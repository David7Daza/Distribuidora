import { Pipe, PipeTransform } from '@angular/core';

const fmt = new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 });

@Pipe({ name: 'cop' })
export class CopPipe implements PipeTransform {
  transform(v: number | null | undefined) { return v == null ? '—' : fmt.format(v); }
}

/** Convierte 'YYYY-MM-DD HH:MM:SS' (PostgreSQL) en 'dd/MM/yyyy HH:mm'. */
@Pipe({ name: 'fecha' })
export class FechaPipe implements PipeTransform {
  transform(v: string | null | undefined, soloDia = false) {
    if (!v) return '—';
    const [d, h] = v.split(/[ T]/);
    const [y, m, dd] = d.split('-');
    return soloDia || !h ? `${dd}/${m}/${y}` : `${dd}/${m}/${y} ${h.slice(0, 5)}`;
  }
}
