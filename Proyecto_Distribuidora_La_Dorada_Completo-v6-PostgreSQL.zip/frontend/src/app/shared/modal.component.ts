import { Component, input, output } from '@angular/core';

@Component({
  selector: 'app-modal',
  template: `
    <div class="modal-fondo" (click)="cerrar.emit()">
      <div class="modal" [class.ancho]="ancho()" (click)="$event.stopPropagation()" role="dialog" [attr.aria-label]="titulo()">
        <header><h3>{{ titulo() }}</h3><button class="btn-icono" (click)="cerrar.emit()" aria-label="Cerrar">✕</button></header>
        <div class="modal-cuerpo"><ng-content /></div>
        <footer><ng-content select="[pie]" /></footer>
      </div>
    </div>`
})
export class ModalComponent {
  titulo = input('');
  ancho = input(false);
  cerrar = output<void>();
}
