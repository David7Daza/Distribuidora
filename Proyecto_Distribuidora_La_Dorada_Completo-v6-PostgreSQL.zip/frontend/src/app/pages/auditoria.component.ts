import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Api } from '../core/api.service';
import { FechaPipe } from '../shared/pipes';

@Component({
  selector: 'app-auditoria',
  imports: [FormsModule, FechaPipe],
  template: `
  <div class="encabezado-pagina"><div><h2>Auditoría</h2><p>Registro de quién hizo qué y cuándo (últimos 300 eventos).</p></div></div>
  <div class="filtros"><select [(ngModel)]="entidad" (ngModelChange)="cargar()"><option value="">Todas las entidades</option>
    @for (e of entidades; track e) { <option>{{ e }}</option> }</select></div>
  <div class="tabla-wrap"><table>
    <thead><tr><th>Fecha</th><th>Usuario</th><th>Acción</th><th>Entidad</th><th>Detalle</th></tr></thead>
    <tbody>
      @for (a of filas(); track a.id) {
        <tr><td>{{ a.fecha | fecha }}</td><td>{{ a.usuario_nombre || 'Sistema' }}</td><td><span class="insignia">{{ a.accion }}</span></td><td>{{ a.entidad }} {{ a.entidad_id }}</td><td>{{ a.detalle }}</td></tr>
      } @empty { <tr><td colspan="5" class="vacio">Sin eventos.</td></tr> }
    </tbody></table></div>`
})
export class AuditoriaComponent implements OnInit {
  private api = inject(Api);
  filas = signal<any[]>([]); entidad = '';
  entidades = ['pedido', 'producto', 'compra', 'cliente', 'proveedor', 'categoría', 'usuario', 'sistema'];
  ngOnInit() { this.cargar(); }
  async cargar() { this.filas.set(await this.api.get('/auditoria', { entidad: this.entidad })); }
}
