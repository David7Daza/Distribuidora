import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Api } from '../core/api.service';
import { FechaPipe } from '../shared/pipes';

const ETIQUETAS: Record<string, string> = { ENTRADA_COMPRA: 'Entrada por compra', SALIDA_PEDIDO: 'Salida por pedido', DEVOLUCION_PEDIDO: 'Devolución (pedido rechazado)', AJUSTE: 'Ajuste manual', INICIAL: 'Inventario inicial' };

@Component({
  selector: 'app-kardex',
  imports: [FormsModule, FechaPipe],
  template: `
  <div class="encabezado-pagina"><div><h2>Kardex — movimientos de inventario</h2><p>Trazabilidad de cada entrada, salida y ajuste de existencias.</p></div></div>
  <div class="filtros">
    <select [(ngModel)]="productoId" (ngModelChange)="cargar()"><option value="">Todos los productos</option>
      @for (p of productos(); track p.id) { <option [value]="p.id">{{ p.referencia }} — {{ p.nombre }}</option> }</select>
    <select [(ngModel)]="tipo" (ngModelChange)="cargar()"><option value="">Todos los tipos</option>
      @for (t of tipos; track t) { <option [value]="t">{{ etiqueta(t) }}</option> }</select>
  </div>
  <div class="tabla-wrap"><table>
    <thead><tr><th>Fecha</th><th>Producto</th><th>Movimiento</th><th class="num">Cantidad</th><th class="num">Stock resultante</th><th>Referencia</th><th>Usuario</th></tr></thead>
    <tbody>
      @for (m of movs(); track m.id) {
        <tr><td>{{ m.fecha | fecha }}</td><td>{{ m.referencia_producto }} <small class="sub">{{ m.producto }}</small></td>
          <td>{{ etiqueta(m.tipo) }}@if (m.nota) { <br><small class="sub">{{ m.nota }}</small> }</td>
          <td class="num" [class.positivo]="m.cantidad > 0" [class.negativo]="m.cantidad < 0">{{ m.cantidad > 0 ? '+' : '' }}{{ m.cantidad }}</td>
          <td class="num">{{ m.stock_resultante }}</td><td>{{ m.referencia || "—" }}</td><td>{{ m.usuario || 'Sistema' }}</td></tr>
      } @empty { <tr><td colspan="7" class="vacio">Sin movimientos.</td></tr> }
    </tbody></table></div>`
})
export class KardexComponent implements OnInit {
  private api = inject(Api);
  productos = signal<any[]>([]); movs = signal<any[]>([]);
  productoId = ''; tipo = '';
  tipos = Object.keys(ETIQUETAS);
  etiqueta(t: string) { return ETIQUETAS[t] ?? t; }
  async ngOnInit() { this.productos.set(await this.api.get('/productos')); this.cargar(); }
  async cargar() { this.movs.set(await this.api.get('/kardex', { productoId: this.productoId, tipo: this.tipo })); }
}
