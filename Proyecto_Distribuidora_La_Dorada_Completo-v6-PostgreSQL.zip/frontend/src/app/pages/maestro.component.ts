import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Api } from '../core/api.service';
import { ModalComponent } from '../shared/modal.component';

interface Campo { k: string; l: string; tipo?: 'text' | 'email' | 'select'; opciones?: string[]; col?: boolean; }
const CONFIG: Record<string, { titulo: string; sub: string; singular: string; campos: Campo[] }> = {
  clientes: {
    titulo: 'Clientes', singular: 'cliente', sub: 'Tiendas, restaurantes y pequeños comercios compradores.',
    campos: [{ k: 'nombre', l: 'Nombre / Razón social *' }, { k: 'nit', l: 'NIT / Cédula' }, { k: 'telefono', l: 'Teléfono / WhatsApp' }, { k: 'email', l: 'Correo', tipo: 'email' },
      { k: 'direccion', l: 'Dirección' }, { k: 'ciudad', l: 'Ciudad' }, { k: 'tipo', l: 'Tipo de cliente', tipo: 'select', opciones: ['Tienda', 'Restaurante', 'Minimercado', 'Otro'] }]
  },
  proveedores: {
    titulo: 'Proveedores', singular: 'proveedor', sub: 'Empresas que abastecen el inventario.',
    campos: [{ k: 'nombre', l: 'Nombre / Razón social *' }, { k: 'nit', l: 'NIT' }, { k: 'telefono', l: 'Teléfono' }, { k: 'email', l: 'Correo', tipo: 'email' }, { k: 'direccion', l: 'Dirección' }]
  },
  categorias: { titulo: 'Categorías de producto', singular: 'categoría', sub: 'Agrupan el catálogo.', campos: [{ k: 'nombre', l: 'Nombre *' }] }
};

@Component({
  selector: 'app-maestro',
  imports: [FormsModule, ModalComponent],
  template: `
  <div class="encabezado-pagina"><div><h2>{{ cfg().titulo }}</h2><p>{{ cfg().sub }}</p></div>
    <button class="btn btn-primario" (click)="nuevo()">＋ Nuevo {{ cfg().singular }}</button></div>
  <div class="filtros"><input type="search" placeholder="Buscar…" [(ngModel)]="buscar" (ngModelChange)="cargar()"></div>
  <div class="tabla-wrap"><table>
    <thead><tr>@for (c of cfg().campos; track c.k) { <th>{{ c.l.replace(' *','') }}</th> }<th></th></tr></thead>
    <tbody>
      @for (f of filas(); track f.id) {
        <tr>@for (c of cfg().campos; track c.k) { <td>{{ f[c.k] || '—' }}</td> }
          <td class="acc"><button class="btn btn-chico" (click)="editar(f)">Editar</button><button class="btn btn-chico btn-peligro" (click)="eliminar(f)">✕</button></td></tr>
      } @empty { <tr><td [attr.colspan]="cfg().campos.length + 1" class="vacio">Sin registros.</td></tr> }
    </tbody></table></div>

  @if (form(); as f) {
    <app-modal [titulo]="(f.id ? 'Editar ' : 'Nuevo ') + cfg().singular" (cerrar)="form.set(null)">
      <div class="form-fila">
        @for (c of cfg().campos; track c.k) {
          <div class="campo"><label>{{ c.l }}</label>
            @if (c.tipo === 'select') { <select [(ngModel)]="f[c.k]">@for (o of c.opciones; track o) { <option>{{ o }}</option> }</select> }
            @else { <input [type]="c.tipo || 'text'" [(ngModel)]="f[c.k]"> }
          </div>
        }
      </div>
      <div pie><button class="btn" (click)="form.set(null)">Cancelar</button><button class="btn btn-primario" (click)="guardar()">Guardar</button></div>
    </app-modal>
  }`
})
export class MaestroComponent implements OnInit {
  private api = inject(Api);
  private ruta = inject(ActivatedRoute);
  tipo = '';
  cfg = signal(CONFIG['clientes']);
  filas = signal<any[]>([]); form = signal<any>(null);
  buscar = '';

  ngOnInit() {
    this.tipo = this.ruta.snapshot.data['tipo'];
    this.cfg.set(CONFIG[this.tipo]);
    this.cargar();
  }
  async cargar() { this.filas.set(await this.api.get('/' + this.tipo, { buscar: this.buscar })); }
  nuevo() { this.form.set(this.tipo === 'clientes' ? { tipo: 'Tienda' } : {}); }
  editar(f: any) { this.form.set({ ...f }); }
  async guardar() {
    const f = this.form();
    const r = f.id ? await this.api.put(`/${this.tipo}/${f.id}`, f) : await this.api.post('/' + this.tipo, f);
    if (r) { this.form.set(null); this.cargar(); }
  }
  async eliminar(f: any) {
    if (!confirm(`¿Eliminar ${this.cfg().singular} «${f.nombre}»?`)) return;
    if (await this.api.delete(`/${this.tipo}/${f.id}`)) this.cargar();
  }
}
