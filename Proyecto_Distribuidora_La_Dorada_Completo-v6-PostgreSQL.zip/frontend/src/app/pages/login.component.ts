import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Auth } from '../core/auth.service';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  template: `
  <div class="login-pagina">
    <form class="login-caja" (ngSubmit)="entrar()">
      <div class="marca" style="padding:0 0 14px"><div class="logo">🧴</div><div><strong style="color:#1f2937">Distribuidora La Dorada</strong><small>Sistema de Pedidos e Inventario</small></div></div>
      <div class="campo"><label>Correo</label><input name="email" type="email" [(ngModel)]="email" autocomplete="username" required></div>
      <div class="campo"><label>Contraseña</label><input name="password" type="password" [(ngModel)]="password" autocomplete="current-password" required></div>
      @if (error()) { <div class="aviso error">{{ error() }}</div> }
      <button class="btn btn-primario" style="width:100%;justify-content:center" [disabled]="cargando()">{{ cargando() ? 'Ingresando…' : 'Ingresar' }}</button>
      <div class="aviso info mt"><strong>Usuarios de prueba</strong> (clic para llenar)
        <div class="acciones" style="margin-top:6px">
          <button type="button" class="btn btn-chico" (click)="demo('admin@ladorada.co','admin123')">ADMIN</button>
          <button type="button" class="btn btn-chico" (click)="demo('ventas@ladorada.co','ventas123')">VENTAS</button>
          <button type="button" class="btn btn-chico" (click)="demo('bodega@ladorada.co','bodega123')">BODEGA</button>
        </div>
      </div>
    </form>
  </div>`
})
export class LoginComponent {
  private auth = inject(Auth);
  private router = inject(Router);
  email = ''; password = '';
  error = signal(''); cargando = signal(false);
  demo(e: string, p: string) { this.email = e; this.password = p; }
  async entrar() {
    this.cargando.set(true); this.error.set('');
    const err = await this.auth.login(this.email, this.password);
    this.cargando.set(false);
    if (err) this.error.set(err); else this.router.navigateByUrl('/');
  }
}
