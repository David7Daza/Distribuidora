import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Api } from '../core/api.service';
import { CopPipe } from '../shared/pipes';

/** CAPA 4 (presentación): equivalente Angular de BorradorPedidoState — carrito temporal del pedido. */
class BorradorPedido {
  items = signal<{ productoId: number; referencia: string; nombre: string; precio: number; cantidad: number; disponible: number }[]>([]);
  total = computed(() => this.items().reduce((a, i) => a + i.precio * i.cantidad, 0));
  agregar(p: any, cantidad: number): string | null {
    if (!Number.isInteger(cantidad) || cantidad <= 0) return `Cantidad inválida (${cantidad}): solo se permiten enteros mayores a cero.`;
    const ex = this.items().find(i => i.productoId === p.id);
    if (ex) this.items.update(l => l.map(i => i.productoId === p.id ? { ...i, cantidad: i.cantidad + cantidad } : i));
    else this.items.update(l => [...l, { productoId: p.id, referencia: p.referencia, nombre: p.nombre, precio: p.precio, cantidad, disponible: p.existencias }]);
    return null;
  }
  quitar(id: number) { this.items.update(l => l.filter(i => i.productoId !== id)); }
  limpiar() { this.items.set([]); }
}

@Component({
  selector: 'app-pedido-nuevo',
  imports: [FormsModule, CopPipe],
  template: `
  <div class="encabezado-pagina"><div><h2>Registrar pedido</h2><p>Seleccione cliente y productos del catálogo único; el sistema valida cantidades y existencias.</p></div></div>
  <div class="cuadricula-2">
    <div>
      <div class="tarjeta">
        <h3>1. Cliente</h3>
        <div class="form-fila">
          <div class="campo"><label>Cliente registrado</label>
            <select [(ngModel)]="clienteId"><option [ngValue]="null">— Cliente ocasional (escribir nombre) —</option>
              @for (c of clientes(); track c.id) { <option [ngValue]="c.id">{{ c.nombre }}</option> }</select></div>
          <div class="campo"><label>Canal</label><select [(ngModel)]="canal"><option>WhatsApp</option><option>Teléfono</option><option>Presencial</option><option>Correo</option></select></div>
        </div>
        @if (!clienteId) { <div class="campo"><label>Nombre del cliente *</label><input [(ngModel)]="clienteNombre" placeholder="Ej.: Tienda Don Pepe"></div> }
      </div>

      <div class="tarjeta mt">
        <h3>2. Agregar productos</h3>
        <div class="filtros">
          <select [(ngModel)]="productoId" style="flex:3 1 220px"><option [ngValue]="null">Seleccione un producto…</option>
            @for (p of productos(); track p.id) { <option [ngValue]="p.id">{{ p.referencia }} — {{ p.nombre }} ({{ p.existencias }} disp.) · {{ p.precio | cop }}</option> }</select>
          <input type="number" min="1" step="1" [(ngModel)]="cantidad" placeholder="Cantidad" style="flex:1 1 90px">
          <button class="btn btn-primario" (click)="agregar()">Agregar al pedido</button>
        </div>
        @if (errorLocal()) { <div class="aviso error">{{ errorLocal() }}</div> }
      </div>
    </div>

    <div class="tarjeta">
      <h3>3. Borrador del pedido</h3>
      @for (i of borrador.items(); track i.productoId) {
        <div style="display:flex;justify-content:space-between;gap:8px;padding:6px 0;border-bottom:1px dashed var(--borde)">
          <div>{{ i.nombre }}<br><small class="sub">{{ i.cantidad }} × {{ i.precio | cop }}
            @if (i.cantidad > i.disponible) { · <span class="negativo">solo hay {{ i.disponible }}</span> }</small></div>
          <div class="derecha"><strong>{{ i.cantidad * i.precio | cop }}</strong><br><button class="btn btn-chico" (click)="borrador.quitar(i.productoId)">Quitar</button></div>
        </div>
      } @empty { <div class="sub">Aún no hay productos en el borrador.</div> }
      <div class="derecha mt">Total: <span class="total-grande">{{ borrador.total() | cop }}</span></div>

      @if (resultado(); as r) { <div class="aviso" [class.ok]="r.exito" [class.error]="!r.exito"><strong>{{ r.exito ? 'Éxito' : 'Bloqueado' }}</strong> · {{ r.mensaje }}</div> }

      <div class="acciones mt" style="justify-content:flex-end">
        <button class="btn" (click)="limpiar()">Vaciar</button>
        <button class="btn" [disabled]="enviando()" (click)="enviar(false)">Guardar como Pendiente</button>
        <button class="btn btn-verde" [disabled]="enviando()" (click)="enviar(true)">Validar existencias y CONFIRMAR</button>
      </div>
    </div>
  </div>`
})
export class PedidoNuevoComponent implements OnInit {
  private api = inject(Api);
  private router = inject(Router);
  borrador = new BorradorPedido();
  clientes = signal<any[]>([]); productos = signal<any[]>([]);
  clienteId: number | null = null; clienteNombre = ''; canal = 'WhatsApp';
  productoId: number | null = null; cantidad: number | null = 1;
  errorLocal = signal(''); resultado = signal<any>(null); enviando = signal(false);

  async ngOnInit() { this.clientes.set(await this.api.get('/clientes')); await this.recargarProductos(); }
  recargarProductos = async () => this.productos.set(await this.api.get('/productos'));

  agregar() {
    this.errorLocal.set(''); this.resultado.set(null);
    const p = this.productos().find(x => x.id === this.productoId);
    if (!p) { this.errorLocal.set('Seleccione un producto.'); return; }
    const err = this.borrador.agregar(p, Number(this.cantidad));
    if (err) this.errorLocal.set(err); else { this.productoId = null; this.cantidad = 1; }
  }
  limpiar() { this.borrador.limpiar(); this.resultado.set(null); this.errorLocal.set(''); }

  async enviar(confirmar: boolean) {
    this.resultado.set(null); this.enviando.set(true);
    try {
      const body = {
        clienteId: this.clienteId, cliente: this.clienteNombre, nota: this.canal, confirmarInmediatamente: confirmar,
        items: this.borrador.items().map(i => ({ productoId: i.productoId, cantidad: i.cantidad }))
      };
      // El servidor es la autoridad: si bloquea (p. ej. stock insuficiente) mostramos su motivo exacto.
      const r = await this.api.post('/pedidos', body, true);
      if (r) {
        this.resultado.set(r);
        this.borrador.limpiar();
        await this.recargarProductos();
        setTimeout(() => this.router.navigate(['/pedidos']), 1600);
      } else {
        this.resultado.set({ exito: false, mensaje: this.ultimoError || 'No se pudo registrar el pedido.' });
      }
    } finally { this.enviando.set(false); }
  }
  get ultimoError() { return this.api.ultimoError; }
}
