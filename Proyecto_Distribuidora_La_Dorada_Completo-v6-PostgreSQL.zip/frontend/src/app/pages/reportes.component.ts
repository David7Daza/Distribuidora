import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Api } from '../core/api.service';
import { CopPipe, FechaPipe } from '../shared/pipes';

interface Col { k: string; l: string; t?: 'cop' | 'num' | 'fecha'; }
interface Rep { id: string; nombre: string; ruta: string; cols: Col[]; filtros: 'periodo' | 'fecha' | 'ninguno'; }
const REPORTES: Rep[] = [
  { id: 'ventas', nombre: 'Ventas por periodo', ruta: 'ventas', filtros: 'periodo', cols: [{ k: 'periodo', l: 'Periodo' }, { k: 'pedidos', l: 'Pedidos', t: 'num' }, { k: 'ventas', l: 'Ventas', t: 'cop' }, { k: 'utilidad', l: 'Utilidad bruta', t: 'cop' }] },
  { id: 'productos', nombre: 'Ventas por producto', ruta: 'productos', filtros: 'periodo', cols: [{ k: 'referencia', l: 'Ref.' }, { k: 'nombre', l: 'Producto' }, { k: 'unidades', l: 'Unidades', t: 'num' }, { k: 'ingresos', l: 'Ingresos', t: 'cop' }, { k: 'utilidad', l: 'Utilidad', t: 'cop' }] },
  { id: 'clientes', nombre: 'Ventas por cliente', ruta: 'clientes', filtros: 'periodo', cols: [{ k: 'cliente', l: 'Cliente' }, { k: 'pedidos', l: 'Pedidos', t: 'num' }, { k: 'ventas', l: 'Ventas', t: 'cop' }, { k: 'saldo', l: 'Saldo por cobrar', t: 'cop' }] },
  { id: 'cartera', nombre: 'Cuentas por cobrar', ruta: 'cartera', filtros: 'ninguno', cols: [{ k: 'codigo', l: 'Pedido' }, { k: 'cliente', l: 'Cliente' }, { k: 'estado', l: 'Estado' }, { k: 'confirmado', l: 'Confirmado', t: 'fecha' }, { k: 'dias', l: 'Días', t: 'num' }, { k: 'total', l: 'Total', t: 'cop' }, { k: 'pagado', l: 'Pagado', t: 'cop' }, { k: 'saldo', l: 'Saldo', t: 'cop' }] },
  { id: 'caja', nombre: 'Cierre de caja diario', ruta: 'cierre-caja', filtros: 'fecha', cols: [{ k: 'fecha', l: 'Hora', t: 'fecha' }, { k: 'codigo', l: 'Pedido' }, { k: 'cliente', l: 'Cliente' }, { k: 'metodo', l: 'Método' }, { k: 'monto', l: 'Monto', t: 'cop' }] }
];

@Component({
  selector: 'app-reportes',
  imports: [FormsModule, CopPipe, FechaPipe],
  template: `
  <div class="encabezado-pagina"><div><h2>Reportes</h2><p>Ventas, rentabilidad, cartera y cierre de caja (consolidación diaria de pagos).</p></div>
    <button class="btn" (click)="csv()">⬇ Exportar CSV</button></div>
  <div class="pestanas">@for (r of reportes; track r.id) { <button class="pestana" [class.activa]="actual().id === r.id" (click)="elegir(r)">{{ r.nombre }}</button> }</div>
  <div class="filtros">
    @if (actual().filtros === 'periodo') {
      <input type="date" [(ngModel)]="desde" (ngModelChange)="cargar()" title="Desde"><input type="date" [(ngModel)]="hasta" (ngModelChange)="cargar()" title="Hasta">
      @if (actual().id === 'ventas') { <select [(ngModel)]="agrupar" (ngModelChange)="cargar()"><option value="dia">Por día</option><option value="mes">Por mes</option></select> }
    }
    @if (actual().filtros === 'fecha') { <input type="date" [(ngModel)]="fecha" (ngModelChange)="cargar()"> }
  </div>
  @if (actual().id === 'caja' && cierre(); as c) {
    <div class="kpis"><div class="kpi verde"><small>Total recaudado el {{ c.fecha }}</small><strong>{{ c.total | cop }}</strong></div>
      @for (m of c.porMetodo; track m.metodo) { <div class="kpi"><small>{{ m.metodo }}</small><strong>{{ m.total | cop }}</strong><span>{{ m.pagos }} pagos</span></div> }</div>
  }
  <div class="tabla-wrap"><table>
    <thead><tr>@for (c of actual().cols; track c.k) { <th [class.num]="c.t === 'cop' || c.t === 'num'">{{ c.l }}</th> }</tr></thead>
    <tbody>
      @for (f of filas(); track $index) {
        <tr>@for (c of actual().cols; track c.k) {
          <td [class.num]="c.t === 'cop' || c.t === 'num'">
            @switch (c.t) { @case ('cop') { {{ f[c.k] | cop }} } @case ('fecha') { {{ f[c.k] | fecha }} } @default { {{ f[c.k] ?? '—' }} } }
          </td> }</tr>
      } @empty { <tr><td [attr.colspan]="actual().cols.length" class="vacio">No hay datos para el periodo seleccionado.</td></tr> }
    </tbody>
    @if (filas().length && totalCol(); as t) { <tfoot><tr><td [attr.colspan]="actual().cols.length - 1"><strong>Total</strong></td><td class="num"><strong>{{ t.valor | cop }}</strong></td></tr></tfoot> }
  </table></div>`
})
export class ReportesComponent implements OnInit {
  private api = inject(Api);
  reportes = REPORTES;
  actual = signal<Rep>(REPORTES[0]);
  filas = signal<any[]>([]); cierre = signal<any>(null);
  desde = ''; hasta = ''; agrupar = 'dia'; fecha = new Date().toISOString().slice(0, 10);

  ngOnInit() { this.cargar(); }
  elegir(r: Rep) { this.actual.set(r); this.cargar(); }
  private params() { return { desde: this.desde, hasta: this.hasta, agrupar: this.agrupar, fecha: this.fecha }; }
  async cargar() {
    const d = await this.api.datos(`/reportes/${this.actual().ruta}`, this.params());
    if (this.actual().id === 'caja') { this.cierre.set(d); this.filas.set(d.pagos); } else this.filas.set(d);
  }
  totalCol() {
    const cols = this.actual().cols; const ult = cols[cols.length - 1];
    if (ult.t !== 'cop') return null;
    return { valor: this.filas().reduce((a, f) => a + (f[ult.k] || 0), 0) };
  }
  csv() { this.api.descargar(`/reportes/${this.actual().ruta}`, { ...this.params(), formato: 'csv' }, `${this.actual().ruta}.csv`); }
}
