import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Api } from '../core/api.service';
import { ModalComponent } from '../shared/modal.component';
import { CopPipe, FechaPipe } from '../shared/pipes';

@Component({
  selector: 'app-compras',
  imports: [FormsModule, ModalComponent, CopPipe, FechaPipe],
  template: `
  <div class="encabezado-pagina"><div><h2>Compras e ingreso de mercancía</h2><p>Cada compra aumenta el inventario y deja trazabilidad en el kardex.</p></div>
    <button class="btn btn-primario" (click)="nueva()">＋ Registrar compra</button></div>
  <div class="tabla-wrap"><table>
    <thead><tr><th>Código</th><th>Fecha</th><th>Proveedor</th><th class="num">Líneas</th><th class="num">Total</th><th>Registró</th><th></th></tr></thead>
    <tbody>
      @for (c of compras(); track c.id) {
        <tr><td><strong>{{ c.codigo }}</strong></td><td>{{ c.fecha | fecha }}</td><td>{{ c.proveedor }}</td><td class="num">{{ c.lineas }}</td><td class="num">{{ c.total | cop }}</td><td>{{ c.usuario }}</td>
          <td class="acc"><button class="btn btn-chico" (click)="ver(c.id)">Detalle</button></td></tr>
      } @empty { <tr><td colspan="7" class="vacio">Aún no hay compras registradas.</td></tr> }
    </tbody></table></div>

  @if (form(); as f) {
    <app-modal titulo="Registrar compra" [ancho]="true" (cerrar)="form.set(null)">
      <div class="form-fila">
        <div class="campo"><label>Proveedor *</label><select [(ngModel)]="f.proveedorId"><option [ngValue]="null">Seleccione…</option>
          @for (p of proveedores(); track p.id) { <option [ngValue]="p.id">{{ p.nombre }}</option> }</select></div>
        <div class="campo"><label>Nota / factura del proveedor</label><input [(ngModel)]="f.nota"></div>
      </div>
      <div class="tabla-wrap"><table>
        <thead><tr><th>Producto</th><th class="num" style="width:110px">Cantidad</th><th class="num" style="width:140px">Costo unitario</th><th class="num">Subtotal</th><th></th></tr></thead>
        <tbody>
          @for (l of f.items; track $index) {
            <tr><td><select [(ngModel)]="l.productoId" (ngModelChange)="alElegir(l)"><option [ngValue]="null">Seleccione…</option>
                @for (p of productos(); track p.id) { <option [ngValue]="p.id">{{ p.referencia }} — {{ p.nombre }}</option> }</select></td>
              <td><input type="number" min="1" step="1" [(ngModel)]="l.cantidad"></td>
              <td><input type="number" min="0" [(ngModel)]="l.costoUnitario"></td>
              <td class="num">{{ (l.cantidad || 0) * (l.costoUnitario || 0) | cop }}</td>
              <td><button class="btn btn-chico" (click)="quitar($index)">✕</button></td></tr>
          }
        </tbody></table></div>
      <div class="acciones mt"><button class="btn btn-chico" (click)="agregarLinea()">＋ Agregar línea</button><span style="flex:1"></span>
        Total: <span class="total-grande">{{ total() | cop }}</span></div>
      <div pie><button class="btn" (click)="form.set(null)">Cancelar</button><button class="btn btn-primario" (click)="guardar()">Registrar y aumentar inventario</button></div>
    </app-modal>
  }
  @if (det(); as c) {
    <app-modal [titulo]="'Compra ' + c.codigo" (cerrar)="det.set(null)">
      <p>{{ c.proveedor }} · {{ c.fecha | fecha }} · {{ c.usuario }}<br>{{ c.nota }}</p>
      <ul class="lista-simple">@for (i of c.items; track i.id) { <li><span>{{ i.referencia }} — {{ i.nombre }}<br><small class="sub">{{ i.cantidad }} × {{ i.costo_unitario | cop }}</small></span><strong>{{ i.cantidad * i.costo_unitario | cop }}</strong></li> }</ul>
      <div class="derecha mt">Total <span class="total-grande">{{ c.total | cop }}</span></div>
    </app-modal>
  }`
})
export class ComprasComponent implements OnInit {
  private api = inject(Api);
  compras = signal<any[]>([]); proveedores = signal<any[]>([]); productos = signal<any[]>([]);
  form = signal<any>(null); det = signal<any>(null);
  total = computed(() => (this.form()?.items ?? []).reduce((a: number, l: any) => a + (l.cantidad || 0) * (l.costoUnitario || 0), 0));

  async ngOnInit() {
    this.proveedores.set(await this.api.get('/proveedores'));
    this.productos.set(await this.api.get('/productos'));
    this.cargar();
  }
  async cargar() { this.compras.set(await this.api.get('/compras')); }
  nueva() { this.form.set({ proveedorId: null, nota: '', items: [{ productoId: null, cantidad: 1, costoUnitario: 0 }] }); }
  agregarLinea() { this.form.update(f => ({ ...f, items: [...f.items, { productoId: null, cantidad: 1, costoUnitario: 0 }] })); }
  quitar(i: number) { this.form.update(f => ({ ...f, items: f.items.filter((_: any, k: number) => k !== i) })); }
  alElegir(l: any) { const p = this.productos().find(x => x.id === l.productoId); if (p) l.costoUnitario = p.costo; }
  async guardar() {
    const f = this.form();
    const r = await this.api.post('/compras', { ...f, items: f.items.filter((l: any) => l.productoId) });
    if (r) { this.form.set(null); this.cargar(); this.productos.set(await this.api.get('/productos')); }
  }
  async ver(id: number) { this.det.set(await this.api.datos('/compras/' + id)); }
}
