import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Api } from '../core/api.service';
import { Auth } from '../core/auth.service';
import { ModalComponent } from '../shared/modal.component';
import { CopPipe, FechaPipe } from '../shared/pipes';

@Component({
  selector: 'app-pedidos',
  imports: [FormsModule, RouterLink, ModalComponent, CopPipe, FechaPipe],
  template: `
  <div class="encabezado-pagina"><div><h2>Pedidos</h2><p>Vista compartida del estado de cada pedido (RF-05, RF-07).</p></div>
    <div class="acciones">
      <button class="btn" (click)="exportar()">⬇ Exportar CSV</button>
      @if (auth.puede('registrarPedido')) { <a class="btn btn-primario" routerLink="/pedidos/nuevo">＋ Nuevo pedido</a> }
    </div></div>

  <div class="pestanas">
    @for (e of estados; track e) {
      <button class="pestana" [class.activa]="estado === e" (click)="filtrar(e)">{{ e === 'TODOS' ? 'Todos' : e }}
        <small>{{ resumen()[e === 'TODOS' ? 'total' : e] ?? 0 }}</small></button>
    }
  </div>
  <div class="filtros">
    <input type="search" placeholder="Buscar por código o cliente…" [(ngModel)]="buscar" (ngModelChange)="cargar()">
    <input type="date" [(ngModel)]="desde" (ngModelChange)="cargar()" title="Desde">
    <input type="date" [(ngModel)]="hasta" (ngModelChange)="cargar()" title="Hasta">
  </div>

  <div class="tabla-wrap"><table>
    <thead><tr><th>Código</th><th>Fecha</th><th>Cliente</th><th>Estado</th><th>Pago</th><th class="num">Total</th><th></th></tr></thead>
    <tbody>
      @for (p of pedidos(); track p.id) {
        <tr class="clic" (click)="ver(p.id)">
          <td><strong>{{ p.codigo }}</strong></td><td>{{ p.fecha | fecha }}</td>
          <td>{{ p.cliente }}<br><small class="sub">{{ p.nota }} · {{ p.vendedor }}</small></td>
          <td><span class="insignia {{p.estado}}">{{ p.estado }}</span></td>
          <td><span class="insignia {{p.estadoPago === 'Sin pago' ? 'bajo' : p.estadoPago}}">{{ p.estadoPago }}</span></td>
          <td class="num">{{ p.total | cop }}</td>
          <td class="acc"><button class="btn btn-chico" (click)="ver(p.id); $event.stopPropagation()">Ver detalle</button></td>
        </tr>
      } @empty { <tr><td colspan="7" class="vacio">No hay pedidos con estos filtros.</td></tr> }
    </tbody></table></div>

  @if (det(); as p) {
    <app-modal [titulo]="'Pedido ' + p.codigo" [ancho]="true" (cerrar)="det.set(null)">
      <div class="cuadricula-3" style="margin-bottom:10px">
        <div><small class="sub">Cliente</small><br><strong>{{ p.cliente }}</strong></div>
        <div><small class="sub">Estado</small><br><span class="insignia {{p.estado}}">{{ p.estado }}</span> <span class="insignia {{p.estadoPago === 'Sin pago' ? 'bajo' : p.estadoPago}}">{{ p.estadoPago }}</span></div>
        <div><small class="sub">Canal · Vendedor</small><br>{{ p.nota }} · {{ p.vendedor }}</div>
        <div><small class="sub">Creado</small><br>{{ p.fecha | fecha }}</div>
        <div><small class="sub">Confirmado</small><br>{{ p.confirmado | fecha }}</div>
        <div><small class="sub">Despachado</small><br>{{ p.despachado | fecha }}</div>
      </div>
      <div class="tabla-wrap"><table>
        <thead><tr><th>Ref.</th><th>Producto</th><th class="num">Cant.</th><th class="num">Precio</th><th class="num">Subtotal</th></tr></thead>
        <tbody>
          @for (i of p.items; track i.productoId) {
            <tr><td>{{ i.referencia }}</td><td>{{ i.nombre }}</td><td class="num">{{ i.cantidad }}</td><td class="num">{{ i.precioUnitario | cop }}</td><td class="num">{{ i.cantidad * i.precioUnitario | cop }}</td></tr>
          }
          <tr><td colspan="4" class="num"><strong>Total</strong></td><td class="num total-grande">{{ p.total | cop }}</td></tr>
        </tbody></table></div>

      <h3 class="mt">Pagos <small class="sub">· pagado {{ p.pagado | cop }} · saldo {{ p.saldo | cop }}</small></h3>
      @for (g of p.pagos; track g.id) { <div class="sub">• {{ g.fecha | fecha }} — {{ g.monto | cop }} ({{ g.metodo }}) · {{ g.usuario }}</div> }
      @if (!p.pagos.length) { <div class="sub">Sin pagos registrados.</div> }
      @if (auth.puede('registrarPago') && (p.estado === 'Confirmado' || p.estado === 'Despachado') && p.saldo > 0) {
        <div class="filtros mt">
          <input type="number" min="1" [max]="p.saldo" [(ngModel)]="monto" placeholder="Monto del pago">
          <select [(ngModel)]="metodo"><option>Efectivo</option><option>Transferencia</option><option>Nequi</option><option>Daviplata</option><option>Tarjeta</option></select>
          <button class="btn btn-verde" (click)="pagar(p)">💵 Registrar pago</button>
          <button class="btn" (click)="monto = p.saldo">Saldo completo</button>
        </div>
      }
      <div pie>
        @if (p.estado === 'Pendiente' && auth.puede('registrarPedido')) { <button class="btn btn-verde" (click)="cambiar(p, 'Confirmado')">✔ Validar y confirmar</button> }
        @if (p.estado === 'Confirmado' && auth.puede('despachar')) { <button class="btn btn-primario" (click)="cambiar(p, 'Despachado')">🚚 Marcar despachado</button> }
        @if (p.estado !== 'Despachado' && p.estado !== 'Rechazado' && auth.puede('rechazar')) { <button class="btn btn-peligro" (click)="cambiar(p, 'Rechazado')">✕ Rechazar / cancelar</button> }
        <button class="btn" (click)="imprimir()">🖨 Imprimir</button>
      </div>
    </app-modal>
  }`
})
export class PedidosComponent implements OnInit {
  private api = inject(Api);
  private ruta = inject(ActivatedRoute);
  auth = inject(Auth);
  estados = ['TODOS', 'Pendiente', 'Confirmado', 'Despachado', 'Rechazado'];
  pedidos = signal<any[]>([]); resumen = signal<any>({}); det = signal<any>(null);
  estado = 'TODOS'; buscar = ''; desde = ''; hasta = '';
  monto: number | null = null; metodo = 'Efectivo';

  ngOnInit() {
    const e = this.ruta.snapshot.queryParamMap.get('estado');
    if (e && this.estados.includes(e)) this.estado = e;
    this.cargar();
  }
  filtrar(e: string) { this.estado = e; this.cargar(); }
  async cargar() {
    this.resumen.set(await this.api.get('/pedidos/resumen'));
    this.pedidos.set(await this.api.get('/pedidos', { estado: this.estado, buscar: this.buscar, desde: this.desde, hasta: this.hasta }));
  }
  async ver(id: number) { this.monto = null; this.det.set(await this.api.datos('/pedidos/' + id)); }
  async cambiar(p: any, estado: string) {
    if (estado === 'Rechazado' && !confirm(`¿Rechazar el pedido ${p.codigo}?` + (p.estado === 'Confirmado' ? ' Las unidades volverán al inventario.' : ''))) return;
    const r = await this.api.post(`/pedidos/${p.id}/estado`, { estado });
    if (r) { this.det.set(r.datos); this.cargar(); }
  }
  async pagar(p: any) {
    const r = await this.api.post(`/pedidos/${p.id}/pagos`, { monto: this.monto, metodo: this.metodo });
    if (r) { this.det.set(r.datos); this.monto = null; this.cargar(); }
  }
  imprimir() { window.print(); }
  exportar() { this.api.descargar('/exportar/pedidos.csv', undefined, 'pedidos.csv'); }
}
