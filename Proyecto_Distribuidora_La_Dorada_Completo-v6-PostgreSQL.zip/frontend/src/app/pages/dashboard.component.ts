import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Api } from '../core/api.service';
import { CopPipe, FechaPipe } from '../shared/pipes';

@Component({
  selector: 'app-dashboard',
  imports: [RouterLink, CopPipe, FechaPipe],
  template: `
  <div class="encabezado-pagina"><div><h2>Panel de control</h2><p>Vista compartida de ventas, pedidos e inventario en tiempo real.</p></div>
    <button class="btn" (click)="cargar()">↻ Actualizar</button></div>
  @if (d(); as d) {
    <div class="kpis">
      <div class="kpi"><small>Ventas de hoy</small><strong>{{ d.ventasHoy.t | cop }}</strong><span>{{ d.ventasHoy.n }} pedidos</span></div>
      <div class="kpi verde"><small>Ventas del mes</small><strong>{{ d.ventasMes.t | cop }}</strong><span>{{ d.ventasMes.n }} pedidos</span></div>
      <div class="kpi rojo"><small>Por cobrar (cartera)</small><strong>{{ d.porCobrar | cop }}</strong><span>pedidos confirmados sin pago total</span></div>
      <div class="kpi azul"><small>Valor del inventario</small><strong>{{ d.inventario.valorCosto | cop }}</strong><span>{{ d.inventario.unidades }} uds · {{ d.inventario.productos }} productos</span></div>
    </div>

    <div class="pestanas">
      @for (e of estados; track e) {
        <a class="pestana" [routerLink]="['/pedidos']" [queryParams]="{estado: e}">
          <span class="insignia {{e}}">{{ e }}</span> <small>{{ d.resumen[e] }}</small></a>
      }
      <span class="pestana">Total pedidos <small>{{ d.resumen.total }}</small></span>
    </div>

    <div class="cuadricula-2">
      <div class="tarjeta"><h3>Ventas de los últimos 14 días</h3>
        <svg class="grafico" viewBox="0 0 560 190" role="img" aria-label="Ventas diarias">
          @for (b of barras(); track b.fecha) {
            <rect [attr.x]="b.x" [attr.y]="b.y" width="28" [attr.height]="b.h" rx="3" fill="#c8921a"><title>{{ b.fecha }}: {{ b.total | cop }}</title></rect>
            <text [attr.x]="b.x + 14" y="182" text-anchor="middle">{{ b.dia }}</text>
          }
          <line x1="0" y1="165" x2="560" y2="165" stroke="#e5e7eb" />
        </svg>
        @if (!hayVentas()) { <div class="sub derecha">Aún no hay ventas registradas en este periodo.</div> }
      </div>
      <div class="tarjeta"><h3>KPIs de la Sección 5.9</h3>
        <ul class="lista-simple">
          <li><span>Tiempo promedio de confirmación</span><strong>{{ d.kpis.tiempoConfirmacionMin == null ? '—' : d.kpis.tiempoConfirmacionMin + ' min' }}</strong></li>
          <li><span>Meta</span><span class="sub">&lt; 2 min (antes: 40 min)</span></li>
          <li><span>Tasa de pedidos rechazados</span><strong>{{ d.kpis.tasaRechazoPct }}%</strong></li>
          <li><span>Valor potencial de venta del stock</span><strong>{{ d.inventario.valorVenta | cop }}</strong></li>
        </ul>
      </div>
    </div>

    <div class="cuadricula-3 mt">
      <div class="tarjeta"><h3>⚠ Stock bajo / agotándose</h3>
        @if (!d.stockBajo.length) { <div class="sub">Todo el inventario está sobre su mínimo ✔</div> }
        <ul class="lista-simple">
          @for (p of d.stockBajo; track p.id) {
            <li><span>{{ p.nombre }}<br><small class="sub">{{ p.referencia }} · mín. {{ p.stock_minimo }}</small></span>
              <span class="insignia" [class.agotado]="p.existencias === 0" [class.bajo]="p.existencias > 0">{{ p.existencias }} uds</span></li>
          }
        </ul>
      </div>
      <div class="tarjeta"><h3>🏆 Productos más vendidos</h3>
        @if (!d.topProductos.length) { <div class="sub">Sin ventas todavía.</div> }
        <ul class="lista-simple">
          @for (p of d.topProductos; track p.referencia) { <li><span>{{ p.nombre }}</span><strong>{{ p.unidades }} uds</strong></li> }
        </ul>
      </div>
      <div class="tarjeta"><h3>⭐ Mejores clientes</h3>
        @if (!d.topClientes.length) { <div class="sub">Sin ventas todavía.</div> }
        <ul class="lista-simple">
          @for (c of d.topClientes; track c.cliente) { <li><span>{{ c.cliente }}<br><small class="sub">{{ c.pedidos }} pedidos</small></span><strong>{{ c.total | cop }}</strong></li> }
        </ul>
      </div>
    </div>

    <div class="tarjeta mt"><h3>Pedidos recientes</h3>
      <div class="tabla-wrap" style="border:0">
        <table><thead><tr><th>Código</th><th>Fecha</th><th>Cliente</th><th>Estado</th><th class="num">Total</th></tr></thead>
        <tbody>
          @for (p of d.recientes; track p.id) {
            <tr><td><strong>{{ p.codigo }}</strong></td><td>{{ p.fecha | fecha }}</td><td>{{ p.cliente }}</td><td><span class="insignia {{p.estado}}">{{ p.estado }}</span></td><td class="num">{{ p.total | cop }}</td></tr>
          } @empty { <tr><td colspan="5" class="vacio">No hay pedidos todavía. Cree el primero desde «Nuevo pedido».</td></tr> }
        </tbody></table>
      </div>
    </div>
  } @else { <div class="vacio">Cargando panel…</div> }`
})
export class DashboardComponent implements OnInit {
  private api = inject(Api);
  estados = ['Pendiente', 'Confirmado', 'Despachado', 'Rechazado'] as const;
  d = signal<any>(null);
  barras = computed(() => {
    const dias: any[] = this.d()?.ventasDiarias ?? [];
    const max = Math.max(1, ...dias.map(x => x.total));
    return dias.map((x, i) => {
      const h = Math.round((x.total / max) * 140);
      return { ...x, x: i * 40 + 2, h, y: 165 - h, dia: x.fecha.slice(8) + '/' + x.fecha.slice(5, 7) };
    });
  });
  hayVentas = computed(() => (this.d()?.ventasDiarias ?? []).some((x: any) => x.total > 0));
  ngOnInit() { this.cargar(); }
  async cargar() { this.d.set(await this.api.datos('/dashboard')); }
}
