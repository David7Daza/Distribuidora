import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Api } from '../core/api.service';
import { Auth } from '../core/auth.service';
import { ModalComponent } from '../shared/modal.component';
import { CopPipe } from '../shared/pipes';

@Component({
  selector: 'app-productos',
  imports: [FormsModule, ModalComponent, CopPipe],
  template: `
  <div class="encabezado-pagina"><div><h2>Catálogo e inventario</h2><p>Productos, precios y existencias (RF-01, RF-02).</p></div>
    <div class="acciones">
      <button class="btn" (click)="exportar()">⬇ Exportar CSV</button>
      @if (auth.puede('editarCatalogo')) { <button class="btn btn-primario" (click)="nuevo()">＋ Nuevo producto</button> }
    </div></div>

  <div class="filtros">
    <input type="search" placeholder="Buscar por nombre o referencia…" [(ngModel)]="buscar" (ngModelChange)="cargar()">
    <select [(ngModel)]="categoriaId" (ngModelChange)="cargar()"><option value="">Todas las categorías</option>
      @for (c of categorias(); track c.id) { <option [value]="c.id">{{ c.nombre }}</option> }</select>
    <label class="marca-check"><input type="checkbox" [(ngModel)]="bajoStock" (ngModelChange)="cargar()"> Solo stock bajo</label>
  </div>

  <div class="tabla-wrap"><table>
    <thead><tr><th>Referencia</th><th>Producto</th><th>Categoría</th><th class="num">Precio</th><th class="num">Costo · margen</th><th class="num">Existencias</th><th></th></tr></thead>
    <tbody>
      @for (p of productos(); track p.id) {
        <tr>
          <td><strong>{{ p.referencia }}</strong></td>
          <td>{{ p.nombre }}<br><small class="sub">{{ p.proveedor || 'Sin proveedor' }}</small></td>
          <td>{{ p.categoria || '—' }}</td>
          <td class="num">{{ p.precio | cop }}</td>
          <td class="num">{{ p.costo | cop }}<br><small class="sub">{{ p.precio > 0 ? (((p.precio - p.costo) / p.precio) * 100).toFixed(0) : 0 }}% margen</small></td>
          <td class="num"><span class="insignia" [class.ok]="p.existencias > p.stockMinimo" [class.bajo]="p.existencias <= p.stockMinimo && p.existencias > 0" [class.agotado]="p.existencias === 0">{{ p.existencias }}</span><br><small class="sub">mín. {{ p.stockMinimo }}</small></td>
          <td class="acc">
            @if (auth.puede('ajustarStock')) { <button class="btn btn-chico" (click)="abrirAjuste(p)">± Stock</button> }
            @if (auth.puede('editarCatalogo')) { <button class="btn btn-chico" (click)="editar(p)">Editar</button>
              <button class="btn btn-chico btn-peligro" (click)="desactivar(p)">✕</button> }
          </td>
        </tr>
      } @empty { <tr><td colspan="7" class="vacio">No hay productos que coincidan con la búsqueda.</td></tr> }
    </tbody></table></div>

  @if (form(); as f) {
    <app-modal [titulo]="f.id ? 'Editar producto' : 'Nuevo producto'" (cerrar)="form.set(null)">
      <div class="form-fila">
        <div class="campo"><label>Referencia *</label><input [(ngModel)]="f.referencia" placeholder="ASEO-006"></div>
        <div class="campo"><label>Nombre *</label><input [(ngModel)]="f.nombre"></div>
        <div class="campo"><label>Categoría</label><select [(ngModel)]="f.categoriaId"><option [ngValue]="null">— Sin categoría —</option>
          @for (c of categorias(); track c.id) { <option [ngValue]="c.id">{{ c.nombre }}</option> }</select></div>
        <div class="campo"><label>Proveedor</label><select [(ngModel)]="f.proveedorId"><option [ngValue]="null">— Sin proveedor —</option>
          @for (c of proveedores(); track c.id) { <option [ngValue]="c.id">{{ c.nombre }}</option> }</select></div>
        <div class="campo"><label>Precio de venta (COP) *</label><input type="number" min="1" [(ngModel)]="f.precio"></div>
        <div class="campo"><label>Costo (COP)</label><input type="number" min="0" [(ngModel)]="f.costo"></div>
        <div class="campo"><label>Existencias</label><input type="number" min="0" step="1" [(ngModel)]="f.existencias"></div>
        <div class="campo"><label>Stock mínimo (alerta)</label><input type="number" min="0" step="1" [(ngModel)]="f.stockMinimo"></div>
      </div>
      <div pie><button class="btn" (click)="form.set(null)">Cancelar</button><button class="btn btn-primario" (click)="guardar()">Guardar</button></div>
    </app-modal>
  }
  @if (ajuste(); as a) {
    <app-modal [titulo]="'Ajustar stock — ' + a.p.referencia" (cerrar)="ajuste.set(null)">
      <p>{{ a.p.nombre }} — existencia actual: <strong>{{ a.p.existencias }}</strong></p>
      <div class="campo"><label>Nueva existencia</label><input type="number" min="0" step="1" [(ngModel)]="a.existencias"></div>
      <div class="campo"><label>Motivo del ajuste *</label><input [(ngModel)]="a.nota" placeholder="Conteo físico, merma, daño…"></div>
      <div pie><button class="btn" (click)="ajuste.set(null)">Cancelar</button><button class="btn btn-primario" (click)="guardarAjuste()">Aplicar ajuste</button></div>
    </app-modal>
  }`
})
export class ProductosComponent implements OnInit {
  private api = inject(Api);
  auth = inject(Auth);
  productos = signal<any[]>([]); categorias = signal<any[]>([]); proveedores = signal<any[]>([]);
  form = signal<any>(null); ajuste = signal<any>(null);
  buscar = ''; categoriaId = ''; bajoStock = false;

  async ngOnInit() {
    this.categorias.set(await this.api.get('/categorias'));
    this.proveedores.set(await this.api.get('/proveedores'));
    await this.cargar();
  }
  async cargar() { this.productos.set(await this.api.get('/productos', { buscar: this.buscar, categoriaId: this.categoriaId, bajoStock: this.bajoStock })); }
  nuevo() { this.form.set({ referencia: '', nombre: '', categoriaId: null, proveedorId: null, precio: null, costo: 0, existencias: 0, stockMinimo: 5 }); }
  editar(p: any) { this.form.set({ ...p }); }
  async guardar() {
    const f = this.form();
    const r = f.id ? await this.api.put('/productos/' + f.id, f) : await this.api.post('/productos', f);
    if (r) { this.form.set(null); this.cargar(); }
  }
  async desactivar(p: any) {
    if (!confirm(`¿Desactivar «${p.nombre}»? No aparecerá en nuevos pedidos pero se conserva el historial.`)) return;
    if (await this.api.delete('/productos/' + p.id)) this.cargar();
  }
  abrirAjuste(p: any) { this.ajuste.set({ p, existencias: p.existencias, nota: '' }); }
  async guardarAjuste() {
    const a = this.ajuste();
    if (await this.api.post(`/productos/${a.p.id}/ajuste`, { existencias: a.existencias, nota: a.nota })) { this.ajuste.set(null); this.cargar(); }
  }
  exportar() { this.api.descargar('/exportar/productos.csv', undefined, 'productos.csv'); }
}
