import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Api } from '../core/api.service';
import { Auth } from '../core/auth.service';
import { ModalComponent } from '../shared/modal.component';
import { FechaPipe } from '../shared/pipes';

@Component({
  selector: 'app-usuarios',
  imports: [FormsModule, ModalComponent, FechaPipe],
  template: `
  <div class="encabezado-pagina"><div><h2>Usuarios y roles</h2><p>Autenticación con contraseña cifrada (bcrypt) y matriz de permisos por rol (RF-08).</p></div>
    <button class="btn btn-primario" (click)="nuevo()">＋ Nuevo usuario</button></div>
  <div class="tabla-wrap"><table>
    <thead><tr><th>Nombre</th><th>Correo</th><th>Rol</th><th>Estado</th><th>Creado</th><th></th></tr></thead>
    <tbody>
      @for (u of usuarios(); track u.id) {
        <tr><td><strong>{{ u.nombre }}</strong>@if (u.id === auth.usuario()?.id) { <small class="sub"> (usted)</small> }</td><td>{{ u.email }}</td><td><span class="insignia Confirmado">{{ u.rol }}</span></td>
          <td><span class="insignia" [class.ok]="u.activo" [class.inactivo]="!u.activo">{{ u.activo ? 'Activo' : 'Inactivo' }}</span></td><td>{{ u.creado | fecha:true }}</td>
          <td class="acc"><button class="btn btn-chico" (click)="editar(u)">Editar</button></td></tr>
      }
    </tbody></table></div>

  <div class="tarjeta mt"><h3>Matriz de permisos (Sección 5.7)</h3>
    <div class="tabla-wrap" style="border:0"><table>
      <thead><tr><th>Acción</th><th>ADMIN</th><th>VENTAS</th><th>BODEGA</th></tr></thead>
      <tbody>@for (a of matriz; track a[0]) { <tr><td>{{ a[1] }}</td>@for (x of a[2]; track $index) { <td>{{ x ? '✔' : '—' }}</td> }</tr> }</tbody></table></div></div>

  @if (form(); as f) {
    <app-modal [titulo]="f.id ? 'Editar usuario' : 'Nuevo usuario'" (cerrar)="form.set(null)">
      <div class="campo"><label>Nombre *</label><input [(ngModel)]="f.nombre"></div>
      @if (!f.id) { <div class="campo"><label>Correo *</label><input type="email" [(ngModel)]="f.email"></div> }
      <div class="form-fila">
        <div class="campo"><label>Rol</label><select [(ngModel)]="f.rol"><option>ADMIN</option><option>VENTAS</option><option>BODEGA</option></select></div>
        <div class="campo"><label>{{ f.id ? 'Nueva contraseña (opcional)' : 'Contraseña * (mín. 6)' }}</label><input type="password" [(ngModel)]="f.password"></div>
      </div>
      @if (f.id) { <label class="marca-check"><input type="checkbox" [(ngModel)]="f.activo"> Usuario activo</label> }
      <div pie><button class="btn" (click)="form.set(null)">Cancelar</button><button class="btn btn-primario" (click)="guardar()">Guardar</button></div>
    </app-modal>
  }`
})
export class UsuariosComponent implements OnInit {
  private api = inject(Api);
  auth = inject(Auth);
  usuarios = signal<any[]>([]); form = signal<any>(null);
  matriz: [string, string, boolean[]][] = [
    ['consultar', 'Consultar catálogo, pedidos y resumen', [true, true, true]],
    ['editarCatalogo', 'Crear/editar productos y categorías', [true, false, true]],
    ['ajustarStock', 'Ajustar existencias manualmente', [true, false, true]],
    ['registrarCompra', 'Registrar compras de mercancía', [true, false, true]],
    ['gestionarProveedores', 'Gestionar proveedores', [true, false, true]],
    ['registrarPedido', 'Registrar y confirmar pedidos', [true, true, false]],
    ['gestionarClientes', 'Gestionar clientes', [true, true, false]],
    ['despachar', 'Marcar pedidos como Despachado', [true, false, true]],
    ['rechazar', 'Rechazar/cancelar pedidos no despachados', [true, true, true]],
    ['registrarPago', 'Registrar pagos (consolidación diaria)', [true, false, false]],
    ['verReportes', 'Ver reportes financieros', [true, false, false]],
    ['gestionarUsuarios', 'Administrar usuarios y auditoría', [true, false, false]]
  ];
  ngOnInit() { this.cargar(); }
  async cargar() { this.usuarios.set(await this.api.datos('/usuarios')); }
  nuevo() { this.form.set({ nombre: '', email: '', rol: 'VENTAS', password: '', activo: true }); }
  editar(u: any) { this.form.set({ ...u, activo: !!u.activo, password: '' }); }
  async guardar() {
    const f = this.form();
    const r = f.id ? await this.api.put('/usuarios/' + f.id, f) : await this.api.post('/usuarios', f);
    if (r) { this.form.set(null); this.cargar(); }
  }
}
