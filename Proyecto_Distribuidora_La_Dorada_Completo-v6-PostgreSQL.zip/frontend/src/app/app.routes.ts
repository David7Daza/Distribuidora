import { Routes } from '@angular/router';
import { authGuard } from './core/guards';

export const routes: Routes = [
  { path: 'login', loadComponent: () => import('./pages/login.component').then(m => m.LoginComponent) },
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () => import('./layout/shell.component').then(m => m.ShellComponent),
    children: [
      { path: '', pathMatch: 'full', loadComponent: () => import('./pages/dashboard.component').then(m => m.DashboardComponent) },
      { path: 'pedidos', loadComponent: () => import('./pages/pedidos.component').then(m => m.PedidosComponent) },
      { path: 'pedidos/nuevo', canActivate: [authGuard], data: { permiso: 'registrarPedido' }, loadComponent: () => import('./pages/pedido-nuevo.component').then(m => m.PedidoNuevoComponent) },
      { path: 'productos', loadComponent: () => import('./pages/productos.component').then(m => m.ProductosComponent) },
      { path: 'clientes', canActivate: [authGuard], data: { permiso: 'gestionarClientes', tipo: 'clientes' }, loadComponent: () => import('./pages/maestro.component').then(m => m.MaestroComponent) },
      { path: 'proveedores', canActivate: [authGuard], data: { permiso: 'gestionarProveedores', tipo: 'proveedores' }, loadComponent: () => import('./pages/maestro.component').then(m => m.MaestroComponent) },
      { path: 'categorias', canActivate: [authGuard], data: { permiso: 'editarCatalogo', tipo: 'categorias' }, loadComponent: () => import('./pages/maestro.component').then(m => m.MaestroComponent) },
      { path: 'compras', canActivate: [authGuard], data: { permiso: 'registrarCompra' }, loadComponent: () => import('./pages/compras.component').then(m => m.ComprasComponent) },
      { path: 'kardex', loadComponent: () => import('./pages/kardex.component').then(m => m.KardexComponent) },
      { path: 'reportes', canActivate: [authGuard], data: { permiso: 'verReportes' }, loadComponent: () => import('./pages/reportes.component').then(m => m.ReportesComponent) },
      { path: 'usuarios', canActivate: [authGuard], data: { permiso: 'gestionarUsuarios' }, loadComponent: () => import('./pages/usuarios.component').then(m => m.UsuariosComponent) },
      { path: 'auditoria', canActivate: [authGuard], data: { permiso: 'verAuditoria' }, loadComponent: () => import('./pages/auditoria.component').then(m => m.AuditoriaComponent) }
    ]
  },
  { path: '**', redirectTo: '' }
];
