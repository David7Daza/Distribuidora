import { Injectable, signal } from '@angular/core';

export interface Toast { id: number; tipo: 'ok' | 'error'; texto: string; }

@Injectable({ providedIn: 'root' })
export class ToastService {
  toasts = signal<Toast[]>([]);
  private n = 0;
  ok(t: string) { this.push('ok', t, 4500); }
  error(t: string) { this.push('error', t, 9000); }
  cerrar(id: number) { this.toasts.update(l => l.filter(x => x.id !== id)); }
  private push(tipo: 'ok' | 'error', texto: string, ms: number) {
    const id = ++this.n;
    this.toasts.update(l => [...l, { id, tipo, texto }]);
    setTimeout(() => this.cerrar(id), ms);
  }
}
