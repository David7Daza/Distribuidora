import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { ToastService } from './toast.service';

/** Respuesta estándar del backend (ResultadoOperacion). */
export interface Resultado<T = any> {
  exito: boolean;
  mensaje: string;
  datos: T;
  capaOrigen: string;
  timestamp: string;
}

@Injectable({ providedIn: 'root' })
export class Api {
  private http = inject(HttpClient);
  private toast = inject(ToastService);
  /** Último mensaje de error devuelto por el servidor (para mostrarlo también dentro de formularios). */
  ultimoError = '';

  private params(p?: Record<string, any>) {
    let hp = new HttpParams();
    for (const [k, v] of Object.entries(p ?? {})) if (v !== null && v !== undefined && v !== '' && v !== false) hp = hp.set(k, String(v));
    return hp;
  }

  /** Consultas de lectura (devuelven los datos directamente). */
  get<T = any>(ruta: string, p?: Record<string, any>) { return firstValueFrom(this.http.get<T>('/api' + ruta, { params: this.params(p) })); }
  /** Igual que get pero para endpoints que devuelven ResultadoOperacion; entrega .datos */
  async datos<T = any>(ruta: string, p?: Record<string, any>): Promise<T> {
    const r = await this.get<Resultado<T>>(ruta, p);
    return r.datos;
  }

  /** Escrituras: muestran el mensaje exacto del servidor (éxito o motivo del rechazo) y devuelven el resultado o null. */
  async accion(metodo: 'post' | 'put' | 'delete', ruta: string, body?: any, silencioExito = false): Promise<Resultado | null> {
    try {
      const r = await firstValueFrom(this.http.request<Resultado>(metodo, '/api' + ruta, { body }));
      if (!silencioExito) this.toast.ok(r.mensaje);
      return r;
    } catch (e: any) {
      if (e.status === 401) return null; // el interceptor ya redirige al login
      const msg = e.error?.mensaje ?? 'No se pudo completar la operación (' + (e.statusText || 'error de red') + ').';
      this.ultimoError = msg;
      this.toast.error(msg);
      return null;
    }
  }
  post(ruta: string, body?: any, silencio = false) { return this.accion('post', ruta, body, silencio); }
  put(ruta: string, body?: any) { return this.accion('put', ruta, body); }
  delete(ruta: string) { return this.accion('delete', ruta); }

  /** Descarga un archivo (CSV) respetando el token de sesión. */
  async descargar(ruta: string, p: Record<string, any> | undefined, nombre: string) {
    try {
      const blob = await firstValueFrom(this.http.get('/api' + ruta, { params: this.params(p), responseType: 'blob' }));
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = nombre; a.click();
      URL.revokeObjectURL(url);
    } catch { this.toast.error('No se pudo descargar el archivo.'); }
  }
}
