import { Injectable, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { Resultado } from './api.service';

export interface Usuario { id: number; nombre: string; email: string; rol: 'ADMIN' | 'VENTAS' | 'BODEGA'; }
const KEY = 'la_dorada_token';

@Injectable({ providedIn: 'root' })
export class Auth {
  private http = inject(HttpClient);
  private router = inject(Router);
  token = signal<string | null>(localStorage.getItem(KEY));
  usuario = signal<Usuario | null>(null);
  permisos = signal<Record<string, boolean>>({});
  logueado = computed(() => !!this.token());

  puede(accion: string) { return !!this.permisos()[accion]; }

  async login(email: string, password: string): Promise<string | null> {
    try {
      const r = await firstValueFrom(this.http.post<Resultado>('/api/auth/login', { email, password }));
      localStorage.setItem(KEY, r.datos.token);
      this.token.set(r.datos.token);
      this.usuario.set(r.datos.usuario);
      this.permisos.set(r.datos.permisos);
      return null;
    } catch (e: any) { return e.error?.mensaje ?? 'No se pudo conectar con el servidor.'; }
  }

  /** Restaura la sesión al recargar la página. */
  async restaurar(): Promise<boolean> {
    if (!this.token()) return false;
    if (this.usuario()) return true;
    try {
      const r = await firstValueFrom(this.http.get<Resultado>('/api/auth/me'));
      this.usuario.set(r.datos.usuario);
      this.permisos.set(r.datos.permisos);
      return true;
    } catch { this.cerrarSesion(false); return false; }
  }

  cerrarSesion(navegar = true) {
    localStorage.removeItem(KEY);
    this.token.set(null); this.usuario.set(null); this.permisos.set({});
    if (navegar) this.router.navigateByUrl('/login');
  }
}
