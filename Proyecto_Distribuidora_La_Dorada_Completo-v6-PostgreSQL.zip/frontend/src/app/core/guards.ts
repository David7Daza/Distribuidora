import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { HttpInterceptorFn } from '@angular/common/http';
import { catchError, throwError } from 'rxjs';
import { Auth } from './auth.service';

export const authGuard: CanActivateFn = async (route) => {
  const auth = inject(Auth), router = inject(Router);
  if (!(await auth.restaurar())) return router.parseUrl('/login');
  const permiso = route.data?.['permiso'];
  if (permiso && !auth.puede(permiso)) return router.parseUrl('/');
  return true;
};

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(Auth);
  const t = auth.token();
  const r = t && req.url.startsWith('/api') ? req.clone({ setHeaders: { Authorization: `Bearer ${t}` } }) : req;
  return next(r).pipe(catchError(e => {
    if (e.status === 401 && !req.url.includes('/auth/login')) auth.cerrarSesion();
    return throwError(() => e);
  }));
};
