import { Component, inject, signal } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Auth } from '../core/auth.service';
import { Api } from '../core/api.service';
import { ModalComponent } from '../shared/modal.component';

@Component({
  selector: 'app-shell',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, FormsModule, ModalComponent],
  template: `
  <div class="marco" [class.movil]="movil()">
   <div class="shell">
    <aside class="lateral" [class.abierto]="menu()">
      <div class="marca"><div class="logo">🧴</div><div><strong>La Dorada</strong><small>Pedidos e Inventario</small></div></div>
      <nav (click)="menu.set(false)">
        <a routerLink="/" routerLinkActive="activo" [routerLinkActiveOptions]="{exact:true}">📊 Panel</a>
        <div class="grupo">Ventas</div>
        @if (auth.puede('registrarPedido')) { <a routerLink="/pedidos/nuevo" routerLinkActive="activo">➕ Nuevo pedido</a> }
        <a routerLink="/pedidos" routerLinkActive="activo" [routerLinkActiveOptions]="{exact:true}">📦 Pedidos</a>
        @if (auth.puede('gestionarClientes')) { <a routerLink="/clientes" routerLinkActive="activo">👥 Clientes</a> }
        <div class="grupo">Inventario</div>
        <a routerLink="/productos" routerLinkActive="activo">🧴 Productos</a>
        @if (auth.puede('editarCatalogo')) { <a routerLink="/categorias" routerLinkActive="activo">🏷️ Categorías</a> }
        <a routerLink="/kardex" routerLinkActive="activo">📒 Kardex</a>
        @if (auth.puede('registrarCompra')) { <a routerLink="/compras" routerLinkActive="activo">🚚 Compras</a> }
        @if (auth.puede('gestionarProveedores')) { <a routerLink="/proveedores" routerLinkActive="activo">🏭 Proveedores</a> }
        @if (auth.puede('verReportes') || auth.puede('gestionarUsuarios')) { <div class="grupo">Administración</div> }
        @if (auth.puede('verReportes')) { <a routerLink="/reportes" routerLinkActive="activo">📈 Reportes</a> }
        @if (auth.puede('gestionarUsuarios')) { <a routerLink="/usuarios" routerLinkActive="activo">🔐 Usuarios</a> }
        @if (auth.puede('verAuditoria')) { <a routerLink="/auditoria" routerLinkActive="activo">🕵️ Auditoría</a> }
      </nav>
      <div class="pie">
        @if (auth.puede('restaurarDatos')) { <button class="btn btn-lateral btn-chico" (click)="restaurar()">♻ Restaurar datos Sección 8</button> }
        <button class="btn btn-lateral btn-chico" (click)="pass.set(true)">🔑 Cambiar contraseña</button>
      </div>
    </aside>
    <div class="fondo-menu" [class.abierto]="menu()" (click)="menu.set(false)"></div>

    <div class="principal">
      <header class="barra">
        <button class="btn btn-icono hamburguesa" (click)="menu.set(!menu())" aria-label="Menú">☰</button>
        <div class="espacio"></div>
        <button class="btn btn-chico" (click)="movil.set(!movil())">📱 <span class="btn-movil-txt">{{ movil() ? 'Vista escritorio' : 'Vista móvil' }}</span></button>
        <div class="quien"><strong>{{ auth.usuario()?.nombre }}</strong><br><small>Rol: {{ auth.usuario()?.rol }}</small></div>
        <button class="btn btn-chico" (click)="auth.cerrarSesion()">Salir</button>
      </header>
      <main class="contenido"><router-outlet /></main>
    </div>

    @if (pass()) {
      <app-modal titulo="Cambiar contraseña" (cerrar)="pass.set(false)">
        <div class="campo"><label>Contraseña actual</label><input type="password" [(ngModel)]="actual"></div>
        <div class="campo"><label>Nueva contraseña (mín. 6 caracteres)</label><input type="password" [(ngModel)]="nueva"></div>
        <div pie><button class="btn" (click)="pass.set(false)">Cancelar</button><button class="btn btn-primario" (click)="cambiarPass()">Guardar</button></div>
      </app-modal>
    }
   </div>
  </div>`
})
export class ShellComponent {
  auth = inject(Auth);
  private api = inject(Api);
  private router = inject(Router);
  menu = signal(false);
  movil = signal(false);
  pass = signal(false);
  actual = ''; nueva = '';

  async restaurar() {
    if (!confirm('¿Restaurar la base de datos a los datos de prueba de la Sección 8? Se borrarán pedidos, clientes y movimientos actuales.')) return;
    const r = await this.api.post('/admin/restaurar-semilla');
    if (r) { await this.router.navigateByUrl('/'); location.reload(); }
  }
  async cambiarPass() {
    const r = await this.api.post('/auth/password', { actual: this.actual, nueva: this.nueva });
    if (r) { this.pass.set(false); this.actual = this.nueva = ''; }
  }
}
