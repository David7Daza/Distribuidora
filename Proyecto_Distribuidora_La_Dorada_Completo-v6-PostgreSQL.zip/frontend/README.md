# Frontend Angular — Distribuidora La Dorada

Aplicación Angular (componentes standalone, signals, rutas con carga perezosa, guards por rol e interceptor JWT).

```bash
npm install
npm start          # http://localhost:4200  (proxy automático de /api hacia http://localhost:3000)
npm run build      # genera dist/frontend/browser  → copiar a ../backend/public
```
Requiere que el backend esté corriendo (`cd ../backend && npm start`).
