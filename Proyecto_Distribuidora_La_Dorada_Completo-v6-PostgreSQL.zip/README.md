# Sistema de Gestión de Pedidos e Inventario — Distribuidora La Dorada S.A.S.

Proyecto Final Integrador — Asignatura: Desarrollo de Sistemas de Información Empresariales.

> **Versión 4.0 — Angular + API REST (Node/Express) + PostgreSQL.**
> Conserva la arquitectura en 4 capas del documento técnico y añade base de datos relacional real,
> autenticación por roles y nuevos módulos. La versión 2 (`index.html` con `localStorage`) sigue incluida y funcionando.

## 0. Qué hay en el proyecto

| Carpeta / archivo | Contenido |
|---|---|
| `frontend/` | Aplicación **Angular 22** (código fuente). |
| `backend/` | API **Node.js + Express + PostgreSQL** (`pg`), en 4 capas. Sirve también el Angular ya compilado (`backend/public`). |
| `backend/database/la_dorada_completo.sql` | Script SQL único (tablas + datos iniciales) para pgAdmin; el backend también lo aplica solo al iniciar. |
| `backend/.env` | Cadena de conexión a PostgreSQL (usuario `postgres`, contraseña `cuesta2016`). |
| `docker-compose.yml` | PostgreSQL 16 listo para usar (opcional). |
| `index.html`, `src/` | Versión 2 original (sin servidor, `localStorage`). |
| `Documento_Tecnico_...docx` | Documento técnico original (v2). |

## 1. Ejecución rápida

Requisitos: **Node.js 20 o superior** y **PostgreSQL 14 o superior** instalado y encendido (con pgAdmin).

**La conexión ya está configurada** en `backend/.env`:
```
DATABASE_URL=postgresql://postgres:cuesta2016@localhost:5432/la_dorada
```
(usuario `postgres`, contraseña `cuesta2016`, servidor `localhost`, puerto `5432`, base `la_dorada`). Si su PostgreSQL usa otro puerto o contraseña, edite solo esa línea.

### Paso a paso en Visual Studio Code
1. Descomprima el zip y abra la carpeta en VS Code (**Archivo → Abrir carpeta**).
2. Abra la terminal (**Ctrl + ñ**) y ejecute:
```bash
cd backend
npm install
npm start
```
3. Abra **http://localhost:3000**. Al primer arranque el sistema **crea solo la base `la_dorada`, las tablas y los datos de la Sección 8**.
   (También puede iniciar con F5: ya existe la configuración en `.vscode/launch.json`.)

### Ver y manejar la base de datos en pgAdmin (una sola base: `la_dorada`)
**Opción 1 — automática (la más fácil):** inicie el sistema (`npm start`). Él crea la base `la_dorada`, las tablas y los datos. En pgAdmin haga clic derecho en *Databases → Refresh* y verá `la_dorada` (*Schemas → public → Tables*).

**Opción 2 — manual con un solo archivo** (`backend/database/la_dorada_completo.sql`):
1. En pgAdmin: clic derecho en *Databases → Create → Database…*, nombre **la_dorada** → Save.
2. Clic derecho en **la_dorada → Query Tool**, pegue **todo** el contenido de `la_dorada_completo.sql` y presione **F5**.
3. Inicie el sistema con `npm start`: se conecta a esa misma base.

**Opción 3 — con Docker:** `docker compose up -d` crea PostgreSQL con la misma contraseña `cuesta2016`.

### Usuarios de prueba
| Rol | Correo | Contraseña |
|---|---|---|
| ADMIN (Gerente) | admin@ladorada.co | admin123 |
| VENTAS (Vendedor) | ventas@ladorada.co | ventas123 |
| BODEGA (Encargada) | bodega@ladorada.co | bodega123 |

## 2. Desarrollo con Angular (recarga en caliente)

```bash
# Terminal 1
cd backend && npm install && npm run dev
# Terminal 2
cd frontend && npm install && npm start     # http://localhost:4200 (proxy /api → :3000)
```
Para regenerar el Angular compilado y copiarlo al backend: `npm run build:frontend` (desde la raíz).

## 3. Base de datos PostgreSQL

Tablas (12): `usuarios`, `categorias`, `proveedores`, `clientes`, `productos`, `pedidos`, `pedido_items`, `pagos`, `compras`, `compra_items`, `movimientos_inventario` (kardex), `auditoria` y las secuencias `seq_pedido` / `seq_compra` (códigos PED-1001…, CMP-1…).

- Llaves foráneas, `UNIQUE` y restricciones `CHECK` (precio > 0, existencias ≥ 0, cantidad > 0, roles y estados válidos): la propia base de datos impide datos inválidos.
- **Transacciones**: confirmar un pedido es atómico (`BEGIN … COMMIT`); si algo falla se hace `ROLLBACK` y el stock queda intacto.
- **Bloqueo de filas (`SELECT … FOR UPDATE`)**: si dos vendedores confirman a la vez pedidos que compiten por las mismas unidades, solo uno lo logra (no hay sobreventa); un doble clic en «Confirmar» descuenta el stock una sola vez.
- Dinero en `NUMERIC(12,2)` (sin errores de redondeo) y fechas en `TIMESTAMP`.
- **Restaurar datos de la Sección 8:** botón «♻ Restaurar datos Sección 8» (ADMIN) o `cd backend && npm run seed`.
- Variables de entorno en `backend/.env`: `DATABASE_URL`, `PORT`, `JWT_SECRET`.

## 4. Novedades respecto a la versión 2

- **Login con JWT y contraseñas cifradas (bcrypt)**: se implementa de verdad el RF-08. Permisos por rol aplicados en el **servidor**, no solo en la interfaz.
- **Clientes**, **proveedores** y **categorías**.
- **Productos** con categoría, proveedor, costo, margen, **stock mínimo con alertas**, ajuste de inventario con motivo y desactivación sin perder historial.
- **Kardex**: cada entrada, salida por pedido, devolución y ajuste queda registrado con usuario y stock resultante.
- **Compras / ingreso de mercancía** que incrementa el inventario y actualiza el costo.
- **Pedidos**: filtros por estado, texto y fechas; detalle con tiempos; el **precio lo toma el servidor** de la base de datos (el cliente no puede alterarlo).
- **Pagos** parciales o totales por método (Efectivo, Transferencia, Nequi…), estado de pago y **cartera por cobrar** (cubre la “consolidación diaria de pagos” de Administración).
- **Panel** con KPIs de la Sección 5.9 (tiempo de confirmación, tasa de rechazo), ventas diarias, más vendidos, mejores clientes y stock bajo.
- **Reportes** (ventas por periodo, por producto, por cliente, cartera, cierre de caja) y **exportación CSV** (compatible con Excel).
- **Auditoría** de quién hizo qué y cuándo; **gestión de usuarios** (el sistema impide dejar al sistema sin administrador).
- **Vista móvil / emulador 390 px** y diseño responsivo (Escenario 3).
- **Pruebas automáticas** de la API: `cd backend && npm test` (15 pruebas: los 3 escenarios, roles, pagos, reportes y concurrencia). Usan una base separada `la_dorada_test` (se crea sola; se puede cambiar con `TEST_DATABASE_URL`).

## 5. Arquitectura (se mantienen las 4 capas)

| Capa | Dónde | Clases |
|---|---|---|
| 1. Dominio | `backend/src/capa1_dominio` | `Producto`, `ItemPedido`, `Pedido`, `ResultadoOperacion` |
| 2. Persistencia | `backend/src/capa2_persistencia` | `StorageDriver` (pool PostgreSQL + transacciones), `ProductoRepository`, `PedidoRepository`, `MaestroRepository`, repositorios de usuarios, kardex, pagos, compras y auditoría |
| 3. Negocio | `backend/src/capa3_servicios_negocio` | `ValidadorReglasNegocio`, `ControlAccesoRolService`, `InventarioService`, `PedidoService`, `AuthService`, `MaestroService`, `ReporteService`, `AuditoriaService` |
| 4. Presentación | `backend/src/capa4_api` + `frontend/` | API REST (Express) y componentes Angular; `BorradorPedido` (carrito) vive en `pedido-nuevo.component.ts` |

Las reglas obligatorias (cantidad > 0, bloqueo por stock insuficiente, descuento único con `stockDescontado`, restitución al rechazar) se mantienen **idénticas** y ahora se ejecutan dentro de transacciones SQL.

## 6. Los tres escenarios de prueba (Sección 8)

Datos iniciales (botón **♻ Restaurar datos Sección 8**, solo ADMIN): ASEO-001 Detergente 20 uds · ASEO-002 Jabón en barra 8 uds · ASEO-003 35 · ASEO-004 14 · ASEO-005 18.

1. **Pedido válido:** ingrese como VENTAS → *Nuevo pedido* → cliente cualquiera, Detergente Líquido Multiusos 1L × 5 → **Validar existencias y CONFIRMAR**. Pedido `Confirmado` y stock 20 → 15 (visible en *Productos* y en *Kardex*).
2. **Pedido inválido:** Jabón en Barra Multiusos 300g × 12 → **CONFIRMAR**. El sistema bloquea, muestra el motivo exacto (Solicitado: 12, Disponible: 8) y el stock sigue en 8; no se crea ningún pedido.
3. **Consulta móvil y persistencia:** botón **📱 Vista móvil**, consulte el pedido; cierre el navegador **e incluso detenga y reinicie el servidor**: los datos siguen en PostgreSQL.

## 7. Endpoints principales (todos bajo `/api`, con `Authorization: Bearer <token>`)

`POST /auth/login` · `GET /dashboard` · `GET/POST/PUT/DELETE /productos` · `POST /productos/:id/ajuste` · `GET /kardex` ·
`GET/POST /compras` · `GET/POST /pedidos` · `POST /pedidos/:id/estado` · `POST /pedidos/:id/pagos` ·
`/clientes`, `/proveedores`, `/categorias` (CRUD) · `/reportes/{ventas,productos,clientes,cartera,cierre-caja}` (`?formato=csv`) ·
`/exportar/productos.csv`, `/exportar/pedidos.csv` · `/usuarios` · `/auditoria` · `POST /admin/restaurar-semilla`.

## 8. Notas para producción

Defina `JWT_SECRET` con un valor largo y secreto, cambie las contraseñas de prueba y la de PostgreSQL, y sirva la aplicación detrás de HTTPS.

---

## Versión 2 (sin servidor) — instrucciones originales

## 1. Requisitos e Instalación
El sistema fue diseñado bajo una arquitectura ligera sin dependencias externas complejas para facilitar su ejecución inmediata durante la sustentación:

### Opción A: Ejecución Directa (Recomendada para demostración rápida)
1. Abra el archivo `index.html` haciendo doble clic desde cualquier navegador moderno (Chrome, Edge, Firefox, Safari).
2. La aplicación carga automáticamente el catálogo inicial con persistencia en `localStorage` (`distribuidora_la_dorada_db_v1`).

### Opción B: Ejecución en Servidor Local (Escritorio y Teléfono en Red Local)
Si desea abrir el sistema desde el computador y el celular al mismo tiempo en la misma red Wi-Fi:
1. Abra una terminal en la carpeta del proyecto.
2. Ejecute: `python -m http.server 8000`
3. En el computador ingrese a `http://localhost:8000` y desde el teléfono a `http://<IP-DEL-PC>:8000`.

## 2. Datos de Prueba Precargados (Alineados con la Sección 8)
Al iniciar el sistema (o al presionar el botón **Restaurar Datos Sección 8**), se cargan los siguientes productos de prueba:
- `ASEO-001` | **Detergente Líquido Multiusos 1L** | Precio: `$9.500` | **Existencias: 20 unidades** (Para Escenario 1).
- `ASEO-002` | **Jabón en Barra Multiusos 300g** | Precio: `$3.800` | **Existencias: 8 unidades** (Para Escenario 2).
- `ASEO-003` | **Hipoclorito Blanqueador Desinfectante 2L** | Precio: `$6.200` | **Existencias: 35 unidades**.
- `ASEO-004` | **Desengrasante Industrial Cocina 1L** | Precio: `$12.000` | **Existencias: 14 unidades**.
- `ASEO-005` | **Ambientador Pisos Lavanda 1L** | Precio: `$7.500` | **Existencias: 18 unidades**.

## 3. Ejecución de los Tres Escenarios de Prueba Obligatorios (Sección 8)
1. **Escenario 1 (Pedido válido):** Seleccione *Detergente Líquido Multiusos 1L* (20 disponibles), ingrese cantidad `5`, agregue al pedido y presione **Validar Existencias y CONFIRMAR Pedido**. Verifique que el pedido pasa a `Confirmado` y el stock baja a `15` una sola vez.
2. **Escenario 2 (Pedido inválido):** Seleccione *Jabón en Barra Multiusos 300g* (8 disponibles), ingrese cantidad `12`, agregue al pedido y presione **Validar Existencias y CONFIRMAR Pedido**. Verifique que el sistema impide la confirmación, muestra el motivo exacto y conserva el stock en `8`.
3. **Escenario 3 (Consulta móvil y persistencia):** Presione el botón **Vista Móvil / Emulador** (o abra las herramientas de desarrollador del navegador en modo dispositivo móvil), consulte el pedido confirmado, cierre la pestaña y vuelva a abrir `index.html` para comprobar que el registro y las existencias permanecen guardados.
