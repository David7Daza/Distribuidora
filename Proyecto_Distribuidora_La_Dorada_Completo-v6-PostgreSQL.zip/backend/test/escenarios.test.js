// Pruebas automáticas: los 3 escenarios obligatorios de la Sección 8 + reglas ampliadas
import test from 'node:test';
import assert from 'node:assert/strict';
import { StorageDriver } from '../src/capa2_persistencia/Database.js';
import { crearContenedor } from '../src/capa4_api/contenedor.js';
import { crearApp } from '../src/capa4_api/app.js';

// Usa una base de datos de pruebas separada (se borra y se siembra al iniciar)
const driver = await StorageDriver.crear({ connectionString: process.env.TEST_DATABASE_URL || 'postgresql://postgres:cuesta2016@localhost:5432/la_dorada_test' });
await driver.restaurarSemilla();
const app = crearApp(crearContenedor(driver));
const server = app.listen(0);
const base = `http://127.0.0.1:${server.address().port}/api`;
const tokens = {};
const api = async (m, ruta, body, rol = 'ADMIN') => {
  const r = await fetch(base + ruta, { method: m, headers: { 'Content-Type': 'application/json', ...(tokens[rol] ? { Authorization: 'Bearer ' + tokens[rol] } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, body: await r.json() };
};
const stock = async id => (await api('GET', '/productos')).body.find(p => p.id === id).existencias;

test.before(async () => {
  for (const [rol, email, pw] of [['ADMIN', 'admin@ladorada.co', 'admin123'], ['VENTAS', 'ventas@ladorada.co', 'ventas123'], ['BODEGA', 'bodega@ladorada.co', 'bodega123']]) {
    tokens[rol] = (await api('POST', '/auth/login', { email, password: pw }, null)).body.datos.token;
  }
});
test.after(async () => { server.close(); await driver.cerrar(); });

test('sin token => 401', async () => assert.equal((await api('GET', '/productos', null, null)).status, 401));
test('login incorrecto => 401', async () => assert.equal((await api('POST', '/auth/login', { email: 'admin@ladorada.co', password: 'x' }, null)).status, 401));

test('Escenario 1: pedido válido descuenta 20 -> 15 una sola vez', async () => {
  const r = await api('POST', '/pedidos', { clienteId: 1, items: [{ productoId: 1, cantidad: 5 }], confirmarInmediatamente: true }, 'VENTAS');
  assert.equal(r.status, 201);
  assert.equal(r.body.datos.estado, 'Confirmado');
  assert.equal(await stock(1), 15);
  // idempotencia: reconfirmar es rechazado y el stock no cambia
  const again = await api('POST', `/pedidos/${r.body.datos.id}/estado`, { estado: 'Confirmado' }, 'VENTAS');
  assert.equal(again.status, 409);
  assert.equal(await stock(1), 15);
});

test('Escenario 2: pedido inválido (12 > 8) bloquea y deja stock en 8', async () => {
  const r = await api('POST', '/pedidos', { clienteId: 2, items: [{ productoId: 2, cantidad: 12 }], confirmarInmediatamente: true }, 'VENTAS');
  assert.equal(r.status, 400);
  assert.match(r.body.mensaje, /INVENTARIO INSUFICIENTE/);
  assert.equal(await stock(2), 8);
  assert.equal((await api('GET', '/pedidos?buscar=Sabor')).body.length, 0); // no se creó pedido
});

test('cantidad <= 0 es rechazada', async () => {
  const r = await api('POST', '/pedidos', { clienteId: 1, items: [{ productoId: 1, cantidad: 0 }] }, 'VENTAS');
  assert.equal(r.status, 400);
});

test('Escenario 3: persistencia en base de datos (pedido y stock se conservan)', async () => {
  const lista = (await api('GET', '/pedidos')).body;
  assert.equal(lista.length, 1);
  assert.equal(lista[0].total, 47500);
});

test('rechazar pedido confirmado restituye inventario; despachado no se puede rechazar', async () => {
  const p = (await api('POST', '/pedidos', { clienteId: 3, items: [{ productoId: 3, cantidad: 10 }], confirmarInmediatamente: true }, 'VENTAS')).body.datos;
  assert.equal(await stock(3), 25);
  await api('POST', `/pedidos/${p.id}/estado`, { estado: 'Rechazado' }, 'VENTAS');
  assert.equal(await stock(3), 35);
  const p2 = (await api('POST', '/pedidos', { clienteId: 3, items: [{ productoId: 3, cantidad: 1 }], confirmarInmediatamente: true }, 'VENTAS')).body.datos;
  assert.equal((await api('POST', `/pedidos/${p2.id}/estado`, { estado: 'Despachado' }, 'BODEGA')).status, 200);
  assert.equal((await api('POST', `/pedidos/${p2.id}/estado`, { estado: 'Rechazado' }, 'ADMIN')).status, 409);
  assert.equal(await stock(3), 34);
});

test('roles: ventas no edita catálogo ni despacha; bodega no registra pedidos', async () => {
  assert.equal((await api('POST', '/productos', { referencia: 'X', nombre: 'X', precio: 1 }, 'VENTAS')).status, 403);
  const p = (await api('POST', '/pedidos', { clienteId: 1, items: [{ productoId: 4, cantidad: 1 }], confirmarInmediatamente: true }, 'VENTAS')).body.datos;
  assert.equal((await api('POST', `/pedidos/${p.id}/estado`, { estado: 'Despachado' }, 'VENTAS')).status, 403);
  assert.equal((await api('POST', '/pedidos', { clienteId: 1, items: [{ productoId: 4, cantidad: 1 }] }, 'BODEGA')).status, 403);
  assert.equal((await api('GET', '/usuarios', null, 'BODEGA')).status, 403);
});

test('el precio lo define el servidor, no el cliente', async () => {
  const r = await api('POST', '/pedidos', { clienteId: 1, items: [{ productoId: 5, cantidad: 2, precioUnitario: 1 }] }, 'VENTAS');
  assert.equal(r.body.datos.total, 15000);
});

test('compras incrementan stock y quedan en el kardex', async () => {
  const antes = await stock(5);
  const r = await api('POST', '/compras', { proveedorId: 1, items: [{ productoId: 5, cantidad: 30, costoUnitario: 4700 }] }, 'BODEGA');
  assert.equal(r.status, 201);
  assert.equal(await stock(5), antes + 30);
  const k = (await api('GET', '/kardex?productoId=5')).body;
  assert.equal(k[0].tipo, 'ENTRADA_COMPRA');
});

test('pagos: parcial, total y no exceder el saldo', async () => {
  const p = (await api('POST', '/pedidos', { clienteId: 4, items: [{ productoId: 4, cantidad: 2 }], confirmarInmediatamente: true }, 'VENTAS')).body.datos; // 24000
  assert.equal((await api('POST', `/pedidos/${p.id}/pagos`, { monto: 10000 }, 'VENTAS')).status, 403);
  assert.equal((await api('POST', `/pedidos/${p.id}/pagos`, { monto: 10000, metodo: 'Nequi' })).body.datos.estadoPago, 'Parcial');
  assert.equal((await api('POST', `/pedidos/${p.id}/pagos`, { monto: 20000 })).status, 409);
  assert.equal((await api('POST', `/pedidos/${p.id}/pagos`, { monto: 14000 })).body.datos.estadoPago, 'Pagado');
});

test('dashboard, reportes y auditoría responden', async () => {
  const d = (await api('GET', '/dashboard')).body.datos;
  assert.ok(d.ventasDiarias.length === 14 && d.resumen.total > 0);
  assert.equal((await api('GET', '/reportes/ventas')).status, 200);
  assert.equal((await api('GET', '/reportes/ventas', null, 'VENTAS')).status, 403);
  assert.ok((await api('GET', '/auditoria')).body.length > 5);
});

test('concurrencia: dos confirmaciones simultáneas no pueden sobrevender el stock', async () => {
  await api('POST', '/admin/restaurar-semilla'); // ASEO-002 vuelve a 8 unidades
  tokens.VENTAS = (await api('POST', '/auth/login', { email: 'ventas@ladorada.co', password: 'ventas123' }, null)).body.datos.token;
  tokens.ADMIN = (await api('POST', '/auth/login', { email: 'admin@ladorada.co', password: 'admin123' }, null)).body.datos.token;
  const pedir = () => api('POST', '/pedidos', { clienteId: 1, items: [{ productoId: 2, cantidad: 5 }], confirmarInmediatamente: true }, 'VENTAS');
  const resultados = await Promise.all([pedir(), pedir(), pedir()]);
  assert.equal(resultados.filter(r => r.status === 201).length, 1);   // solo cabe un pedido de 5 con 8 en stock
  assert.equal(resultados.filter(r => r.status === 400).length, 2);
  assert.equal(await stock(2), 3);
});

test('doble clic en Confirmar un pedido Pendiente descuenta el stock una sola vez', async () => {
  const p = (await api('POST', '/pedidos', { clienteId: 1, items: [{ productoId: 1, cantidad: 4 }] }, 'VENTAS')).body.datos; // Pendiente
  const antes = await stock(1);
  const r = await Promise.all([1, 2].map(() => api('POST', `/pedidos/${p.id}/estado`, { estado: 'Confirmado' }, 'VENTAS')));
  assert.deepEqual(r.map(x => x.status).sort(), [200, 409]);
  assert.equal(await stock(1), antes - 4);
});

test('todos los reportes funcionan con datos y exportan CSV', async () => {
  const p = (await api('POST', '/pedidos', { clienteId: 2, items: [{ productoId: 4, cantidad: 3 }], confirmarInmediatamente: true }, 'VENTAS')).body.datos;
  await api('POST', `/pedidos/${p.id}/pagos`, { monto: 10000, metodo: 'Efectivo' });
  for (const ruta of ['ventas', 'ventas?agrupar=mes', 'productos', 'clientes', 'cartera', 'cierre-caja']) {
    const r = await api('GET', '/reportes/' + ruta);
    assert.equal(r.status, 200, ruta);
  }
  const cartera = (await api('GET', '/reportes/cartera')).body.datos;
  assert.ok(cartera.some(f => f.saldo === 26000));
  const caja = (await api('GET', '/reportes/cierre-caja')).body.datos;
  assert.equal(caja.total, 10000);
  const ventas = (await api('GET', '/reportes/ventas')).body.datos;
  assert.ok(ventas[0].utilidad > 0);
  const d = (await api('GET', '/dashboard')).body.datos;
  assert.ok(d.kpis.tiempoConfirmacionMin !== null && d.ventasHoy.n > 0 && d.topProductos.length > 0);
  const r = await fetch(base + '/reportes/ventas?formato=csv', { headers: { Authorization: 'Bearer ' + tokens.ADMIN } });
  assert.match(r.headers.get('content-type'), /text\/csv/);
});
