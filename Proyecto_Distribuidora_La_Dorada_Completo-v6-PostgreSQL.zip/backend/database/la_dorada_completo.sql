-- =====================================================================
-- DISTRIBUIDORA LA DORADA S.A.S. — BASE DE DATOS COMPLETA (UN SOLO ARCHIVO)
-- Una sola base de datos: la_dorada
--
-- Cómo usarlo en pgAdmin:
--   1) Clic derecho en "Databases" -> Create -> Database... -> nombre: la_dorada -> Save.
--   2) Clic derecho en la_dorada -> Query Tool -> pegue TODO este archivo -> F5.
-- Crea las 12 tablas y carga los datos iniciales. Se puede ejecutar varias veces sin duplicar datos.
-- (Si prefiere no hacer nada de esto: al iniciar el sistema con "npm start" este mismo
--  archivo se aplica solo y la base se crea automáticamente.)
-- =====================================================================

CREATE TABLE IF NOT EXISTS usuarios (
  id            INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  nombre        TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  rol           TEXT NOT NULL CHECK (rol IN ('ADMIN','VENTAS','BODEGA')),
  activo        INTEGER NOT NULL DEFAULT 1,
  creado        TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP(0)
);

CREATE TABLE IF NOT EXISTS categorias (
  id     INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  nombre TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS proveedores (
  id        INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  nombre    TEXT NOT NULL,
  nit       TEXT, telefono TEXT, email TEXT, direccion TEXT,
  activo    INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS clientes (
  id        INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  nombre    TEXT NOT NULL,
  nit       TEXT, telefono TEXT, email TEXT, direccion TEXT, ciudad TEXT,
  tipo      TEXT NOT NULL DEFAULT 'Tienda',
  activo    INTEGER NOT NULL DEFAULT 1,
  creado    TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP(0)
);

CREATE TABLE IF NOT EXISTS productos (
  id            INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  referencia    TEXT NOT NULL UNIQUE,
  nombre        TEXT NOT NULL,
  categoria_id  INTEGER REFERENCES categorias(id),
  proveedor_id  INTEGER REFERENCES proveedores(id),
  precio        NUMERIC(12,2) NOT NULL CHECK (precio > 0),
  costo         NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (costo >= 0),
  existencias   INTEGER NOT NULL DEFAULT 0 CHECK (existencias >= 0),
  stock_minimo  INTEGER NOT NULL DEFAULT 5 CHECK (stock_minimo >= 0),
  activo        INTEGER NOT NULL DEFAULT 1
);

CREATE SEQUENCE IF NOT EXISTS seq_pedido START 1001;
CREATE SEQUENCE IF NOT EXISTS seq_compra START 1;

CREATE TABLE IF NOT EXISTS pedidos (
  id               INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  codigo           TEXT NOT NULL UNIQUE,
  cliente_id       INTEGER REFERENCES clientes(id),
  cliente_nombre   TEXT NOT NULL,
  nota             TEXT NOT NULL DEFAULT 'WhatsApp',
  estado           TEXT NOT NULL DEFAULT 'Pendiente' CHECK (estado IN ('Pendiente','Confirmado','Despachado','Rechazado')),
  stock_descontado INTEGER NOT NULL DEFAULT 0,
  total            NUMERIC(14,2) NOT NULL DEFAULT 0,
  vendedor_id      INTEGER REFERENCES usuarios(id),
  creado           TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP(0),
  confirmado       TIMESTAMP,
  despachado       TIMESTAMP
);

CREATE TABLE IF NOT EXISTS pedido_items (
  id              INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  pedido_id       INTEGER NOT NULL REFERENCES pedidos(id) ON DELETE CASCADE,
  producto_id     INTEGER NOT NULL REFERENCES productos(id),
  referencia      TEXT NOT NULL,
  nombre          TEXT NOT NULL,
  precio_unitario NUMERIC(12,2) NOT NULL,
  cantidad        INTEGER NOT NULL CHECK (cantidad > 0)
);

CREATE TABLE IF NOT EXISTS pagos (
  id          INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  pedido_id   INTEGER NOT NULL REFERENCES pedidos(id) ON DELETE CASCADE,
  monto       NUMERIC(14,2) NOT NULL CHECK (monto > 0),
  metodo      TEXT NOT NULL DEFAULT 'Efectivo',
  usuario_id  INTEGER REFERENCES usuarios(id),
  fecha       TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP(0)
);

CREATE TABLE IF NOT EXISTS compras (
  id            INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  codigo        TEXT NOT NULL UNIQUE,
  proveedor_id  INTEGER REFERENCES proveedores(id),
  total         NUMERIC(14,2) NOT NULL DEFAULT 0,
  nota          TEXT,
  usuario_id    INTEGER REFERENCES usuarios(id),
  fecha         TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP(0)
);

CREATE TABLE IF NOT EXISTS compra_items (
  id              INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  compra_id       INTEGER NOT NULL REFERENCES compras(id) ON DELETE CASCADE,
  producto_id     INTEGER NOT NULL REFERENCES productos(id),
  cantidad        INTEGER NOT NULL CHECK (cantidad > 0),
  costo_unitario  NUMERIC(12,2) NOT NULL CHECK (costo_unitario >= 0)
);

CREATE TABLE IF NOT EXISTS movimientos_inventario (
  id                INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  producto_id       INTEGER NOT NULL REFERENCES productos(id),
  tipo              TEXT NOT NULL CHECK (tipo IN ('ENTRADA_COMPRA','SALIDA_PEDIDO','DEVOLUCION_PEDIDO','AJUSTE','INICIAL')),
  cantidad          INTEGER NOT NULL,
  stock_resultante  INTEGER NOT NULL,
  referencia        TEXT,
  nota              TEXT,
  usuario_id        INTEGER REFERENCES usuarios(id),
  fecha             TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP(0)
);

CREATE TABLE IF NOT EXISTS auditoria (
  id              INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  usuario_id      INTEGER REFERENCES usuarios(id),
  usuario_nombre  TEXT,
  accion          TEXT NOT NULL,
  entidad         TEXT NOT NULL,
  entidad_id      TEXT,
  detalle         TEXT,
  fecha           TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP(0)
);

CREATE INDEX IF NOT EXISTS idx_pedidos_estado  ON pedidos(estado);
CREATE INDEX IF NOT EXISTS idx_pedidos_cliente ON pedidos(cliente_id);
CREATE INDEX IF NOT EXISTS idx_items_pedido    ON pedido_items(pedido_id);
CREATE INDEX IF NOT EXISTS idx_mov_producto    ON movimientos_inventario(producto_id);
CREATE INDEX IF NOT EXISTS idx_pagos_pedido    ON pagos(pedido_id);


-- =====================================================================
-- DATOS INICIALES (Sección 8 del documento técnico)
-- Solo se insertan si la tabla de usuarios está vacía (se puede ejecutar varias veces sin duplicar).
-- Contraseñas (cifradas con bcrypt): admin123 / ventas123 / bodega123
-- =====================================================================
DO $$
BEGIN
  IF (SELECT COUNT(*) FROM usuarios) = 0 THEN
    INSERT INTO usuarios (nombre, email, password_hash, rol) VALUES
      ('Gerente La Dorada',   'admin@ladorada.co',  '$2b$10$CxWA2.xCYYtfkJ.sb7dTKeUfoZpmr5ZjAc9o7wev9LdigNQ9Jn1pK',  'ADMIN'),
      ('Vendedor 1',          'ventas@ladorada.co', '$2b$10$THwU9aKs3GfEeAqN2HE4qeAmDc7H9TB3yJRyarIVp4AJvDWrKy1La', 'VENTAS'),
      ('Encargada de Bodega', 'bodega@ladorada.co', '$2b$10$2boPnIASUTe.m1aLP/6EUuKi3632KoiwdHNRAJCxMCf4IhUGN531C', 'BODEGA');

    INSERT INTO categorias (nombre) VALUES ('Detergentes'),('Jabones'),('Desinfectantes'),('Desengrasantes'),('Ambientadores');

    INSERT INTO proveedores (nombre, nit, telefono, email, direccion) VALUES
      ('Químicos del Valle S.A.S.',   '900.123.456-1', '3101234567', 'ventas@quimicosdelvalle.co', 'Cali, Valle del Cauca'),
      ('Distribuciones Andinas Ltda.', '800.765.432-9', '3207654321', 'pedidos@andinas.co',         'Yumbo, Valle del Cauca');

    INSERT INTO productos (referencia, nombre, categoria_id, proveedor_id, precio, costo, existencias, stock_minimo) VALUES
      ('ASEO-001', 'Detergente Líquido Multiusos 1L',            1, 1,  9500, 6200, 20,  8),
      ('ASEO-002', 'Jabón en Barra Multiusos 300g',              2, 1,  3800, 2300,  8, 10),
      ('ASEO-003', 'Hipoclorito Blanqueador Desinfectante 2L',   3, 2,  6200, 3900, 35, 10),
      ('ASEO-004', 'Desengrasante Industrial Cocina 1L',         4, 2, 12000, 7800, 14,  6),
      ('ASEO-005', 'Ambientador Pisos Lavanda 1L',               5, 1,  7500, 4600, 18,  6);

    INSERT INTO movimientos_inventario (producto_id, tipo, cantidad, stock_resultante, referencia, nota)
      SELECT id, 'INICIAL', existencias, existencias, 'SEMILLA', 'Carga inicial de inventario' FROM productos ORDER BY id;

    INSERT INTO clientes (nombre, nit, telefono, email, direccion, ciudad, tipo) VALUES
      ('Tienda La Esquina',          '900.111.222-3', '3001112233', 'laesquina@correo.co',      'Cra 8 # 12-30',  'Cali', 'Tienda'),
      ('Restaurante Sabor Criollo',  '901.333.444-5', '3014445566', 'compras@saborcriollo.co',  'Av 6N # 25-10',  'Cali', 'Restaurante'),
      ('Minimercado El Vecino',      '900.555.666-7', '3025556677', 'elvecino@correo.co',       'Cll 5 # 40-22',  'Cali', 'Minimercado'),
      ('Cafetería Aroma',            '901.777.888-9', '3036667788', 'aroma@correo.co',          'Cra 100 # 15-05','Cali', 'Restaurante');
  END IF;
END $$;
