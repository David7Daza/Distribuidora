import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Carga opcional de backend/.env (sin dependencias externas)
const envFile = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '.env');
if (fs.existsSync(envFile)) {
  for (const l of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/i);
    if (m && !l.trim().startsWith('#') && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}

const { StorageDriver, URL_POR_DEFECTO } = await import('./capa2_persistencia/Database.js');
const { crearContenedor } = await import('./capa4_api/contenedor.js');
const { crearApp } = await import('./capa4_api/app.js');

const PUERTO = process.env.PORT || 3000;
let driver;
try {
  driver = await StorageDriver.crear();
} catch (e) {
  console.error('\n  ✖ No se pudo conectar a PostgreSQL.');
  console.error(`    Intentando con: ${(process.env.DATABASE_URL || URL_POR_DEFECTO).replace(/:\/\/([^:]+):[^@]*@/, '://$1:****@')}`);
  console.error(`    Motivo: ${e.code || ''} ${e.message}`);
  console.error('    Soluciones: 1) inicie PostgreSQL (o use "docker compose up -d" en la raíz del proyecto);');
  console.error('                2) copie backend/.env.example a backend/.env y ajuste DATABASE_URL con su usuario/contraseña.\n');
  process.exit(1);
}
crearApp(crearContenedor(driver)).listen(PUERTO, '0.0.0.0', () => {
  console.log(`\n  Distribuidora La Dorada — API y aplicación web`);
  console.log(`  Base de datos PostgreSQL: ${driver.archivo}`);
  console.log(`  Abra: http://localhost:${PUERTO}\n`);
  console.log(`  Usuarios de prueba:  admin@ladorada.co / admin123   ventas@ladorada.co / ventas123   bodega@ladorada.co / bodega123\n`);
});
