// CAPA 4: API - Aplicación Express (rutas REST). Convierte ResultadoOperacion en respuestas HTTP.
import express from 'express';
import cors from 'cors';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const enviar = (res, r) => res.status(r.http).json(r.aJSON());
const csv = (res, nombre, filas) => {
  const cols = filas.length ? Object.keys(filas[0]) : [];
  const esc = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const texto = [cols.join(','), ...filas.map(f => cols.map(c => esc(f[c])).join(','))].join('\n');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${nombre}.csv"`);
  res.send('\uFEFF' + texto); // BOM para que Excel respete tildes
};
const q = req => req.query;
const bool = v => v === '1' || v === 'true';

export function crearApp(c) {
  const app = express();
  app.use(cors());
  app.use(express.json({ limit: '1mb' }));

  // ---------- Salud y autenticación ----------
  app.get('/api/salud', async (_req, res) => {
    await c.driver.uno('SELECT 1 AS ok');
    res.json({ ok: true, baseDeDatos: 'PostgreSQL', hora: new Date().toISOString() });
  });
  app.post('/api/auth/login', async (req, res) => enviar(res, await c.auth.login(req.body?.email, req.body?.password)));

  // Middleware de autenticación para todo lo demás
  app.use('/api', async (req, res, next) => {
    const h = req.headers.authorization || '';
    const usuario = h.startsWith('Bearer ') ? await c.auth.verificarToken(h.slice(7)) : null;
    if (!usuario) return res.status(401).json({ exito: false, mensaje: 'Sesión no válida o expirada. Inicie sesión.', capaOrigen: 'Auth' });
    req.ctx = { usuario };
    next();
  });

  app.get('/api/auth/me', (req, res) => enviar(res, c.auth.perfil(req.ctx.usuario)));
  app.post('/api/auth/password', async (req, res) => enviar(res, await c.auth.cambiarPropiaPassword(req.ctx, req.body?.actual, req.body?.nueva)));

  // ---------- Dashboard ----------
  app.get('/api/dashboard', async (_req, res) => enviar(res, await c.reportes.dashboard()));

  // ---------- Productos / inventario ----------
  app.get('/api/productos', async (req, res) => res.json(await c.inventario.consultarCatalogo({
    buscar: q(req).buscar, categoriaId: q(req).categoriaId, bajoStock: bool(q(req).bajoStock), incluirInactivos: bool(q(req).inactivos)
  })));
  app.post('/api/productos', async (req, res) => enviar(res, await c.inventario.guardarProducto(req.body, req.ctx)));
  app.put('/api/productos/:id', async (req, res) => enviar(res, await c.inventario.guardarProducto({ ...req.body, id: Number(req.params.id) }, req.ctx)));
  app.delete('/api/productos/:id', async (req, res) => enviar(res, await c.inventario.desactivarProducto(req.params.id, req.ctx)));
  app.post('/api/productos/:id/ajuste', async (req, res) => enviar(res, await c.inventario.ajustarStock(req.params.id, req.body?.existencias, req.body?.nota, req.ctx)));
  app.get('/api/kardex', async (req, res) => res.json(await c.inventario.consultarKardex({ productoId: q(req).productoId, tipo: q(req).tipo })));

  // ---------- Compras ----------
  app.get('/api/compras', async (_req, res) => res.json(await c.inventario.listarCompras()));
  app.get('/api/compras/:id', async (req, res) => enviar(res, await c.inventario.obtenerCompra(req.params.id)));
  app.post('/api/compras', async (req, res) => enviar(res, await c.inventario.registrarCompra(req.body, req.ctx)));

  // ---------- Pedidos ----------
  app.get('/api/pedidos/resumen', async (_req, res) => res.json(await c.pedidos.obtenerResumenPorEstado()));
  app.get('/api/pedidos', async (req, res) => res.json((await c.pedidos.listarPedidos({
    estado: q(req).estado, buscar: q(req).buscar, clienteId: q(req).clienteId, desde: q(req).desde, hasta: q(req).hasta
  })).map(p => ({ ...p, saldo: p.saldoPendiente(), estadoPago: p.estadoPago() }))));
  app.get('/api/pedidos/:id', async (req, res) => enviar(res, await c.pedidos.obtenerPedido(req.params.id)));
  app.post('/api/pedidos', async (req, res) => enviar(res, await c.pedidos.registrarPedido(req.body, req.ctx)));
  app.post('/api/pedidos/:id/estado', async (req, res) => enviar(res, await c.pedidos.cambiarEstadoPedido(req.params.id, req.body?.estado, req.ctx)));
  app.post('/api/pedidos/:id/pagos', async (req, res) => enviar(res, await c.pedidos.registrarPago(req.params.id, req.body || {}, req.ctx)));

  // ---------- Maestros: clientes, proveedores, categorías ----------
  for (const [ruta, svc] of [['clientes', c.clientes], ['proveedores', c.proveedores], ['categorias', c.categorias]]) {
    app.get(`/api/${ruta}`, async (req, res) => res.json(await svc.listar({ buscar: q(req).buscar, incluirInactivos: bool(q(req).inactivos) })));
    app.get(`/api/${ruta}/:id`, async (req, res) => enviar(res, await svc.obtener(req.params.id)));
    app.post(`/api/${ruta}`, async (req, res) => enviar(res, await svc.guardar(null, req.body, req.ctx)));
    app.put(`/api/${ruta}/:id`, async (req, res) => enviar(res, await svc.guardar(req.params.id, req.body, req.ctx)));
    app.delete(`/api/${ruta}/:id`, async (req, res) => enviar(res, await svc.eliminar(req.params.id, req.ctx)));
  }

  // ---------- Reportes (ADMIN) ----------
  const reporte = (ruta, fn, nombreCsv) => app.get(`/api/reportes/${ruta}`, async (req, res) => {
    const r = await fn(q(req), req.ctx);
    if (!r.exito) return enviar(res, r);
    if (q(req).formato === 'csv') return csv(res, nombreCsv, Array.isArray(r.datos) ? r.datos : r.datos.pagos || []);
    enviar(res, r);
  });
  reporte('ventas', (p, ctx) => c.reportes.ventas(p, ctx), 'ventas');
  reporte('productos', (p, ctx) => c.reportes.ventasPorProducto(p, ctx), 'ventas_por_producto');
  reporte('clientes', (p, ctx) => c.reportes.ventasPorCliente(p, ctx), 'ventas_por_cliente');
  reporte('cierre-caja', (p, ctx) => c.reportes.cierreCaja(p, ctx), 'cierre_caja');
  reporte('cartera', (_p, ctx) => c.reportes.cuentasPorCobrar(ctx), 'cuentas_por_cobrar');

  // Exportaciones CSV de listados operativos
  app.get('/api/exportar/productos.csv', async (_req, res) => csv(res, 'productos', (await c.inventario.consultarCatalogo({ incluirInactivos: true }))
    .map(p => ({ referencia: p.referencia, nombre: p.nombre, categoria: p.categoria, proveedor: p.proveedor, precio: p.precio, costo: p.costo, existencias: p.existencias, stock_minimo: p.stockMinimo, activo: p.activo ? 'Sí' : 'No' }))));
  app.get('/api/exportar/pedidos.csv', async (_req, res) => csv(res, 'pedidos', (await c.pedidos.listarPedidos({}))
    .map(p => ({ codigo: p.codigo, fecha: p.fecha, cliente: p.cliente, canal: p.nota, estado: p.estado, total: p.total, pagado: p.pagado, saldo: p.saldoPendiente(), vendedor: p.vendedor }))));

  // ---------- Administración ----------
  app.get('/api/usuarios', async (req, res) => enviar(res, await c.auth.listarUsuarios(req.ctx)));
  app.post('/api/usuarios', async (req, res) => enviar(res, await c.auth.crearUsuario(req.body, req.ctx)));
  app.put('/api/usuarios/:id', async (req, res) => enviar(res, await c.auth.actualizarUsuario(req.params.id, req.body, req.ctx)));
  app.get('/api/auditoria', async (req, res) => {
    const p = c.seguridad.verificarPermiso(req.ctx.usuario.rol, 'verAuditoria');
    if (!p.exito) return enviar(res, p);
    res.json(await c.auditoria.listar({ entidad: q(req).entidad }));
  });
  app.post('/api/admin/restaurar-semilla', async (req, res) => {
    const p = c.seguridad.verificarPermiso(req.ctx.usuario.rol, 'restaurarDatos');
    if (!p.exito) return enviar(res, p);
    await c.driver.restaurarSemilla();
    res.json({ exito: true, mensaje: 'Base de datos restaurada con los datos de prueba de la Sección 8.', capaOrigen: 'Admin' });
  });

  app.use('/api', (_req, res) => res.status(404).json({ exito: false, mensaje: 'Ruta de API no encontrada.', capaOrigen: 'API' }));

  // ---------- Frontend Angular compilado (carpeta public/) ----------
  const publico = path.join(__dirname, '..', '..', 'public');
  if (fs.existsSync(path.join(publico, 'index.html'))) {
    app.use(express.static(publico));
    app.get(/^(?!\/api).*/, (_req, res) => res.sendFile(path.join(publico, 'index.html')));
  }

  // Manejo de errores inesperados (los fallos de negocio ya viajan como ResultadoOperacion)
  app.use((err, _req, res, _next) => {
    console.error(err);
    res.status(500).json({ exito: false, mensaje: 'Error interno del servidor: ' + err.message, capaOrigen: 'API' });
  });
  return app;
}
