// CAPA 4: API - Composición de dependencias (inyección por constructor)
import { StorageDriver } from '../capa2_persistencia/Database.js';
import { ProductoRepository } from '../capa2_persistencia/ProductoRepository.js';
import { PedidoRepository } from '../capa2_persistencia/PedidoRepository.js';
import { MaestroRepository } from '../capa2_persistencia/MaestroRepository.js';
import { UsuarioRepository, MovimientoRepository, PagoRepository, CompraRepository, AuditoriaRepository } from '../capa2_persistencia/OtrosRepositories.js';
import { ControlAccesoRolService } from '../capa3_servicios_negocio/ControlAccesoRolService.js';
import { ValidadorReglasNegocio } from '../capa3_servicios_negocio/ValidadorReglasNegocio.js';
import { AuditoriaService } from '../capa3_servicios_negocio/AuditoriaService.js';
import { InventarioService } from '../capa3_servicios_negocio/InventarioService.js';
import { PedidoService } from '../capa3_servicios_negocio/PedidoService.js';
import { AuthService } from '../capa3_servicios_negocio/AuthService.js';
import { MaestroService } from '../capa3_servicios_negocio/MaestroService.js';
import { ReporteService } from '../capa3_servicios_negocio/ReporteService.js';

/** Recibe un StorageDriver ya conectado (use await StorageDriver.crear()). */
export function crearContenedor(driver) {
  const seguridad = new ControlAccesoRolService();
  const validador = new ValidadorReglasNegocio();
  const auditoria = new AuditoriaService(new AuditoriaRepository(driver));

  const productoRepo = new ProductoRepository(driver);
  const pedidoRepo = new PedidoRepository(driver);
  const usuarioRepo = new UsuarioRepository(driver);
  const movimientoRepo = new MovimientoRepository(driver);
  const pagoRepo = new PagoRepository(driver);
  const compraRepo = new CompraRepository(driver);
  const clienteRepo = new MaestroRepository(driver, 'clientes', ['nombre', 'nit', 'telefono', 'email', 'direccion', 'ciudad', 'tipo'], ['nombre', 'nit', 'telefono', 'ciudad']);
  const proveedorRepo = new MaestroRepository(driver, 'proveedores', ['nombre', 'nit', 'telefono', 'email', 'direccion'], ['nombre', 'nit']);
  const categoriaRepo = new MaestroRepository(driver, 'categorias', ['nombre'], ['nombre'], { softDelete: false });

  const inventario = new InventarioService({ driver, productoRepo, movimientoRepo, compraRepo, proveedorRepo, seguridad, auditoria });
  const pedidos = new PedidoService({ driver, pedidoRepo, productoRepo, clienteRepo, pagoRepo, inventarioService: inventario, validador, seguridad, auditoria });
  const auth = new AuthService({ usuarioRepo, seguridad, validador, auditoria });
  const reportes = new ReporteService({ driver, pedidoService: pedidos, seguridad });
  const maestro = (repo, nombreEntidad, permiso) => new MaestroService({ repo, nombreEntidad, permiso, validador, seguridad, auditoria });

  return {
    driver, seguridad, validador, auditoria, inventario, pedidos, auth, reportes,
    clientes: maestro(clienteRepo, 'cliente', 'gestionarClientes'),
    proveedores: maestro(proveedorRepo, 'proveedor', 'gestionarProveedores'),
    categorias: maestro(categoriaRepo, 'categoría', 'editarCatalogo')
  };
}
