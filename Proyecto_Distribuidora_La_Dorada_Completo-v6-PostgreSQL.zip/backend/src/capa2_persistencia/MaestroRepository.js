// CAPA 2: PERSISTENCIA - Repositorio genérico para tablas maestras simples (clientes, proveedores, categorías)
export class MaestroRepository {
  /** @param tabla nombre de la tabla  @param columnas columnas editables  @param buscables columnas para ILIKE */
  constructor(driver, tabla, columnas, buscables, { softDelete = true } = {}) {
    this.db = driver;
    this.tabla = tabla;
    this.columnas = columnas;
    this.buscables = buscables;
    this.softDelete = softDelete;
  }
  listar({ buscar = '', incluirInactivos = false } = {}) {
    const where = [], params = [];
    if (this.softDelete && !incluirInactivos) where.push('activo = 1');
    if (buscar) {
      where.push('(' + this.buscables.map(c => `${c} ILIKE ?`).join(' OR ') + ')');
      this.buscables.forEach(() => params.push(`%${buscar}%`));
    }
    return this.db.query(`SELECT * FROM ${this.tabla} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY nombre`, params);
  }
  buscarPorId(id) { return this.db.uno(`SELECT * FROM ${this.tabla} WHERE id = ?`, [Number(id)]); }
  crear(datos) {
    const cols = this.columnas;
    return this.db.uno(`INSERT INTO ${this.tabla} (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')}) RETURNING *`,
      cols.map(c => datos[c] ?? null));
  }
  actualizar(id, datos) {
    const cols = this.columnas;
    return this.db.uno(`UPDATE ${this.tabla} SET ${cols.map(c => `${c}=?`).join(',')} WHERE id=? RETURNING *`,
      [...cols.map(c => datos[c] ?? null), Number(id)]);
  }
  async eliminar(id) {
    if (this.softDelete) await this.db.query(`UPDATE ${this.tabla} SET activo = 0 WHERE id = ?`, [Number(id)]);
    else await this.db.query(`DELETE FROM ${this.tabla} WHERE id = ?`, [Number(id)]);
  }
}
