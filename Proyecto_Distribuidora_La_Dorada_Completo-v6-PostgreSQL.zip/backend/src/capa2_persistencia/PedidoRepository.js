// CAPA 2: PERSISTENCIA - Repositorio de Pedidos (PostgreSQL)
import { Pedido } from '../capa1_dominio/Pedido.js';

const SELECT = `
  SELECT o.*, u.nombre AS vendedor,
         COALESCE((SELECT SUM(monto) FROM pagos WHERE pedido_id = o.id), 0) AS pagado
  FROM pedidos o LEFT JOIN usuarios u ON u.id = o.vendedor_id`;

export class PedidoRepository {
  constructor(driver) { this.db = driver; }

  async _hidratar(rows) {
    if (!rows.length) return [];
    const ids = rows.map(r => r.id);
    const filas = await this.db.query('SELECT * FROM pedido_items WHERE pedido_id = ANY(?::int[]) ORDER BY id', [ids]);
    const porPedido = new Map();
    for (const i of filas) {
      if (!porPedido.has(i.pedido_id)) porPedido.set(i.pedido_id, []);
      porPedido.get(i.pedido_id).push({ productoId: i.producto_id, referencia: i.referencia, nombre: i.nombre, precioUnitario: i.precio_unitario, cantidad: i.cantidad });
    }
    return rows.map(r => new Pedido(r.id, r.cliente_nombre, r.nota, r.creado, r.estado, r.stock_descontado, porPedido.get(r.id) ?? [], {
      codigo: r.codigo, clienteId: r.cliente_id, vendedorId: r.vendedor_id, vendedor: r.vendedor,
      confirmado: r.confirmado, despachado: r.despachado, pagado: r.pagado
    }));
  }

  async listar({ estado = 'TODOS', buscar = '', clienteId = null, desde = null, hasta = null } = {}) {
    const where = [], params = [];
    if (estado && estado !== 'TODOS') { where.push('o.estado = ?'); params.push(estado); }
    if (buscar) { where.push('(o.codigo ILIKE ? OR o.cliente_nombre ILIKE ?)'); params.push(`%${buscar}%`, `%${buscar}%`); }
    if (clienteId) { where.push('o.cliente_id = ?'); params.push(Number(clienteId)); }
    if (desde) { where.push('o.creado::date >= ?::date'); params.push(desde); }
    if (hasta) { where.push('o.creado::date <= ?::date'); params.push(hasta); }
    const rows = await this.db.query(`${SELECT} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY o.id DESC`, params);
    return this._hidratar(rows);
  }
  listarTodos() { return this.listar(); }
  async buscarPorId(id, bloquear = false) {
    if (bloquear) await this.db.query('SELECT id FROM pedidos WHERE id = ? FOR UPDATE', [Number(id)]);
    const r = await this.db.uno(`${SELECT} WHERE o.id = ?`, [Number(id)]);
    return r ? (await this._hidratar([r]))[0] : null;
  }
  async buscarPorCodigo(codigo) {
    const r = await this.db.uno(`${SELECT} WHERE o.codigo = ?`, [codigo]);
    return r ? (await this._hidratar([r]))[0] : null;
  }
  /** Código correlativo mediante secuencia de PostgreSQL (seguro ante concurrencia). */
  async siguienteCodigo() { return 'PED-' + (await this.db.uno(`SELECT nextval('seq_pedido') AS n`)).n; }

  async guardar(p) {
    if (!p.id) {
      p.codigo = p.codigo || await this.siguienteCodigo();
      const r = await this.db.uno(`INSERT INTO pedidos (codigo,cliente_id,cliente_nombre,nota,estado,stock_descontado,total,vendedor_id,confirmado)
        VALUES (?,?,?,?,?,?,?,?,?) RETURNING id, creado`, [p.codigo, p.clienteId, p.cliente, p.nota, p.estado, p.stockDescontado ? 1 : 0, p.calcularTotal(), p.vendedorId, p.confirmado]);
      p.id = r.id; p.fecha = r.creado;
      for (const i of p.items) {
        await this.db.query(`INSERT INTO pedido_items (pedido_id,producto_id,referencia,nombre,precio_unitario,cantidad) VALUES (?,?,?,?,?,?)`,
          [p.id, i.productoId, i.referencia, i.nombre, i.precioUnitario, i.cantidad]);
      }
    } else {
      await this.db.query(`UPDATE pedidos SET estado=?, stock_descontado=?, total=?, confirmado=?, despachado=? WHERE id=?`,
        [p.estado, p.stockDescontado ? 1 : 0, p.calcularTotal(), p.confirmado, p.despachado, p.id]);
    }
    return p;
  }
}
