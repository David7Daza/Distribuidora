// CAPA 2: PERSISTENCIA - Conexión PostgreSQL (pool), esquema, transacciones y semilla.
// Reemplaza al StorageDriver de localStorage/SQLite. Las transacciones usan AsyncLocalStorage:
// todo lo que se ejecute dentro de transaccion(fn) comparte la misma conexión automáticamente.
import pg from 'pg';
import bcrypt from 'bcryptjs';
import fs from 'node:fs';
import path from 'node:path';
import { AsyncLocalStorage } from 'node:async_hooks';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const RUTA_ESQUEMA = path.join(__dirname, '..', '..', 'database', 'la_dorada_completo.sql');

// Tipos: COUNT/SUM (bigint) y NUMERIC llegan como números; TIMESTAMP llega como texto 'YYYY-MM-DD HH:MM:SS'
pg.types.setTypeParser(20, v => parseInt(v, 10));
pg.types.setTypeParser(1700, v => parseFloat(v));
pg.types.setTypeParser(1114, v => v);

export const URL_POR_DEFECTO = 'postgresql://postgres:cuesta2016@localhost:5432/la_dorada';

const TABLAS_DATOS = [
  'auditoria', 'movimientos_inventario', 'compra_items', 'compras', 'pagos',
  'pedido_items', 'pedidos', 'productos', 'clientes', 'proveedores', 'categorias', 'usuarios'
];

const contexto = new AsyncLocalStorage();

/** Convierte placeholders '?' en $1, $2, ... */
const aPg = sql => { let n = 0; return sql.replace(/\?/g, () => `$${++n}`); };

export class StorageDriver {
  constructor(pool, connectionString) {
    this.pool = pool;
    this.archivo = connectionString.replace(/:\/\/([^:]+):[^@]*@/, '://$1:****@'); // para mostrar sin contraseña
  }

  /** Crea la base si no existe, aplica el esquema y carga la semilla si está vacía. */
  static async crear({ connectionString = process.env.DATABASE_URL || URL_POR_DEFECTO } = {}) {
    await StorageDriver.#crearBaseSiNoExiste(connectionString);
    const pool = new pg.Pool({ connectionString, max: 10 });
    const driver = new StorageDriver(pool, connectionString);
    await pool.query(fs.readFileSync(RUTA_ESQUEMA, 'utf8'));
    const { rows } = await pool.query('SELECT COUNT(*) AS c FROM usuarios');
    if (!rows[0].c) await driver.sembrar();
    return driver;
  }

  static async #crearBaseSiNoExiste(connectionString) {
    const url = new URL(connectionString);
    const nombre = decodeURIComponent(url.pathname.slice(1));
    url.pathname = '/postgres';
    const admin = new pg.Client({ connectionString: url.toString() });
    try {
      await admin.connect();
      const r = await admin.query('SELECT 1 FROM pg_database WHERE datname = $1', [nombre]);
      if (!r.rowCount) await admin.query(`CREATE DATABASE "${nombre.replace(/"/g, '""')}"`);
    } catch (e) {
      // Si no hay permiso para crear bases, se intenta conectar igual (la base puede existir ya).
      if (e.code === 'ECONNREFUSED' || e.code === '28P01') throw e;
    } finally { await admin.end().catch(() => {}); }
  }

  // ---------- Acceso a datos ----------
  async query(sql, params = []) {
    const cliente = contexto.getStore() ?? this.pool;
    return (await cliente.query(aPg(sql), params)).rows;
  }
  async uno(sql, params = []) { return (await this.query(sql, params))[0] ?? null; }
  async ejecutar(sql, params = []) {
    const cliente = contexto.getStore() ?? this.pool;
    return cliente.query(aPg(sql), params);
  }
  /** Hora local del servidor de base de datos, en el mismo formato de las columnas TIMESTAMP. */
  async ahora() { return (await this.uno(`SELECT LOCALTIMESTAMP(0)::text AS t`)).t; }

  /** Ejecuta fn dentro de una transacción (BEGIN/COMMIT, ROLLBACK ante cualquier error). Anidable. */
  async transaccion(fn) {
    if (contexto.getStore()) return fn();
    const cliente = await this.pool.connect();
    try {
      await cliente.query('BEGIN');
      const r = await contexto.run(cliente, fn);
      await cliente.query('COMMIT');
      return r;
    } catch (e) {
      await cliente.query('ROLLBACK').catch(() => {});
      throw e;
    } finally { cliente.release(); }
  }

  async cerrar() { await this.pool.end(); }

  /** Datos de prueba alineados con la Sección 8 del documento técnico. */
  async sembrar() {
    await this.transaccion(async () => {
      const ins = async (sql, ...a) => (await this.query(sql + ' RETURNING id', a))[0].id;
      const user = (n, e, p, r) => ins('INSERT INTO usuarios (nombre,email,password_hash,rol) VALUES (?,?,?,?)', n, e, bcrypt.hashSync(p, 10), r);
      await user('Gerente La Dorada', 'admin@ladorada.co', 'admin123', 'ADMIN');
      await user('Vendedor 1', 'ventas@ladorada.co', 'ventas123', 'VENTAS');
      await user('Encargada de Bodega', 'bodega@ladorada.co', 'bodega123', 'BODEGA');

      for (const n of ['Detergentes', 'Jabones', 'Desinfectantes', 'Desengrasantes', 'Ambientadores'])
        await ins('INSERT INTO categorias (nombre) VALUES (?)', n);

      await ins('INSERT INTO proveedores (nombre,nit,telefono,email,direccion) VALUES (?,?,?,?,?)',
        'Químicos del Valle S.A.S.', '900.123.456-1', '3101234567', 'ventas@quimicosdelvalle.co', 'Cali, Valle del Cauca');
      await ins('INSERT INTO proveedores (nombre,nit,telefono,email,direccion) VALUES (?,?,?,?,?)',
        'Distribuciones Andinas Ltda.', '800.765.432-9', '3207654321', 'pedidos@andinas.co', 'Yumbo, Valle del Cauca');

      const prod = async (ref, nom, cat, prov, precio, costo, stock, min) => {
        const id = await ins('INSERT INTO productos (referencia,nombre,categoria_id,proveedor_id,precio,costo,existencias,stock_minimo) VALUES (?,?,?,?,?,?,?,?)',
          ref, nom, cat, prov, precio, costo, stock, min);
        await this.query(`INSERT INTO movimientos_inventario (producto_id,tipo,cantidad,stock_resultante,referencia,nota) VALUES (?,?,?,?,?,?)`,
          [id, 'INICIAL', stock, stock, 'SEMILLA', 'Carga inicial de inventario']);
      };
      await prod('ASEO-001', 'Detergente Líquido Multiusos 1L', 1, 1, 9500, 6200, 20, 8);
      await prod('ASEO-002', 'Jabón en Barra Multiusos 300g', 2, 1, 3800, 2300, 8, 10);
      await prod('ASEO-003', 'Hipoclorito Blanqueador Desinfectante 2L', 3, 2, 6200, 3900, 35, 10);
      await prod('ASEO-004', 'Desengrasante Industrial Cocina 1L', 4, 2, 12000, 7800, 14, 6);
      await prod('ASEO-005', 'Ambientador Pisos Lavanda 1L', 5, 1, 7500, 4600, 18, 6);

      const cli = (n, nit, tel, mail, dir, ciu, tipo) =>
        ins('INSERT INTO clientes (nombre,nit,telefono,email,direccion,ciudad,tipo) VALUES (?,?,?,?,?,?,?)', n, nit, tel, mail, dir, ciu, tipo);
      await cli('Tienda La Esquina', '900.111.222-3', '3001112233', 'laesquina@correo.co', 'Cra 8 # 12-30', 'Cali', 'Tienda');
      await cli('Restaurante Sabor Criollo', '901.333.444-5', '3014445566', 'compras@saborcriollo.co', 'Av 6N # 25-10', 'Cali', 'Restaurante');
      await cli('Minimercado El Vecino', '900.555.666-7', '3025556677', 'elvecino@correo.co', 'Cll 5 # 40-22', 'Cali', 'Minimercado');
      await cli('Cafetería Aroma', '901.777.888-9', '3036667788', 'aroma@correo.co', 'Cra 100 # 15-05', 'Cali', 'Restaurante');
    });
  }

  /** Borra todo y vuelve a cargar la semilla (botón "Restaurar Datos Sección 8"). */
  async restaurarSemilla() {
    await this.transaccion(async () => {
      await this.ejecutar(`TRUNCATE ${TABLAS_DATOS.join(', ')} RESTART IDENTITY CASCADE`);
      await this.ejecutar(`ALTER SEQUENCE seq_pedido RESTART WITH 1001`);
      await this.ejecutar(`ALTER SEQUENCE seq_compra RESTART WITH 1`);
    });
    await this.sembrar();
  }
}
