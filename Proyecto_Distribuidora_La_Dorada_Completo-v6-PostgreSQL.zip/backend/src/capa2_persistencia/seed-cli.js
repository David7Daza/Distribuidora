import { StorageDriver } from './Database.js';
const s = await StorageDriver.crear();
await s.restaurarSemilla();
console.log('Base de datos PostgreSQL restaurada con los datos de la Sección 8:', s.archivo);
await s.cerrar();
