// CAPA 2: PERSISTENCIA - Repositorio de Productos (PostgreSQL)
import { Producto } from '../capa1_dominio/Producto.js';

const SELECT = `
  SELECT p.*, c.nombre AS categoria, pr.nombre AS proveedor
  FROM productos p
  LEFT JOIN categorias c ON c.id = p.categoria_id
  LEFT JOIN proveedores pr ON pr.id = p.proveedor_id`;

const aEntidad = r => new Producto(r.id, r.referencia, r.nombre, r.precio, r.existencias, {
  costo: r.costo, stockMinimo: r.stock_minimo, categoriaId: r.categoria_id, proveedorId: r.proveedor_id,
  categoria: r.categoria, proveedor: r.proveedor, activo: r.activo
});

export class ProductoRepository {
  constructor(driver) { this.db = driver; }

  async listar({ buscar = '', categoriaId = null, bajoStock = false, incluirInactivos = false } = {}) {
    const where = [], params = [];
    if (!incluirInactivos) where.push('p.activo = 1');
    if (buscar) { where.push('(p.nombre ILIKE ? OR p.referencia ILIKE ?)'); params.push(`%${buscar}%`, `%${buscar}%`); }
    if (categoriaId) { where.push('p.categoria_id = ?'); params.push(Number(categoriaId)); }
    if (bajoStock) where.push('p.existencias <= p.stock_minimo');
    const rows = await this.db.query(`${SELECT} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY p.referencia`, params);
    return rows.map(aEntidad);
  }
  listarTodos() { return this.listar({ incluirInactivos: true }); }

  /** bloquear=true usa SELECT ... FOR UPDATE (bloqueo de fila dentro de una transacción) para evitar sobreventa concurrente. */
  async buscarPorId(id, bloquear = false) {
    // FOR UPDATE no admite OUTER JOIN sobre las tablas nulables: se bloquea solo la fila de productos.
    const r = await this.db.uno(`${SELECT} WHERE p.id = ? ${bloquear ? 'FOR UPDATE OF p' : ''}`, [Number(id)]);
    return r ? aEntidad(r) : null;
  }
  async buscarPorReferencia(ref) {
    const r = await this.db.uno(`${SELECT} WHERE p.referencia = ?`, [ref]);
    return r ? aEntidad(r) : null;
  }
  async guardar(p) {
    const vals = [p.referencia, p.nombre, p.categoriaId, p.proveedorId, p.precio, p.costo, p.existencias, p.stockMinimo, p.activo ? 1 : 0];
    if (p.id) {
      await this.db.query(`UPDATE productos SET referencia=?, nombre=?, categoria_id=?, proveedor_id=?, precio=?, costo=?,
        existencias=?, stock_minimo=?, activo=? WHERE id=?`, [...vals, p.id]);
    } else {
      const r = await this.db.uno(`INSERT INTO productos (referencia,nombre,categoria_id,proveedor_id,precio,costo,existencias,stock_minimo,activo)
        VALUES (?,?,?,?,?,?,?,?,?) RETURNING id`, vals);
      p.id = r.id;
    }
    return p;
  }
  async desactivar(id) { await this.db.query('UPDATE productos SET activo = 0 WHERE id = ?', [Number(id)]); }
}
