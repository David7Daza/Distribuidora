// CAPA 2: PERSISTENCIA - Repositorios de usuarios, movimientos, pagos, compras y auditoría (PostgreSQL)
export class UsuarioRepository {
  constructor(driver) { this.db = driver; }
  listar() { return this.db.query('SELECT id,nombre,email,rol,activo,creado FROM usuarios ORDER BY id'); }
  buscarPorEmail(email) { return this.db.uno('SELECT * FROM usuarios WHERE email = ?', [String(email).toLowerCase().trim()]); }
  buscarPorId(id) { return this.db.uno('SELECT id,nombre,email,rol,activo,creado FROM usuarios WHERE id = ?', [Number(id)]); }
  crear({ nombre, email, password_hash, rol }) {
    return this.db.uno('INSERT INTO usuarios (nombre,email,password_hash,rol) VALUES (?,?,?,?) RETURNING id,nombre,email,rol,activo,creado',
      [nombre, String(email).toLowerCase().trim(), password_hash, rol]);
  }
  async actualizar(id, { nombre, rol, activo }) {
    await this.db.query('UPDATE usuarios SET nombre=?, rol=?, activo=? WHERE id=?', [nombre, rol, activo ? 1 : 0, Number(id)]);
    return this.buscarPorId(id);
  }
  cambiarPassword(id, hash) { return this.db.query('UPDATE usuarios SET password_hash=? WHERE id=?', [hash, Number(id)]); }
  async contarAdminsActivos() { return (await this.db.uno(`SELECT COUNT(*) AS c FROM usuarios WHERE rol='ADMIN' AND activo=1`)).c; }
}

export class MovimientoRepository {
  constructor(driver) { this.db = driver; }
  registrar({ productoId, tipo, cantidad, stockResultante, referencia = null, nota = null, usuarioId = null }) {
    return this.db.query(`INSERT INTO movimientos_inventario (producto_id,tipo,cantidad,stock_resultante,referencia,nota,usuario_id) VALUES (?,?,?,?,?,?,?)`,
      [productoId, tipo, cantidad, stockResultante, referencia, nota, usuarioId]);
  }
  listar({ productoId = null, tipo = null, limite = 300 } = {}) {
    const where = [], params = [];
    if (productoId) { where.push('m.producto_id = ?'); params.push(Number(productoId)); }
    if (tipo) { where.push('m.tipo = ?'); params.push(tipo); }
    return this.db.query(`
      SELECT m.*, p.referencia AS referencia_producto, p.nombre AS producto, u.nombre AS usuario
      FROM movimientos_inventario m
      JOIN productos p ON p.id = m.producto_id
      LEFT JOIN usuarios u ON u.id = m.usuario_id
      ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      ORDER BY m.id DESC LIMIT ?`, [...params, limite]);
  }
}

export class PagoRepository {
  constructor(driver) { this.db = driver; }
  async registrar({ pedidoId, monto, metodo, usuarioId }) {
    return (await this.db.uno('INSERT INTO pagos (pedido_id,monto,metodo,usuario_id) VALUES (?,?,?,?) RETURNING id', [pedidoId, monto, metodo, usuarioId])).id;
  }
  listarPorPedido(pedidoId) {
    return this.db.query(`SELECT g.*, u.nombre AS usuario FROM pagos g LEFT JOIN usuarios u ON u.id = g.usuario_id WHERE g.pedido_id = ? ORDER BY g.id`, [Number(pedidoId)]);
  }
}

export class CompraRepository {
  constructor(driver) { this.db = driver; }
  async crear({ proveedorId, nota, usuarioId, items }) {
    const codigo = 'CMP-' + (await this.db.uno(`SELECT nextval('seq_compra') AS n`)).n;
    const total = items.reduce((a, i) => a + i.cantidad * i.costoUnitario, 0);
    const { id } = await this.db.uno('INSERT INTO compras (codigo,proveedor_id,total,nota,usuario_id) VALUES (?,?,?,?,?) RETURNING id', [codigo, proveedorId, total, nota, usuarioId]);
    for (const i of items) await this.db.query('INSERT INTO compra_items (compra_id,producto_id,cantidad,costo_unitario) VALUES (?,?,?,?)', [id, i.productoId, i.cantidad, i.costoUnitario]);
    return { id, codigo, total };
  }
  listar() {
    return this.db.query(`
      SELECT c.*, pr.nombre AS proveedor, u.nombre AS usuario,
             (SELECT COUNT(*) FROM compra_items WHERE compra_id = c.id) AS lineas
      FROM compras c LEFT JOIN proveedores pr ON pr.id = c.proveedor_id LEFT JOIN usuarios u ON u.id = c.usuario_id
      ORDER BY c.id DESC`);
  }
  async buscarPorId(id) {
    const c = await this.db.uno(`SELECT c.*, pr.nombre AS proveedor, u.nombre AS usuario FROM compras c
      LEFT JOIN proveedores pr ON pr.id = c.proveedor_id LEFT JOIN usuarios u ON u.id = c.usuario_id WHERE c.id = ?`, [Number(id)]);
    if (!c) return null;
    c.items = await this.db.query(`SELECT ci.*, p.referencia, p.nombre FROM compra_items ci JOIN productos p ON p.id = ci.producto_id WHERE compra_id = ?`, [c.id]);
    return c;
  }
}

export class AuditoriaRepository {
  constructor(driver) { this.db = driver; }
  registrar({ usuarioId = null, usuarioNombre = null, accion, entidad, entidadId = null, detalle = null }) {
    return this.db.query('INSERT INTO auditoria (usuario_id,usuario_nombre,accion,entidad,entidad_id,detalle) VALUES (?,?,?,?,?,?)',
      [usuarioId, usuarioNombre, accion, entidad, entidadId == null ? null : String(entidadId), detalle]);
  }
  listar({ entidad = null, limite = 300 } = {}) {
    return this.db.query(`SELECT * FROM auditoria ${entidad ? 'WHERE entidad = ?' : ''} ORDER BY id DESC LIMIT ?`, entidad ? [entidad, limite] : [limite]);
  }
}
