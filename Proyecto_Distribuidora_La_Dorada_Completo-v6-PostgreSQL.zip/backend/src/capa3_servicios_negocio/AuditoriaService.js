// CAPA 3: LÓGICA DE NEGOCIO - Registro de auditoría (quién hizo qué y cuándo)
export class AuditoriaService {
  constructor(auditoriaRepository) { this.repo = auditoriaRepository; }
  async registrar(ctx, accion, entidad, entidadId, detalle) {
    await this.repo.registrar({
      usuarioId: ctx?.usuario?.id ?? null, usuarioNombre: ctx?.usuario?.nombre ?? null,
      accion, entidad, entidadId, detalle
    });
  }
  listar(filtros) { return this.repo.listar(filtros); }
}
