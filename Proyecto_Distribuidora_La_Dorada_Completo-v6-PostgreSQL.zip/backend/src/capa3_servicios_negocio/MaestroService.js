// CAPA 3: LÓGICA DE NEGOCIO - CRUD validado de clientes, proveedores y categorías
import { ResultadoOperacion } from '../capa1_dominio/ResultadoOperacion.js';

const R = ResultadoOperacion;

export class MaestroService {
  /** @param permiso acción de ControlAccesoRolService requerida para crear/editar/eliminar */
  constructor({ repo, nombreEntidad, permiso, validador, seguridad, auditoria, validarExtra = () => null }) {
    Object.assign(this, { repo, nombreEntidad, permiso, validador, seguridad, auditoria, validarExtra });
  }
  listar(filtros) { return this.repo.listar(filtros); }
  async obtener(id) {
    const r = await this.repo.buscarPorId(id);
    return r ? R.ok("Encontrado.", r, "MaestroService") : R.fallo(`${this.nombreEntidad} no encontrado.`, null, "MaestroService", 404);
  }
  _validar(datos) {
    if (!String(datos.nombre || '').trim()) return `El nombre del ${this.nombreEntidad} es obligatorio.`;
    if (datos.email && !this.validador.validarEmail(datos.email)) return "El correo electrónico no es válido.";
    return this.validarExtra(datos);
  }
  async guardar(id, datos, ctx) {
    const p = this.seguridad.verificarPermiso(ctx.usuario.rol, this.permiso);
    if (!p.exito) return p;
    const error = this._validar(datos);
    if (error) return R.fallo(error, null, "MaestroService");
    const limpio = Object.fromEntries(Object.entries(datos).map(([k, v]) => [k, typeof v === 'string' ? v.trim() : v]));
    try {
      if (id) {
        if (!(await this.repo.buscarPorId(id))) return R.fallo(`${this.nombreEntidad} no encontrado.`, null, "MaestroService", 404);
        const r = await this.repo.actualizar(id, limpio);
        await this.auditoria.registrar(ctx, "EDITAR", this.nombreEntidad, id, r.nombre);
        return R.ok(`${this.nombreEntidad} '${r.nombre}' actualizado.`, r, "MaestroService");
      }
      const r = await this.repo.crear(limpio);
      await this.auditoria.registrar(ctx, "CREAR", this.nombreEntidad, r.id, r.nombre);
      return R.ok(`${this.nombreEntidad} '${r.nombre}' creado.`, r, "MaestroService", 201);
    } catch (e) {
      if (e.code === '23505') return R.fallo(`Ya existe un registro de ${this.nombreEntidad} con ese nombre.`, null, "MaestroService", 409);
      throw e;
    }
  }
  async eliminar(id, ctx) {
    const p = this.seguridad.verificarPermiso(ctx.usuario.rol, this.permiso);
    if (!p.exito) return p;
    const r = await this.repo.buscarPorId(id);
    if (!r) return R.fallo(`${this.nombreEntidad} no encontrado.`, null, "MaestroService", 404);
    try {
      await this.repo.eliminar(id);
    } catch (e) {
      if (e.code === '23503') return R.fallo(`No se puede eliminar: '${r.nombre}' está en uso por otros registros.`, null, "MaestroService", 409);
      throw e;
    }
    await this.auditoria.registrar(ctx, "ELIMINAR", this.nombreEntidad, id, r.nombre);
    return R.ok(`${this.nombreEntidad} '${r.nombre}' eliminado.`, null, "MaestroService");
  }
}
