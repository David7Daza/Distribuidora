// CAPA 3: LÓGICA DE NEGOCIO - Reglas de negocio obligatorias (Sección 4)
import { ResultadoOperacion } from '../capa1_dominio/ResultadoOperacion.js';

export class ValidadorReglasNegocio {
  validarCantidadPositiva(cantidad) {
    const n = Number(cantidad);
    if (!Number.isInteger(n) || n <= 0) {
      return ResultadoOperacion.fallo(
        `REGLA DE NEGOCIO BLOQUEADA: Se rechazó la cantidad (${cantidad}). Solo se permiten cantidades enteras mayores a cero (> 0).`,
        null, "ValidadorReglasNegocio"
      );
    }
    return ResultadoOperacion.ok("Cantidad válida (> 0).", n, "ValidadorReglasNegocio");
  }

  /** Verifica existencias bloqueando cada fila de producto (FOR UPDATE) hasta terminar la transacción: evita sobreventa concurrente. */
  async validarDisponibilidadInventario(itemsPedido, productoRepository) {
    if (!itemsPedido || itemsPedido.length === 0) {
      return ResultadoOperacion.fallo("El pedido debe contener al menos un producto.", null, "ValidadorReglasNegocio");
    }
    const motivosFaltantes = [];
    const ordenados = [...itemsPedido].sort((a, b) => a.productoId - b.productoId); // orden fijo => sin deadlocks
    for (const item of ordenados) {
      const checkCant = this.validarCantidadPositiva(item.cantidad);
      if (!checkCant.exito) return checkCant;
      const prod = await productoRepository.buscarPorId(item.productoId, true);
      const disp = prod ? prod.existencias : 0;
      if (!prod || !prod.activo || !prod.tieneStockSuficiente(item.cantidad)) {
        motivosFaltantes.push(`${item.nombre} (Solicitado: ${item.cantidad}, Disponible: ${disp})`);
      }
    }
    if (motivosFaltantes.length > 0) {
      return ResultadoOperacion.fallo(
        `CONFIRMACIÓN IMPEDIDA — INVENTARIO INSUFICIENTE: ${motivosFaltantes.join("; ")}. Las existencias NO fueron modificadas.`,
        motivosFaltantes, "ValidadorReglasNegocio"
      );
    }
    return ResultadoOperacion.ok("Existencias suficientes verificadas.", null, "ValidadorReglasNegocio");
  }

  validarTransicionEstado(pedido, nuevoEstado) {
    const f = m => ResultadoOperacion.fallo(m, null, "ValidadorReglasNegocio", 409);
    if (nuevoEstado === "Confirmado") {
      if (pedido.estado !== "Pendiente") return f(`Transición inválida: El pedido ${pedido.codigo} está en estado '${pedido.estado}' y no puede volver a confirmarse.`);
      if (pedido.stockDescontado) return f(`Protección anti-duplicado: El pedido ${pedido.codigo} ya tiene existencias descontadas.`);
    } else if (nuevoEstado === "Despachado") {
      if (pedido.estado !== "Confirmado") return f(`Transición inválida: Solo se pueden despachar pedidos en estado 'Confirmado' (Estado actual: ${pedido.estado}).`);
    } else if (nuevoEstado === "Rechazado") {
      if (pedido.estado === "Despachado") return f(`Transición bloqueada: No se puede rechazar/cancelar un pedido que ya fue 'Despachado'.`);
      if (pedido.estado === "Rechazado") return f(`El pedido ${pedido.codigo} ya está Rechazado.`);
    } else {
      return f(`Estado '${nuevoEstado}' no reconocido.`);
    }
    return ResultadoOperacion.ok("Transición de estado permitida.", null, "ValidadorReglasNegocio");
  }

  validarPago(pedido, monto) {
    const m = Number(monto);
    if (!Number.isFinite(m) || m <= 0) return ResultadoOperacion.fallo("El monto del pago debe ser mayor a cero.", null, "ValidadorReglasNegocio");
    if (!["Confirmado", "Despachado"].includes(pedido.estado)) {
      return ResultadoOperacion.fallo(`Solo se registran pagos de pedidos Confirmados o Despachados (estado actual: ${pedido.estado}).`, null, "ValidadorReglasNegocio", 409);
    }
    const saldo = pedido.saldoPendiente();
    if (m > saldo) {
      return ResultadoOperacion.fallo(`El pago ($${m.toLocaleString("es-CO")}) supera el saldo pendiente ($${saldo.toLocaleString("es-CO")}).`, null, "ValidadorReglasNegocio", 409);
    }
    return ResultadoOperacion.ok("Pago válido.", m, "ValidadorReglasNegocio");
  }

  validarEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || ""));
  }
}
