// CAPA 3: LÓGICA DE NEGOCIO - Autenticación (JWT + bcrypt) y gestión de usuarios
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { ResultadoOperacion } from '../capa1_dominio/ResultadoOperacion.js';

const R = ResultadoOperacion;
const SECRET = process.env.JWT_SECRET || 'la-dorada-secreto-de-desarrollo-cambiar-en-produccion';
if (!process.env.JWT_SECRET) console.warn('[AVISO] JWT_SECRET no definido: usando secreto de desarrollo.');

export class AuthService {
  constructor({ usuarioRepo, seguridad, validador, auditoria }) {
    Object.assign(this, { usuarioRepo, seguridad, validador, auditoria });
  }

  async login(email, password) {
    const u = await this.usuarioRepo.buscarPorEmail(email);
    if (!u || !u.activo || !bcrypt.compareSync(String(password || ''), u.password_hash)) {
      return R.fallo("Correo o contraseña incorrectos.", null, "AuthService", 401);
    }
    const usuario = { id: u.id, nombre: u.nombre, email: u.email, rol: u.rol };
    const token = jwt.sign(usuario, SECRET, { expiresIn: '12h' });
    await this.auditoria.registrar({ usuario }, "LOGIN", "usuario", u.id, u.email);
    return R.ok(`Bienvenido, ${u.nombre}.`, { token, usuario, permisos: this.seguridad.permisosDe(u.rol) }, "AuthService");
  }

  async verificarToken(token) {
    try {
      const p = jwt.verify(token, SECRET);
      const u = await this.usuarioRepo.buscarPorId(p.id);
      if (!u || !u.activo) return null;
      return { id: u.id, nombre: u.nombre, email: u.email, rol: u.rol };
    } catch { return null; }
  }

  perfil(usuario) { return R.ok("Sesión activa.", { usuario, permisos: this.seguridad.permisosDe(usuario.rol) }, "AuthService"); }

  async cambiarPropiaPassword(ctx, actual, nueva) {
    const u = await this.usuarioRepo.buscarPorEmail(ctx.usuario.email);
    if (!bcrypt.compareSync(String(actual || ''), u.password_hash)) return R.fallo("La contraseña actual no es correcta.", null, "AuthService");
    if (String(nueva || '').length < 6) return R.fallo("La nueva contraseña debe tener al menos 6 caracteres.", null, "AuthService");
    await this.usuarioRepo.cambiarPassword(u.id, bcrypt.hashSync(nueva, 10));
    await this.auditoria.registrar(ctx, "CAMBIAR_PASSWORD", "usuario", u.id, u.email);
    return R.ok("Contraseña actualizada.", null, "AuthService");
  }

  // --- Administración de usuarios (solo ADMIN) ---
  async listarUsuarios(ctx) {
    const p = this.seguridad.verificarPermiso(ctx.usuario.rol, "gestionarUsuarios"); if (!p.exito) return p;
    return R.ok("Usuarios.", await this.usuarioRepo.listar(), "AuthService");
  }
  async crearUsuario({ nombre, email, password, rol }, ctx) {
    const p = this.seguridad.verificarPermiso(ctx.usuario.rol, "gestionarUsuarios"); if (!p.exito) return p;
    if (!String(nombre || '').trim()) return R.fallo("El nombre es obligatorio.", null, "AuthService");
    if (!this.validador.validarEmail(email)) return R.fallo("Correo electrónico inválido.", null, "AuthService");
    if (!['ADMIN', 'VENTAS', 'BODEGA'].includes(rol)) return R.fallo("Rol inválido.", null, "AuthService");
    if (String(password || '').length < 6) return R.fallo("La contraseña debe tener al menos 6 caracteres.", null, "AuthService");
    if (await this.usuarioRepo.buscarPorEmail(email)) return R.fallo("Ya existe un usuario con ese correo.", null, "AuthService", 409);
    const u = await this.usuarioRepo.crear({ nombre: nombre.trim(), email, password_hash: bcrypt.hashSync(password, 10), rol });
    await this.auditoria.registrar(ctx, "CREAR", "usuario", u.id, `${u.email} (${u.rol})`);
    return R.ok(`Usuario ${u.nombre} creado.`, u, "AuthService", 201);
  }
  async actualizarUsuario(id, { nombre, rol, activo, password }, ctx) {
    const p = this.seguridad.verificarPermiso(ctx.usuario.rol, "gestionarUsuarios"); if (!p.exito) return p;
    const u = await this.usuarioRepo.buscarPorId(id);
    if (!u) return R.fallo("Usuario no encontrado.", null, "AuthService", 404);
    if (!['ADMIN', 'VENTAS', 'BODEGA'].includes(rol)) return R.fallo("Rol inválido.", null, "AuthService");
    const quedaraAdmin = rol === 'ADMIN' && activo;
    if (u.rol === 'ADMIN' && u.activo && !quedaraAdmin && (await this.usuarioRepo.contarAdminsActivos()) <= 1) {
      return R.fallo("No se puede quitar o desactivar al último administrador activo.", null, "AuthService", 409);
    }
    if (password && String(password).length < 6) return R.fallo("La contraseña debe tener al menos 6 caracteres.", null, "AuthService");
    const r = await this.usuarioRepo.actualizar(id, { nombre: String(nombre || u.nombre).trim(), rol, activo: Boolean(activo) });
    if (password) await this.usuarioRepo.cambiarPassword(id, bcrypt.hashSync(password, 10));
    await this.auditoria.registrar(ctx, "EDITAR", "usuario", id, `${r.email} (${r.rol}${r.activo ? '' : ', inactivo'})`);
    return R.ok(`Usuario ${r.nombre} actualizado.`, r, "AuthService");
  }
}
