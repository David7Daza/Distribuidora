// CAPA 3: LÓGICA DE NEGOCIO - Servicio transaccional de pedidos y pagos
import { Pedido } from '../capa1_dominio/Pedido.js';
import { ItemPedido } from '../capa1_dominio/ItemPedido.js';
import { ResultadoOperacion } from '../capa1_dominio/ResultadoOperacion.js';

const R = ResultadoOperacion;

export class PedidoService {
  constructor({ driver, pedidoRepo, productoRepo, clienteRepo, pagoRepo, inventarioService, validador, seguridad, auditoria }) {
    Object.assign(this, { driver, pedidoRepo, productoRepo, clienteRepo, pagoRepo, inventarioService, validador, seguridad, auditoria });
  }

  listarPedidos(filtros) { return this.pedidoRepo.listar(filtros); }

  async obtenerPedido(id) {
    const pedido = await this.pedidoRepo.buscarPorId(id);
    if (!pedido) return R.fallo(`No se encontró el pedido ${id}.`, null, "PedidoService", 404);
    return R.ok("Pedido encontrado.", { ...pedido, saldo: pedido.saldoPendiente(), estadoPago: pedido.estadoPago(), pagos: await this.pagoRepo.listarPorPedido(pedido.id) }, "PedidoService");
  }

  /** Los precios y nombres SIEMPRE se toman de la base de datos, nunca del cliente. */
  async registrarPedido({ clienteId, cliente, nota, items, confirmarInmediatamente }, ctx) {
    const permiso = this.seguridad.verificarPermiso(ctx.usuario.rol, "registrarPedido");
    if (!permiso.exito) return permiso;

    let nombreCliente = String(cliente || "").trim();
    if (clienteId) {
      const c = await this.clienteRepo.buscarPorId(clienteId);
      if (!c || !c.activo) return R.fallo("El cliente seleccionado no existe o está inactivo.", null, "PedidoService", 404);
      nombreCliente = c.nombre;
    }
    if (!nombreCliente) return R.fallo("Debe seleccionar o ingresar el nombre del cliente.", null, "PedidoService");
    if (!Array.isArray(items) || items.length === 0) return R.fallo("Debe agregar al menos un producto al pedido.", null, "PedidoService");

    const fusion = new Map();
    for (const it of items) {
      const vCant = this.validador.validarCantidadPositiva(it.cantidad);
      if (!vCant.exito) return vCant;
      const prod = await this.productoRepo.buscarPorId(it.productoId);
      if (!prod || !prod.activo) return R.fallo(`El producto ${it.productoId} no existe o está inactivo.`, null, "PedidoService", 404);
      const previo = fusion.get(prod.id);
      if (previo) previo.cantidad += Number(it.cantidad);
      else fusion.set(prod.id, new ItemPedido(prod.id, prod.referencia, prod.nombre, prod.precio, Number(it.cantidad)));
    }
    const itemsPedido = [...fusion.values()];

    return this.driver.transaccion(async () => {
      const pedido = new Pedido(null, nombreCliente, nota, null, "Pendiente", false, itemsPedido, { clienteId: clienteId ? Number(clienteId) : null, vendedorId: ctx.usuario.id });

      if (!confirmarInmediatamente) {
        await this.pedidoRepo.guardar(pedido);
        await this.auditoria.registrar(ctx, "CREAR", "pedido", pedido.codigo, `Pendiente - ${pedido.cliente} - $${pedido.total.toLocaleString("es-CO")}`);
        return R.ok(`Pedido ${pedido.codigo} registrado en estado PENDIENTE (sin descontar existencias todavía).`, (await this.obtenerPedido(pedido.id)).datos, "PedidoService", 201);
      }

      const validacionStock = await this.validador.validarDisponibilidadInventario(itemsPedido, this.productoRepo);
      if (!validacionStock.exito) return validacionStock; // no se creó nada: stock intacto

      pedido.codigo = await this.pedidoRepo.siguienteCodigo();
      await this.inventarioService.aplicarDescuentoUnico(itemsPedido, ctx, pedido.codigo);
      pedido.confirmarConDescuentoUnico();
      pedido.confirmado = await this.driver.ahora();
      await this.pedidoRepo.guardar(pedido);
      await this.auditoria.registrar(ctx, "CREAR+CONFIRMAR", "pedido", pedido.codigo, `${pedido.cliente} - $${pedido.total.toLocaleString("es-CO")}`);
      return R.ok(`PEDIDO CONFIRMADO EXITOSAMENTE (${pedido.codigo}): Existencias verificadas y descontadas una sola vez.`, (await this.obtenerPedido(pedido.id)).datos, "PedidoService", 201);
    });
  }

  async cambiarEstadoPedido(pedidoId, nuevoEstado, ctx) {
    const previo = await this.pedidoRepo.buscarPorId(pedidoId);
    if (!previo) return R.fallo(`No se encontró el pedido ${pedidoId}.`, null, "PedidoService", 404);

    const accion = { Confirmado: "registrarPedido", Despachado: "despachar", Rechazado: "rechazar" }[nuevoEstado];
    if (accion) {
      const perm = this.seguridad.verificarPermiso(ctx.usuario.rol, accion);
      if (!perm.exito) return perm;
    }

    return this.driver.transaccion(async () => {
      // Bloqueo de la fila del pedido: dos clics simultáneos no pueden descontar el stock dos veces.
      const pedido = await this.pedidoRepo.buscarPorId(pedidoId, true);
      const vTrans = this.validador.validarTransicionEstado(pedido, nuevoEstado);
      if (!vTrans.exito) return vTrans;

      const ahora = await this.driver.ahora();
      let mensaje;
      if (nuevoEstado === "Confirmado") {
        const vStock = await this.validador.validarDisponibilidadInventario(pedido.items, this.productoRepo);
        if (!vStock.exito) return vStock;
        await this.inventarioService.aplicarDescuentoUnico(pedido.items, ctx, pedido.codigo);
        pedido.confirmarConDescuentoUnico();
        pedido.confirmado = ahora;
        mensaje = `Pedido ${pedido.codigo} confirmado. Se descontaron las existencias una única vez.`;
      } else if (nuevoEstado === "Despachado") {
        pedido.marcarDespachado();
        pedido.despachado = ahora;
        mensaje = `Pedido ${pedido.codigo} marcado como DESPACHADO por bodega (sin volver a descontar stock).`;
      } else {
        const teniaStock = pedido.estado === "Confirmado" && pedido.stockDescontado;
        if (teniaStock) await this.inventarioService.restituirInventarioPorCancelacion(pedido.items, ctx, pedido.codigo);
        pedido.marcarRechazado();
        mensaje = teniaStock
          ? `Pedido ${pedido.codigo} cancelado/rechazado. Se restituyeron las unidades al inventario.`
          : `Pedido ${pedido.codigo} marcado como RECHAZADO (no tenía descuento previo de stock).`;
      }
      await this.pedidoRepo.guardar(pedido);
      await this.auditoria.registrar(ctx, "CAMBIO_ESTADO", "pedido", pedido.codigo, `→ ${nuevoEstado}`);
      return R.ok(mensaje, (await this.obtenerPedido(pedido.id)).datos, "PedidoService");
    });
  }

  async registrarPago(pedidoId, { monto, metodo }, ctx) {
    const permiso = this.seguridad.verificarPermiso(ctx.usuario.rol, "registrarPago");
    if (!permiso.exito) return permiso;
    return this.driver.transaccion(async () => {
      const pedido = await this.pedidoRepo.buscarPorId(pedidoId, true);
      if (!pedido) return R.fallo(`No se encontró el pedido ${pedidoId}.`, null, "PedidoService", 404);
      const v = this.validador.validarPago(pedido, monto);
      if (!v.exito) return v;
      const metodoOk = ["Efectivo", "Transferencia", "Nequi", "Daviplata", "Tarjeta"].includes(metodo) ? metodo : "Efectivo";
      await this.pagoRepo.registrar({ pedidoId: pedido.id, monto: v.datos, metodo: metodoOk, usuarioId: ctx.usuario.id });
      await this.auditoria.registrar(ctx, "PAGO", "pedido", pedido.codigo, `$${v.datos.toLocaleString("es-CO")} (${metodoOk})`);
      return R.ok(`Pago de $${v.datos.toLocaleString("es-CO")} registrado en ${pedido.codigo}.`, (await this.obtenerPedido(pedido.id)).datos, "PedidoService", 201);
    });
  }

  async obtenerResumenPorEstado() {
    const filas = await this.driver.query(`SELECT estado, COUNT(*) AS n FROM pedidos GROUP BY estado`);
    const c = e => filas.find(f => f.estado === e)?.n ?? 0;
    const r = { Pendiente: c("Pendiente"), Confirmado: c("Confirmado"), Despachado: c("Despachado"), Rechazado: c("Rechazado") };
    return { total: r.Pendiente + r.Confirmado + r.Despachado + r.Rechazado, ...r };
  }
}
