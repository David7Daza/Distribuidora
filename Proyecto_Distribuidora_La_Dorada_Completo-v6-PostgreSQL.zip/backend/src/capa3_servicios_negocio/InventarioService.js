// CAPA 3: LÓGICA DE NEGOCIO - Catálogo, inventario, kardex y compras
import { Producto } from '../capa1_dominio/Producto.js';
import { ResultadoOperacion } from '../capa1_dominio/ResultadoOperacion.js';

export class InventarioService {
  constructor({ driver, productoRepo, movimientoRepo, compraRepo, proveedorRepo, seguridad, auditoria }) {
    Object.assign(this, { driver, productoRepo, movimientoRepo, compraRepo, proveedorRepo, seguridad, auditoria });
  }

  consultarCatalogo(filtros) { return this.productoRepo.listar(filtros); }
  consultarKardex(filtros) { return this.movimientoRepo.listar(filtros); }

  async guardarProducto(datos, ctx) {
    const permiso = this.seguridad.verificarPermiso(ctx.usuario.rol, "editarCatalogo");
    if (!permiso.exito) return permiso;

    const existente = datos.id ? await this.productoRepo.buscarPorId(datos.id) : null;
    if (datos.id && !existente) return ResultadoOperacion.fallo("Producto no encontrado.", null, "InventarioService", 404);

    const producto = new Producto(existente?.id ?? null, datos.referencia, datos.nombre, datos.precio, datos.existencias ?? existente?.existencias ?? 0, {
      costo: datos.costo ?? existente?.costo ?? 0, stockMinimo: datos.stockMinimo ?? existente?.stockMinimo ?? 5,
      categoriaId: datos.categoriaId, proveedorId: datos.proveedorId, activo: datos.activo ?? true
    });
    if (!producto.esValido()) {
      return ResultadoOperacion.fallo("Datos de producto inválidos: referencia y nombre obligatorios, precio > 0, costo >= 0, existencias y stock mínimo enteros >= 0.", null, "InventarioService");
    }
    const duplicado = await this.productoRepo.buscarPorReferencia(producto.referencia);
    if (duplicado && duplicado.id !== producto.id) {
      return ResultadoOperacion.fallo(`Ya existe un producto con la referencia '${producto.referencia}'.`, null, "InventarioService", 409);
    }

    await this.driver.transaccion(async () => {
      await this.productoRepo.guardar(producto);
      if (!existente && producto.existencias > 0) {
        await this.movimientoRepo.registrar({ productoId: producto.id, tipo: "INICIAL", cantidad: producto.existencias, stockResultante: producto.existencias, nota: "Stock inicial al crear el producto", usuarioId: ctx.usuario.id });
      } else if (existente && existente.existencias !== producto.existencias) {
        await this.movimientoRepo.registrar({ productoId: producto.id, tipo: "AJUSTE", cantidad: producto.existencias - existente.existencias, stockResultante: producto.existencias, nota: "Ajuste al editar el producto", usuarioId: ctx.usuario.id });
      }
    });
    await this.auditoria.registrar(ctx, existente ? "EDITAR" : "CREAR", "producto", producto.id, `${producto.referencia} - ${producto.nombre}`);
    return ResultadoOperacion.ok(`Producto '${producto.nombre}' guardado en el catálogo.`, await this.productoRepo.buscarPorId(producto.id), "InventarioService", existente ? 200 : 201);
  }

  async desactivarProducto(id, ctx) {
    const permiso = this.seguridad.verificarPermiso(ctx.usuario.rol, "editarCatalogo");
    if (!permiso.exito) return permiso;
    const p = await this.productoRepo.buscarPorId(id);
    if (!p) return ResultadoOperacion.fallo("Producto no encontrado.", null, "InventarioService", 404);
    await this.productoRepo.desactivar(id);
    await this.auditoria.registrar(ctx, "DESACTIVAR", "producto", id, p.nombre);
    return ResultadoOperacion.ok(`Producto '${p.nombre}' desactivado (se conserva el historial).`, null, "InventarioService");
  }

  async ajustarStock(productoId, nuevaCantidad, nota, ctx) {
    const permiso = this.seguridad.verificarPermiso(ctx.usuario.rol, "ajustarStock");
    if (!permiso.exito) return permiso;
    const n = Number(nuevaCantidad);
    if (!Number.isInteger(n) || n < 0) return ResultadoOperacion.fallo("La nueva existencia debe ser un entero >= 0.", null, "InventarioService");
    if (!nota || !String(nota).trim()) return ResultadoOperacion.fallo("Debe indicar el motivo del ajuste de inventario.", null, "InventarioService");
    const resultado = await this.driver.transaccion(async () => {
      const p = await this.productoRepo.buscarPorId(productoId, true);
      if (!p) return ResultadoOperacion.fallo("Producto no encontrado.", null, "InventarioService", 404);
      if (n === p.existencias) return ResultadoOperacion.fallo("La existencia indicada es igual a la actual; no hay nada que ajustar.", null, "InventarioService");
      const anterior = p.existencias;
      p.existencias = n;
      await this.productoRepo.guardar(p);
      await this.movimientoRepo.registrar({ productoId: p.id, tipo: "AJUSTE", cantidad: n - anterior, stockResultante: n, nota: String(nota).trim(), usuarioId: ctx.usuario.id });
      await this.auditoria.registrar(ctx, "AJUSTAR_STOCK", "producto", p.id, `${p.referencia}: ${anterior} → ${n} (${nota})`);
      return ResultadoOperacion.ok(`Existencias de '${p.nombre}' ajustadas de ${anterior} a ${n}.`, p, "InventarioService");
    });
    return resultado;
  }

  // Llamados desde PedidoService dentro de su transacción
  async aplicarDescuentoUnico(itemsPedido, ctx, referencia) {
    for (const item of [...itemsPedido].sort((a, b) => a.productoId - b.productoId)) {
      const prod = await this.productoRepo.buscarPorId(item.productoId, true);
      prod.descontarExistencias(item.cantidad);
      await this.productoRepo.guardar(prod);
      await this.movimientoRepo.registrar({ productoId: prod.id, tipo: "SALIDA_PEDIDO", cantidad: -item.cantidad, stockResultante: prod.existencias, referencia, usuarioId: ctx.usuario.id });
    }
  }
  async restituirInventarioPorCancelacion(itemsPedido, ctx, referencia) {
    for (const item of [...itemsPedido].sort((a, b) => a.productoId - b.productoId)) {
      const prod = await this.productoRepo.buscarPorId(item.productoId, true);
      if (prod) {
        prod.restituirExistencias(item.cantidad);
        await this.productoRepo.guardar(prod);
        await this.movimientoRepo.registrar({ productoId: prod.id, tipo: "DEVOLUCION_PEDIDO", cantidad: item.cantidad, stockResultante: prod.existencias, referencia, nota: "Pedido rechazado/cancelado", usuarioId: ctx.usuario.id });
      }
    }
  }

  // --- Compras / ingreso de mercancía ---
  listarCompras() { return this.compraRepo.listar(); }
  async obtenerCompra(id) {
    const c = await this.compraRepo.buscarPorId(id);
    return c ? ResultadoOperacion.ok("Compra encontrada.", c, "InventarioService") : ResultadoOperacion.fallo("Compra no encontrada.", null, "InventarioService", 404);
  }
  async registrarCompra({ proveedorId, nota, items }, ctx) {
    const permiso = this.seguridad.verificarPermiso(ctx.usuario.rol, "registrarCompra");
    if (!permiso.exito) return permiso;
    if (!proveedorId || !(await this.proveedorRepo.buscarPorId(proveedorId))) return ResultadoOperacion.fallo("Seleccione un proveedor válido.", null, "InventarioService");
    if (!Array.isArray(items) || !items.length) return ResultadoOperacion.fallo("La compra debe tener al menos un producto.", null, "InventarioService");

    const lineas = [];
    for (const it of items) {
      const cant = Number(it.cantidad), costo = Number(it.costoUnitario);
      if (!Number.isInteger(cant) || cant <= 0) return ResultadoOperacion.fallo(`Cantidad inválida (${it.cantidad}): debe ser un entero > 0.`, null, "InventarioService");
      if (!Number.isFinite(costo) || costo < 0) return ResultadoOperacion.fallo(`Costo unitario inválido (${it.costoUnitario}).`, null, "InventarioService");
      const prod = await this.productoRepo.buscarPorId(it.productoId);
      if (!prod) return ResultadoOperacion.fallo(`Producto ${it.productoId} no encontrado.`, null, "InventarioService", 404);
      lineas.push({ prod, cantidad: cant, costoUnitario: costo });
    }
    const compra = await this.driver.transaccion(async () => {
      const c = await this.compraRepo.crear({ proveedorId, nota: nota || null, usuarioId: ctx.usuario.id, items: lineas.map(l => ({ productoId: l.prod.id, cantidad: l.cantidad, costoUnitario: l.costoUnitario })) });
      for (const l of lineas) {
        const p = await this.productoRepo.buscarPorId(l.prod.id, true); // relee: puede haber líneas repetidas
        p.aumentarExistencias(l.cantidad);
        if (l.costoUnitario > 0) p.costo = l.costoUnitario;
        await this.productoRepo.guardar(p);
        await this.movimientoRepo.registrar({ productoId: p.id, tipo: "ENTRADA_COMPRA", cantidad: l.cantidad, stockResultante: p.existencias, referencia: c.codigo, nota, usuarioId: ctx.usuario.id });
      }
      return c;
    });
    await this.auditoria.registrar(ctx, "CREAR", "compra", compra.id, `${compra.codigo} por $${compra.total.toLocaleString("es-CO")}`);
    return ResultadoOperacion.ok(`Compra ${compra.codigo} registrada: el inventario fue incrementado.`, await this.compraRepo.buscarPorId(compra.id), "InventarioService", 201);
  }
}
