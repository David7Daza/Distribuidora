// CAPA 3: LÓGICA DE NEGOCIO - Seguridad y permisos por rol (Sección 5.7, ampliada)
import { ResultadoOperacion } from '../capa1_dominio/ResultadoOperacion.js';

export class ControlAccesoRolService {
  constructor() {
    const T = true, F = false;
    this.matrizPermisos = {
      //         consultar editarCatalogo registrarPedido despachar rechazar gestionarClientes gestionarProveedores registrarCompra ajustarStock registrarPago verReportes gestionarUsuarios verAuditoria restaurarDatos
      ADMIN:  { consultar: T, editarCatalogo: T, registrarPedido: T, despachar: T, rechazar: T, gestionarClientes: T, gestionarProveedores: T, registrarCompra: T, ajustarStock: T, registrarPago: T, verReportes: T, gestionarUsuarios: T, verAuditoria: T, restaurarDatos: T },
      VENTAS: { consultar: T, editarCatalogo: F, registrarPedido: T, despachar: F, rechazar: T, gestionarClientes: T, gestionarProveedores: F, registrarCompra: F, ajustarStock: F, registrarPago: F, verReportes: F, gestionarUsuarios: F, verAuditoria: F, restaurarDatos: F },
      BODEGA: { consultar: T, editarCatalogo: T, registrarPedido: F, despachar: T, rechazar: T, gestionarClientes: F, gestionarProveedores: T, registrarCompra: T, ajustarStock: T, registrarPago: F, verReportes: F, gestionarUsuarios: F, verAuditoria: F, restaurarDatos: F }
    };
  }
  permisosDe(rol) { return this.matrizPermisos[rol] || {}; }
  verificarPermiso(rol, accion) {
    const permisosRol = this.matrizPermisos[rol]; // rol desconocido => sin permisos
    if (!permisosRol || !permisosRol[accion]) {
      return ResultadoOperacion.fallo(
        `Seguridad de Roles (Apartado 5.7): El rol '${rol}' no tiene autorización para ejecutar la acción '${accion}'.`,
        null, "ControlAccesoRolService", 403
      );
    }
    return ResultadoOperacion.ok("Permiso concedido.", null, "ControlAccesoRolService");
  }
}
