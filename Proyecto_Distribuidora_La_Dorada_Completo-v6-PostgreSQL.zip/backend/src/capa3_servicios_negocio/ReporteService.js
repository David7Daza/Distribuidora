// CAPA 3: LÓGICA DE NEGOCIO - Dashboard, KPIs (Sección 5.9) y reportes (consultas PostgreSQL)
import { ResultadoOperacion } from '../capa1_dominio/ResultadoOperacion.js';

const R = ResultadoOperacion;
const VENTA = `o.estado IN ('Confirmado','Despachado')`;
// Total pagado por pedido (se une a pedidos para calcular saldos sin subconsultas correlacionadas dentro de agregados)
const PAGADO = `LEFT JOIN (SELECT pedido_id, SUM(monto) AS pagado FROM pagos GROUP BY pedido_id) pg ON pg.pedido_id = o.id`;
// Utilidad bruta por pedido = SUM(cantidad * (precio_unitario - costo actual del producto))
const UTIL = `LEFT JOIN (SELECT i.pedido_id, SUM(i.cantidad * (i.precio_unitario - COALESCE(pr.costo, 0))) AS utilidad
                         FROM pedido_items i LEFT JOIN productos pr ON pr.id = i.producto_id GROUP BY i.pedido_id) ut ON ut.pedido_id = o.id`;

export class ReporteService {
  constructor({ driver, pedidoService, seguridad }) {
    Object.assign(this, { db: driver, pedidoService, seguridad });
  }

  async dashboard() {
    const db = this.db;
    const resumen = await this.pedidoService.obtenerResumenPorEstado();
    const ventasHoy = await db.uno(`SELECT COALESCE(SUM(total),0) AS t, COUNT(*) AS n FROM pedidos o WHERE ${VENTA} AND o.confirmado::date = CURRENT_DATE`);
    const ventasMes = await db.uno(`SELECT COALESCE(SUM(total),0) AS t, COUNT(*) AS n FROM pedidos o WHERE ${VENTA} AND date_trunc('month', o.confirmado) = date_trunc('month', LOCALTIMESTAMP)`);
    const porCobrar = (await db.uno(`SELECT COALESCE(SUM(o.total - COALESCE(pg.pagado,0)),0) AS t FROM pedidos o ${PAGADO} WHERE ${VENTA}`)).t;
    const ventasDiarias = await db.query(`
      SELECT to_char(d, 'YYYY-MM-DD') AS fecha, COALESCE(SUM(o.total),0) AS total, COUNT(o.id) AS pedidos
      FROM generate_series(CURRENT_DATE - 13, CURRENT_DATE, interval '1 day') AS d
      LEFT JOIN pedidos o ON ${VENTA} AND o.confirmado::date = d::date
      GROUP BY d ORDER BY d`);
    const topProductos = await db.query(`
      SELECT i.referencia, i.nombre, SUM(i.cantidad) AS unidades, SUM(i.cantidad*i.precio_unitario) AS ingresos
      FROM pedido_items i JOIN pedidos o ON o.id=i.pedido_id WHERE ${VENTA}
      GROUP BY i.producto_id, i.referencia, i.nombre ORDER BY unidades DESC LIMIT 5`);
    const topClientes = await db.query(`
      SELECT cliente_nombre AS cliente, COUNT(*) AS pedidos, SUM(total) AS total
      FROM pedidos o WHERE ${VENTA} GROUP BY cliente_nombre ORDER BY total DESC LIMIT 5`);
    const stockBajo = await db.query(`SELECT id,referencia,nombre,existencias,stock_minimo FROM productos WHERE activo=1 AND existencias<=stock_minimo ORDER BY (existencias*1.0/GREATEST(stock_minimo,1)) LIMIT 10`);
    const inventario = await db.uno(`SELECT COUNT(*) AS productos, COALESCE(SUM(existencias),0) AS unidades, COALESCE(SUM(existencias*costo),0) AS "valorCosto", COALESCE(SUM(existencias*precio),0) AS "valorVenta" FROM productos WHERE activo=1`);

    // KPIs de la Sección 5.9: minutos promedio entre registro y confirmación
    const t = (await db.uno(`SELECT AVG(EXTRACT(EPOCH FROM (confirmado - creado)) / 60.0) AS m FROM pedidos WHERE confirmado IS NOT NULL`)).m;
    const tasaRechazo = resumen.total ? Math.round((resumen.Rechazado / resumen.total) * 1000) / 10 : 0;
    const recientes = (await this.pedidoService.listarPedidos({})).slice(0, 6).map(p => ({ id: p.id, codigo: p.codigo, cliente: p.cliente, estado: p.estado, total: p.total, fecha: p.fecha }));

    return R.ok("Dashboard.", {
      resumen, ventasHoy, ventasMes, porCobrar, ventasDiarias, topProductos, topClientes, stockBajo, inventario, recientes,
      kpis: { tiempoConfirmacionMin: t == null ? null : Math.round(t * 10) / 10, tasaRechazoPct: tasaRechazo }
    }, "ReporteService");
  }

  _permiso(ctx) { return this.seguridad.verificarPermiso(ctx.usuario.rol, "verReportes"); }

  async ventas({ desde, hasta, agrupar = 'dia' }, ctx) {
    const p = this._permiso(ctx); if (!p.exito) return p;
    const fmt = agrupar === 'mes' ? 'YYYY-MM' : 'YYYY-MM-DD';
    const filas = await this.db.query(`
      SELECT to_char(o.confirmado, ?) AS periodo, COUNT(*) AS pedidos, SUM(o.total) AS ventas, SUM(ut.utilidad) AS utilidad
      FROM pedidos o ${UTIL}
      WHERE ${VENTA} AND o.confirmado::date BETWEEN ?::date AND ?::date
      GROUP BY periodo ORDER BY periodo`, [fmt, desde || '1900-01-01', hasta || '2999-12-31']);
    return R.ok("Ventas por periodo.", filas, "ReporteService");
  }
  async ventasPorProducto({ desde, hasta }, ctx) {
    const p = this._permiso(ctx); if (!p.exito) return p;
    const filas = await this.db.query(`
      SELECT i.referencia, i.nombre, SUM(i.cantidad) AS unidades, SUM(i.cantidad*i.precio_unitario) AS ingresos,
             SUM(i.cantidad*(i.precio_unitario - COALESCE(pr.costo,0))) AS utilidad
      FROM pedido_items i JOIN pedidos o ON o.id=i.pedido_id LEFT JOIN productos pr ON pr.id=i.producto_id
      WHERE ${VENTA} AND o.confirmado::date BETWEEN ?::date AND ?::date
      GROUP BY i.producto_id, i.referencia, i.nombre ORDER BY ingresos DESC`, [desde || '1900-01-01', hasta || '2999-12-31']);
    return R.ok("Ventas por producto.", filas, "ReporteService");
  }
  async ventasPorCliente({ desde, hasta }, ctx) {
    const p = this._permiso(ctx); if (!p.exito) return p;
    const filas = await this.db.query(`
      SELECT o.cliente_nombre AS cliente, COUNT(*) AS pedidos, SUM(o.total) AS ventas, SUM(o.total - COALESCE(pg.pagado,0)) AS saldo
      FROM pedidos o ${PAGADO}
      WHERE ${VENTA} AND o.confirmado::date BETWEEN ?::date AND ?::date
      GROUP BY o.cliente_nombre ORDER BY ventas DESC`, [desde || '1900-01-01', hasta || '2999-12-31']);
    return R.ok("Ventas por cliente.", filas, "ReporteService");
  }
  async cierreCaja({ fecha }, ctx) {
    const p = this._permiso(ctx); if (!p.exito) return p;
    const f = fecha || new Date().toISOString().slice(0, 10);
    const pagos = await this.db.query(`SELECT g.id, g.monto, g.metodo, g.fecha, o.codigo, o.cliente_nombre AS cliente FROM pagos g JOIN pedidos o ON o.id=g.pedido_id WHERE g.fecha::date = ?::date ORDER BY g.id`, [f]);
    const porMetodo = await this.db.query(`SELECT metodo, COUNT(*) AS pagos, SUM(monto) AS total FROM pagos WHERE fecha::date = ?::date GROUP BY metodo ORDER BY metodo`, [f]);
    return R.ok("Cierre de caja.", { fecha: f, total: pagos.reduce((a, x) => a + x.monto, 0), porMetodo, pagos }, "ReporteService");
  }
  async cuentasPorCobrar(ctx) {
    const p = this._permiso(ctx); if (!p.exito) return p;
    const filas = await this.db.query(`
      SELECT * FROM (
        SELECT o.id, o.codigo, o.cliente_nombre AS cliente, o.estado, o.confirmado, o.total,
               COALESCE(pg.pagado,0) AS pagado, o.total - COALESCE(pg.pagado,0) AS saldo,
               (CURRENT_DATE - o.confirmado::date) AS dias
        FROM pedidos o ${PAGADO} WHERE ${VENTA}) x
      WHERE saldo > 0 ORDER BY dias DESC`);
    return R.ok("Cuentas por cobrar.", filas, "ReporteService");
  }
}
