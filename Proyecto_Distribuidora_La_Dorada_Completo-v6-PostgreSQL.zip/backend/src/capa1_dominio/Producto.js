// CAPA 1: DOMINIO - Entidad Producto (con categoría, proveedor, costo y stock mínimo)
export class Producto {
  constructor(id, referencia, nombre, precio, existencias, extra = {}) {
    this.id = id;
    this.referencia = String(referencia ?? "").trim();
    this.nombre = String(nombre ?? "").trim();
    this.precio = Number(precio);
    this.existencias = Number(existencias);
    this.costo = Number(extra.costo ?? 0);
    this.stockMinimo = Number(extra.stockMinimo ?? 5);
    this.categoriaId = extra.categoriaId ? Number(extra.categoriaId) : null;
    this.proveedorId = extra.proveedorId ? Number(extra.proveedorId) : null;
    this.categoria = extra.categoria ?? null;
    this.proveedor = extra.proveedor ?? null;
    this.activo = extra.activo === undefined ? true : Boolean(extra.activo);
  }
  esValido() {
    return (
      this.referencia.length > 0 &&
      this.nombre.length > 0 &&
      Number.isFinite(this.precio) && this.precio > 0 &&
      Number.isFinite(this.costo) && this.costo >= 0 &&
      Number.isInteger(this.existencias) && this.existencias >= 0 &&
      Number.isInteger(this.stockMinimo) && this.stockMinimo >= 0
    );
  }
  tieneStockSuficiente(cantidadSolicitada) {
    return this.existencias >= Number(cantidadSolicitada);
  }
  estaBajoMinimo() {
    return this.existencias <= this.stockMinimo;
  }
  margenPorcentaje() {
    return this.precio > 0 ? Math.round(((this.precio - this.costo) / this.precio) * 1000) / 10 : 0;
  }
  descontarExistencias(cantidad) {
    const cant = Number(cantidad);
    if (cant <= 0) throw new Error("La cantidad a descontar debe ser mayor a cero.");
    if (!this.tieneStockSuficiente(cant)) {
      throw new Error(`Stock insuficiente para ${this.nombre}. Disponible: ${this.existencias}, Solicitado: ${cant}`);
    }
    this.existencias -= cant;
  }
  restituirExistencias(cantidad) {
    const cant = Number(cantidad);
    if (cant > 0) this.existencias += cant;
  }
  aumentarExistencias(cantidad) {
    const cant = Number(cantidad);
    if (!Number.isInteger(cant) || cant <= 0) throw new Error("La cantidad a ingresar debe ser un entero mayor a cero.");
    this.existencias += cant;
  }
}
