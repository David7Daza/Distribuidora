// CAPA 1: DOMINIO - DTO / Value Object para transporte entre capas (ahora con código HTTP sugerido)
export class ResultadoOperacion {
  constructor(exito, mensaje, datos = null, capaOrigen = "Dominio", http = exito ? 200 : 400) {
    this.exito = Boolean(exito);
    this.mensaje = mensaje;
    this.datos = datos;
    this.capaOrigen = capaOrigen;
    this.http = http;
    this.timestamp = new Date().toLocaleTimeString("es-CO");
  }
  static ok(mensaje, datos = null, capa = "Servicio", http = 200) {
    return new ResultadoOperacion(true, mensaje, datos, capa, http);
  }
  static fallo(mensaje, datos = null, capa = "ValidadorReglasNegocio", http = 400) {
    return new ResultadoOperacion(false, mensaje, datos, capa, http);
  }
  aJSON() {
    const { http, ...resto } = this;
    return resto;
  }
}
