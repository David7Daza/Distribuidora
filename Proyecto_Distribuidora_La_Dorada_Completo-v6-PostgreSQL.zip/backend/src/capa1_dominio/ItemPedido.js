// CAPA 1: DOMINIO - Entidad Detalle/Ítem de Pedido
export class ItemPedido {
  constructor(productoId, referencia, nombre, precioUnitario, cantidad) {
    this.productoId = Number(productoId);
    this.referencia = referencia;
    this.nombre = nombre;
    this.precioUnitario = Number(precioUnitario);
    this.cantidad = Number(cantidad);
  }
  tieneCantidadValida() {
    return Number.isInteger(this.cantidad) && this.cantidad > 0;
  }
  calcularSubtotal() {
    return this.cantidad * this.precioUnitario;
  }
}
