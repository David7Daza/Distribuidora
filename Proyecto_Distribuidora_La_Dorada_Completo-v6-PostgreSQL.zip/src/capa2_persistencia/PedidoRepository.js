// CAPA 2: PERSISTENCIA - Clase Repositorio de Pedidos
import { Pedido } from '../capa1_dominio/Pedido.js';

export class PedidoRepository {
  constructor(storageDriver) {
    this.driver = storageDriver;
  }
  listarTodos() {
    const data = this.driver.leerEstado();
    return (data.pedidos || []).map(
      o => new Pedido(o.id, o.cliente, o.nota, o.fecha, o.estado, o.stockDescontado, o.items)
    );
  }
  buscarPorId(id) {
    return this.listarTodos().find(o => o.id === id) || null;
  }
  guardar(pedidoEntidad) {
    const data = this.driver.leerEstado();
    const pedidos = data.pedidos || [];
    const idx = pedidos.findIndex(o => o.id === pedidoEntidad.id);
    const plain = {
      id: pedidoEntidad.id,
      cliente: pedidoEntidad.cliente,
      nota: pedidoEntidad.nota,
      fecha: pedidoEntidad.fecha,
      estado: pedidoEntidad.estado,
      stockDescontado: pedidoEntidad.stockDescontado,
      total: pedidoEntidad.calcularTotal(),
      items: pedidoEntidad.items.map(i => ({
        productoId: i.productoId,
        referencia: i.referencia,
        nombre: i.nombre,
        precioUnitario: i.precioUnitario,
        cantidad: i.cantidad
      }))
    };
    if (idx >= 0) {
      pedidos[idx] = plain;
    } else {
      pedidos.unshift(plain);
    }
    data.pedidos = pedidos;
    this.driver.escribirEstado(data);
    return pedidoEntidad;
  }
}
