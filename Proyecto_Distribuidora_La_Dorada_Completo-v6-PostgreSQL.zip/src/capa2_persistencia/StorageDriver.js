// CAPA 2: PERSISTENCIA - Clase conductora de almacenamiento LocalStorage
export class StorageDriver {
  constructor(storageKey = "distribuidora_la_dorada_db_v1") {
    this.storageKey = storageKey;
  }
  obtenerSemillaInicial() {
    return {
      productos: [
        { id: "PROD-1", referencia: "ASEO-001", nombre: "Detergente Líquido Multiusos 1L", precio: 9500, existencias: 20 },
        { id: "PROD-2", referencia: "ASEO-002", nombre: "Jabón en Barra Multiusos 300g", precio: 3800, existencias: 8 },
        { id: "PROD-3", referencia: "ASEO-003", nombre: "Hipoclorito Blanqueador Desinfectante 2L", precio: 6200, existencias: 35 },
        { id: "PROD-4", referencia: "ASEO-004", nombre: "Desengrasante Industrial Cocina 1L", precio: 12000, existencias: 14 },
        { id: "PROD-5", referencia: "ASEO-005", nombre: "Ambientador Pisos Lavanda 1L", precio: 7500, existencias: 18 }
      ],
      pedidos: []
    };
  }
  leerEstado() {
    const raw = localStorage.getItem(this.storageKey);
    if (!raw) {
      const seed = this.obtenerSemillaInicial();
      this.escribirEstado(seed);
      return seed;
    }
    try {
      return JSON.parse(raw);
    } catch (e) {
      const seed = this.obtenerSemillaInicial();
      this.escribirEstado(seed);
      return seed;
    }
  }
  escribirEstado(data) {
    localStorage.setItem(this.storageKey, JSON.stringify(data));
  }
  restaurarSemilla() {
    const seed = this.obtenerSemillaInicial();
    this.escribirEstado(seed);
    return seed;
  }
}
