// CAPA 2: PERSISTENCIA - Clase Repositorio de Productos
import { Producto } from '../capa1_dominio/Producto.js';

export class ProductoRepository {
  constructor(storageDriver) {
    this.driver = storageDriver;
  }
  listarTodos() {
    const data = this.driver.leerEstado();
    return (data.productos || []).map(
      p => new Producto(p.id, p.referencia, p.nombre, p.precio, p.existencias)
    );
  }
  buscarPorId(id) {
    return this.listarTodos().find(p => p.id === id) || null;
  }
  guardar(productoEntidad) {
    const data = this.driver.leerEstado();
    const productos = data.productos || [];
    const idx = productos.findIndex(p => p.id === productoEntidad.id);
    const plain = {
      id: productoEntidad.id,
      referencia: productoEntidad.referencia,
      nombre: productoEntidad.nombre,
      precio: productoEntidad.precio,
      existencias: productoEntidad.existencias
    };
    if (idx >= 0) {
      productos[idx] = plain;
    } else {
      productos.push(plain);
    }
    data.productos = productos;
    this.driver.escribirEstado(data);
    return productoEntidad;
  }
}
