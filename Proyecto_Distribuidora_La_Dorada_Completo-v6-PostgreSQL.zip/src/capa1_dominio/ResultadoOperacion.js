// CAPA 1: DOMINIO - Clase DTO / Value Object para transporte entre capas
export class ResultadoOperacion {
  constructor(exito, mensaje, datos = null, capaOrigen = "Dominio") {
    this.exito = Boolean(exito);
    this.mensaje = mensaje;
    this.datos = datos;
    this.capaOrigen = capaOrigen;
    this.timestamp = new Date().toLocaleTimeString("es-CO");
  }
  static ok(mensaje, datos = null, capa = "Servicio") {
    return new ResultadoOperacion(true, mensaje, datos, capa);
  }
  static fallo(mensaje, datos = null, capa = "ValidadorReglasNegocio") {
    return new ResultadoOperacion(false, mensaje, datos, capa);
  }
}
