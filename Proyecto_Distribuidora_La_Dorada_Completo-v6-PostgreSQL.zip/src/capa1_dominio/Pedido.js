// CAPA 1: DOMINIO - Entidad Raíz Pedido
import { ItemPedido } from './ItemPedido.js';

export class Pedido {
  constructor(id, cliente, nota, fecha, estado = "Pendiente", stockDescontado = false, items = []) {
    this.id = id;
    this.cliente = String(cliente).trim();
    this.nota = String(nota || "WhatsApp").trim();
    this.fecha = fecha || new Date().toLocaleString("es-CO");
    this.estado = estado; // Pendiente | Confirmado | Despachado | Rechazado
    this.stockDescontado = Boolean(stockDescontado);
    this.items = items.map(i =>
      i instanceof ItemPedido
        ? i
        : new ItemPedido(i.productoId, i.referencia, i.nombre, i.precioUnitario, i.cantidad)
    );
    this.total = this.calcularTotal();
  }
  calcularTotal() {
    return this.items.reduce((acc, item) => acc + item.calcularSubtotal(), 0);
  }
  confirmarConDescuentoUnico() {
    if (this.stockDescontado) {
      throw new Error(`El pedido ${this.id} ya tiene existencias descontadas.`);
    }
    this.estado = "Confirmado";
    this.stockDescontado = true;
  }
  marcarDespachado() {
    if (this.estado !== "Confirmado") {
      throw new Error("Solo se pueden despachar pedidos en estado Confirmado.");
    }
    this.estado = "Despachado";
  }
  marcarRechazado() {
    if (this.estado === "Despachado") {
      throw new Error("No se puede rechazar un pedido ya Despachado.");
    }
    this.estado = "Rechazado";
    this.stockDescontado = false;
  }
}
