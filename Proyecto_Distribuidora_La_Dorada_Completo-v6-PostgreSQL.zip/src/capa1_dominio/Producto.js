// CAPA 1: DOMINIO - Entidad Producto
export class Producto {
  constructor(id, referencia, nombre, precio, existencias) {
    this.id = id;
    this.referencia = String(referencia).trim();
    this.nombre = String(nombre).trim();
    this.precio = Number(precio);
    this.existencias = Number(existencias);
  }
  esValido() {
    return (
      this.referencia.length > 0 &&
      this.nombre.length > 0 &&
      Number.isFinite(this.precio) &&
      this.precio > 0 &&
      Number.isInteger(this.existencias) &&
      this.existencias >= 0
    );
  }
  tieneStockSuficiente(cantidadSolicitada) {
    return this.existencias >= Number(cantidadSolicitada);
  }
  descontarExistencias(cantidad) {
    const cant = Number(cantidad);
    if (cant <= 0) throw new Error("La cantidad a descontar debe ser mayor a cero.");
    if (!this.tieneStockSuficiente(cant)) {
      throw new Error(`Stock insuficiente para ${this.nombre}. Disponible: ${this.existencias}, Solicitado: ${cant}`);
    }
    this.existencias -= cant;
  }
  restituirExistencias(cantidad) {
    const cant = Number(cantidad);
    if (cant > 0) this.existencias += cant;
  }
}
