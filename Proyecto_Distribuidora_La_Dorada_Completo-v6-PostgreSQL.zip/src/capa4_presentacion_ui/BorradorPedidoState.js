// CAPA 4: PRESENTACIÓN - Clase Gestora del Carrito/Borrador en Interfaz
import { ItemPedido } from '../capa1_dominio/ItemPedido.js';
import { ResultadoOperacion } from '../capa1_dominio/ResultadoOperacion.js';

export class BorradorPedidoState {
  constructor(validadorReglas, productoRepository) {
    this.validador = validadorReglas;
    this.productoRepo = productoRepository;
    this.items = [];
  }
  agregarItem(productoId, cantidad) {
    const check = this.validador.validarCantidadPositiva(cantidad);
    if (!check.exito) return check;

    const prod = this.productoRepo.buscarPorId(productoId);
    if (!prod) return ResultadoOperacion.fallo("Producto no encontrado.", null, "BorradorPedidoState");

    const existente = this.items.find(i => i.productoId === productoId);
    if (existente) {
      existente.cantidad += Number(cantidad);
    } else {
      this.items.push(new ItemPedido(prod.id, prod.referencia, prod.nombre, prod.precio, Number(cantidad)));
    }
    return ResultadoOperacion.ok(`Se agregaron ${cantidad} uds de ${prod.nombre} al borrador.`, this.items, "BorradorPedidoState");
  }
  quitarItem(productoId) {
    this.items = this.items.filter(i => i.productoId !== productoId);
  }
  limpiar() {
    this.items = [];
  }
  calcularTotalBorrador() {
    return this.items.reduce((acc, i) => acc + i.calcularSubtotal(), 0);
  }
}
