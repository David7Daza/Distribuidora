// CAPA 3: LÓGICA DE NEGOCIO - Clase Servicio de Catálogo e Inventario
import { Producto } from '../capa1_dominio/Producto.js';
import { ResultadoOperacion } from '../capa1_dominio/ResultadoOperacion.js';

export class InventarioService {
  constructor(productoRepository, controlAccesoRolService) {
    this.productoRepo = productoRepository;
    this.seguridadService = controlAccesoRolService;
  }
  consultarCatalogo() {
    return this.productoRepo.listarTodos();
  }
  guardarProducto({ id, referencia, nombre, precio, existencias }, rolActivo = "ADMIN") {
    const permiso = this.seguridadService.verificarPermiso(rolActivo, "editarCatalogo");
    if (!permiso.exito) return permiso;

    const nuevoId = id || "PROD-" + (this.productoRepo.listarTodos().length + 1 + Math.floor(Math.random() * 900));
    const producto = new Producto(nuevoId, referencia, nombre, precio, existencias);
    if (!producto.esValido()) {
      return ResultadoOperacion.fallo(
        "Datos de producto inválidos: Verifique que el precio sea > 0 y las existencias un entero >= 0.",
        null,
        "InventarioService"
      );
    }
    this.productoRepo.guardar(producto);
    return ResultadoOperacion.ok(`Producto '${producto.nombre}' guardado en el catálogo.`, producto, "InventarioService");
  }
  aplicarDescuentoUnico(itemsPedido) {
    for (const item of itemsPedido) {
      const prod = this.productoRepo.buscarPorId(item.productoId);
      prod.descontarExistencias(item.cantidad);
      this.productoRepo.guardar(prod);
    }
  }
  restituirInventarioPorCancelacion(itemsPedido) {
    for (const item of itemsPedido) {
      const prod = this.productoRepo.buscarPorId(item.productoId);
      if (prod) {
        prod.restituirExistencias(item.cantidad);
        this.productoRepo.guardar(prod);
      }
    }
  }
}
