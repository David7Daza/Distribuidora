// CAPA 3: LÓGICA DE NEGOCIO - Clase Servicio Transaccional de Pedidos
import { Pedido } from '../capa1_dominio/Pedido.js';
import { ResultadoOperacion } from '../capa1_dominio/ResultadoOperacion.js';

export class PedidoService {
  constructor(pedidoRepository, productoRepository, inventarioService, validadorReglas, controlAccesoRolService) {
    this.pedidoRepo = pedidoRepository;
    this.productoRepo = productoRepository;
    this.inventarioService = inventarioService;
    this.validador = validadorReglas;
    this.seguridad = controlAccesoRolService;
  }

  listarPedidos(filtroEstado = "TODOS") {
    const todos = this.pedidoRepo.listarTodos();
    if (filtroEstado === "TODOS") return todos;
    return todos.filter(p => p.estado === filtroEstado);
  }

  registrarPedido({ cliente, nota, items, confirmarInmediatamente }, rolActivo = "ADMIN") {
    const permiso = this.seguridad.verificarPermiso(rolActivo, "registrarPedido");
    if (!permiso.exito) return permiso;

    if (!cliente || !String(cliente).trim()) {
      return ResultadoOperacion.fallo("Debe ingresar el nombre del cliente.", null, "PedidoService");
    }
    if (!items || items.length === 0) {
      return ResultadoOperacion.fallo("Debe agregar al menos un producto al pedido.", null, "PedidoService");
    }

    for (const item of items) {
      const vCant = this.validador.validarCantidadPositiva(item.cantidad);
      if (!vCant.exito) return vCant;
    }

    const nuevoCodigo = "PED-" + (1001 + this.pedidoRepo.listarTodos().length);
    const fechaActual = new Date().toLocaleString("es-CO");

    if (!confirmarInmediatamente) {
      const pedidoPendiente = new Pedido(nuevoCodigo, cliente, nota, fechaActual, "Pendiente", false, items);
      this.pedidoRepo.guardar(pedidoPendiente);
      return ResultadoOperacion.ok(
        `Pedido ${nuevoCodigo} registrado en estado PENDIENTE (sin descontar existencias todavía).`,
        pedidoPendiente,
        "PedidoService"
      );
    }

    const validacionStock = this.validador.validarDisponibilidadInventario(items, this.productoRepo);
    if (!validacionStock.exito) return validacionStock;

    this.inventarioService.aplicarDescuentoUnico(items);
    const pedidoConfirmado = new Pedido(nuevoCodigo, cliente, nota, fechaActual, "Confirmado", true, items);
    this.pedidoRepo.guardar(pedidoConfirmado);

    return ResultadoOperacion.ok(
      `PEDIDO CONFIRMADO EXITOSAMENTE (${nuevoCodigo}): Existencias verificadas y descontadas una sola vez.`,
      pedidoConfirmado,
      "PedidoService"
    );
  }

  cambiarEstadoPedido(pedidoId, nuevoEstado, rolActivo = "ADMIN") {
    const pedido = this.pedidoRepo.buscarPorId(pedidoId);
    if (!pedido) {
      return ResultadoOperacion.fallo(`No se encontró el pedido ${pedidoId}.`, null, "PedidoService");
    }

    if (nuevoEstado === "Despachado") {
      const perm = this.seguridad.verificarPermiso(rolActivo, "despachar");
      if (!perm.exito) return perm;
    }

    const vTrans = this.validador.validarTransicionEstado(pedido, nuevoEstado);
    if (!vTrans.exito) return vTrans;

    if (nuevoEstado === "Confirmado") {
      const vStock = this.validador.validarDisponibilidadInventario(pedido.items, this.productoRepo);
      if (!vStock.exito) return vStock;

      this.inventarioService.aplicarDescuentoUnico(pedido.items);
      pedido.confirmarConDescuentoUnico();
      this.pedidoRepo.guardar(pedido);
      return ResultadoOperacion.ok(
        `Pedido ${pedido.id} confirmado. Se descontaron las existencias una única vez.`,
        pedido,
        "PedidoService"
      );
    }

    if (nuevoEstado === "Despachado") {
      pedido.marcarDespachado();
      this.pedidoRepo.guardar(pedido);
      return ResultadoOperacion.ok(
        `Pedido ${pedido.id} marcado como DESPACHADO por bodega (sin volver a descontar stock).`,
        pedido,
        "PedidoService"
      );
    }

    if (nuevoEstado === "Rechazado") {
      const teniaStockDescontado = pedido.estado === "Confirmado" && pedido.stockDescontado;
      if (teniaStockDescontado) {
        this.inventarioService.restituirInventarioPorCancelacion(pedido.items);
      }
      pedido.marcarRechazado();
      this.pedidoRepo.guardar(pedido);
      return ResultadoOperacion.ok(
        teniaStockDescontado
          ? `Pedido ${pedido.id} cancelado/rechazado. Se restituyeron las unidades al inventario.`
          : `Pedido ${pedido.id} marcado como RECHAZADO (no tenía descuento previo de stock).`,
        pedido,
        "PedidoService"
      );
    }

    return ResultadoOperacion.fallo("Estado no reconocido.", null, "PedidoService");
  }

  obtenerResumenPorEstado() {
    const todos = this.pedidoRepo.listarTodos();
    return {
      total: todos.length,
      Pendiente: todos.filter(p => p.estado === "Pendiente").length,
      Confirmado: todos.filter(p => p.estado === "Confirmado").length,
      Despachado: todos.filter(p => p.estado === "Despachado").length,
      Rechazado: todos.filter(p => p.estado === "Rechazado").length
    };
  }
}
