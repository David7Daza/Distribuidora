// CAPA 3: LÓGICA DE NEGOCIO - Clase de Seguridad y Permisos por Rol (Sección 5.7)
import { ResultadoOperacion } from '../capa1_dominio/ResultadoOperacion.js';

export class ControlAccesoRolService {
  constructor() {
    this.matrizPermisos = {
      ADMIN:  { consultar: true, editarCatalogo: true,  registrarPedido: true,  despachar: true,  rechazar: true },
      VENTAS: { consultar: true, editarCatalogo: false, registrarPedido: true,  despachar: false, rechazar: true },
      BODEGA: { consultar: true, editarCatalogo: true,  registrarPedido: false, despachar: true,  rechazar: true }
    };
  }
  verificarPermiso(rol, accion) {
    const permisosRol = this.matrizPermisos[rol] || this.matrizPermisos.ADMIN;
    if (!permisosRol[accion]) {
      return ResultadoOperacion.fallo(
        `Seguridad de Roles (Apartado 5.7): El rol '${rol}' no tiene autorización para ejecutar la acción '${accion}'.`,
        null,
        "ControlAccesoRolService"
      );
    }
    return ResultadoOperacion.ok("Permiso concedido.", null, "ControlAccesoRolService");
  }
}
