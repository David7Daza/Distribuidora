// CAPA 3: LÓGICA DE NEGOCIO - Clase Validadora de Reglas Obligatorias (Sección 4)
import { ResultadoOperacion } from '../capa1_dominio/ResultadoOperacion.js';

export class ValidadorReglasNegocio {
  validarCantidadPositiva(cantidad) {
    const n = Number(cantidad);
    if (!Number.isInteger(n) || n <= 0) {
      return ResultadoOperacion.fallo(
        `REGLA DE NEGOCIO BLOQUEADA: Se rechazó la cantidad (${cantidad}). Solo se permiten cantidades enteras mayores a cero (> 0).`,
        null,
        "ValidadorReglasNegocio"
      );
    }
    return ResultadoOperacion.ok("Cantidad válida (> 0).", n, "ValidadorReglasNegocio");
  }

  validarDisponibilidadInventario(itemsPedido, productoRepository) {
    if (!itemsPedido || itemsPedido.length === 0) {
      return ResultadoOperacion.fallo("El pedido debe contener al menos un producto.", null, "ValidadorReglasNegocio");
    }
    const motivosFaltantes = [];
    for (const item of itemsPedido) {
      const checkCant = this.validarCantidadPositiva(item.cantidad);
      if (!checkCant.exito) return checkCant;

      const prod = productoRepository.buscarPorId(item.productoId);
      const disp = prod ? prod.existencias : 0;
      if (!prod || !prod.tieneStockSuficiente(item.cantidad)) {
        motivosFaltantes.push(`${item.nombre} (Solicitado: ${item.cantidad}, Disponible: ${disp})`);
      }
    }
    if (motivosFaltantes.length > 0) {
      return ResultadoOperacion.fallo(
        `CONFIRMACIÓN IMPEDIDA — INVENTARIO INSUFICIENTE: ${motivosFaltantes.join("; ")}. Las existencias NO fueron modificadas.`,
        motivosFaltantes,
        "ValidadorReglasNegocio"
      );
    }
    return ResultadoOperacion.ok("Existencias suficientes verificadas.", null, "ValidadorReglasNegocio");
  }

  validarTransicionEstado(pedido, nuevoEstado) {
    if (nuevoEstado === "Confirmado") {
      if (pedido.estado !== "Pendiente") {
        return ResultadoOperacion.fallo(
          `Transición inválida: El pedido ${pedido.id} está en estado '${pedido.estado}' y no puede volver a confirmarse.`,
          null,
          "ValidadorReglasNegocio"
        );
      }
      if (pedido.stockDescontado) {
        return ResultadoOperacion.fallo(
          `Protección anti-duplicado: El pedido ${pedido.id} ya tiene existencias descontadas.`,
          null,
          "ValidadorReglasNegocio"
        );
      }
    } else if (nuevoEstado === "Despachado") {
      if (pedido.estado !== "Confirmado") {
        return ResultadoOperacion.fallo(
          `Transición inválida: Solo se pueden despachar pedidos en estado 'Confirmado' (Estado actual: ${pedido.estado}).`,
          null,
          "ValidadorReglasNegocio"
        );
      }
    } else if (nuevoEstado === "Rechazado") {
      if (pedido.estado === "Despachado") {
        return ResultadoOperacion.fallo(
          `Transición bloqueada: No se puede rechazar/cancelar un pedido que ya fue 'Despachado'.`,
          null,
          "ValidadorReglasNegocio"
        );
      }
    }
    return ResultadoOperacion.ok("Transición de estado permitida.", null, "ValidadorReglasNegocio");
  }
}
